<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/27
  Time: 下午4:41
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Species</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/allSpecies.css">
    <link rel="stylesheet" href="css/body_species.css">--%>
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/allSpecies_24.css">');
            document.write('<link rel="stylesheet" href="css/body_species_24.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/allSpecies_18.css">');
            document.write('<link rel="stylesheet" href="css/body_species_18.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/allSpecies_15.css">');
            document.write('<link rel="stylesheet" href="css/body_species_15.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/allSpecies.css">');
            document.write('<link rel="stylesheet" href="css/body_species.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/allSpecies_6.css">');
            document.write('<link rel="stylesheet" href="css/body_species_6.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>

<div id="body">

    <div id="body_center_center">

        <div class="body_center_center_center">
<s:iterator value="specieslinksList" var="specieslinks">
            <div class="b_c_c_c_top1">


                <div class="species_picture">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=<s:property value="#specieslinks.spe_link_id"/>" target="_blank">
                        <img src="image/<s:property value="#specieslinks.spe_images"/>">
                    </a>
                </div>
                <div class="species_name">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=<s:property value="#specieslinks.spe_link_id"/>" target="_blank">
                        <div class="species_name_commonName">
                            <p><s:property value="#specieslinks.spe_com_name"/></p>
                        </div>
                        <div class="species_name_LDName">
<%--                            <p><i><s:property value="#specieslinks.spe_ladingname1"/> </i><i><s:property value="#specieslinks.spe_ladingname1"/></i></p>--%>
                            <p><i><s:property value="#specieslinks.spe_ladingname1"/> </i></p>
                        </div>
                    </a>
                </div>

            </div>
</s:iterator>
        </div>

        <%--<div class="body_center_center_bottom">
            <div class="b_c_c_c_top2">

                <div class="species_picture">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=2" target="_blank">
                        <img src="image/Brassica_oleracea2.jpg">
                    </a>
                </div>
                <div class="species_name">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=2" target="_blank">
                        <div class="species_name_commonName">
                            <p>Savoy cabbage</p>
                        </div>
                        <div class="species_name_LDName">
                            <p><i>Brassica oleracea</i></p>
                        </div>
                    </a>
                </div>

            </div>
            <div class="b_c_c_c_top3">

                <div class="species_picture">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=20" target="_blank">
                        <img src="image/bn.jpg">
                    </a>
                </div>
                <div class="species_name">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=20" target="_blank">
                        <div class="species_name_commonName">
                            <p>Oilseed rape</p>
                        </div>
                        <div class="species_name_LDName">
                            <p><i>Brassica napus</i></p>
                        </div>
                    </a>
                </div>

            </div>
            <div class="b_c_c_c_top1">
                <div class="species_picture">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=21" target="_blank">
                        <img src="image/ninanjieindex.jpeg">
                    </a>
                </div>
                <div class="species_name">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=21" target="_blank">
                        <div class="species_name_commonName">
                            <p>Thale cress</p>
                        </div>
                        <div class="species_name_LDName">
                            <p><i>Arabidopsis thaliana</i></p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="b_c_c_c_top1">
                <div class="species_picture">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=18" target="_blank">
                        <img src="image/Brassica_nigra.png">
                    </a>
                </div>
                <div class="species_name">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=18" target="_blank">
                        <div class="species_name_commonName">
                            <p>Black mustard</p>
                        </div>
                        <div class="species_name_LDName">
                            <p><i>Brassica nigra</i></p>
                        </div>
                    </a>
                </div>
            </div>

        </div>
        <div class="body_center_center_bottom">
            <div class="b_c_c_c_top1">


                <div class="species_picture">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=9" target="_blank">
                        <img src="image/Arabis_alpina.png">
                    </a>
                </div>
                <div class="species_name">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=9" target="_blank">
                        <div class="species_name_commonName">
                            <p>Alpine rock-cress</p>
                        </div>
                        <div class="species_name_LDName">
                            <p><i>Arabis alpina</i></p>
                            &lt;%&ndash;https://www.ncbi.nlm.nih.gov/pubmed/31554715&ndash;%&gt;
                        </div>
                    </a>
                </div>

            </div>
            <div class="b_c_c_c_top3">
                <div class="species_picture">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=23" target="_blank">
                        <img src="image/wujing1.jpg">
                    </a>
                </div>
                <div class="species_name">
                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=23" target="_blank">
                        <div class="species_name_commonName">
                            <p >Yellow sarson</p>
                        </div>
                        <div class="species_name_LDName">
                            <p><i>Brassica rapa </i>subsp. <i>trilocularis</i></p>
                        </div>
                    </a>
                </div>
            </div>

        </div>--%>
    </div>
</div>



<%@include file="footer.jsp"%>
</body>
</html>
