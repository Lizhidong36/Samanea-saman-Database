<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/10
  Time: 21:30
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
   <%-- <link rel="stylesheet" href="css/footer.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/footer_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/footer_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/footer_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/footer.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/footer_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>
<!--footer-->
<div id="footer">
    <div class="footer_center">

<%--        <div class="link">--%>
<%--            <a href="http://yyxy.njau.edu.cn/__local/C/1C/E2/DA907B97B9033F0BDE97849A464_2D431DBC_48E3B.pdf?e=.pdf" target="_blank">About &nbsp;Us</a>--%>
<%--            |--%>
<%--            <a href="http://tbir.njau.edu.cn/pLoTs/getP_primer.action?&uuidFilenametitle=userguides" target="_blank">User &nbsp;Guide</a>--%>
<%--            |--%>
<%--            <a href="${pageContext.request.contextPath}/faq_allList.action" target="_blank">FAQ</a>--%>
<%--            |--%>
<%--            <a href="${pageContext.request.contextPath}/contact.jsp" target="_blank">Contact &nbsp;Us</a>--%>


<%--        </div>--%>
        <div class="Copyright">
            <p>Copyright @  Hainan University</p>

        </div>

    </div>
</div>
</body>
</html>
