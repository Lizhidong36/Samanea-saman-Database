<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/8/15
  Time: 11:58
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@include file="backHeader.jsp"%>
<%@taglib uri="/struts-tags" prefix="s"%>
<html lang="en">
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/backIndex.css">
</head>
<body>

<div id="body">
    <div class="body_center">
        <div class="b_c_top">
            <p>Maintenance &nbsp;Information</p>
        </div>
        <div class="b_c_body">
            <textarea class="main_cont" ><s:property value="#session.main_infor"/></textarea>
            <input class="save_btn" type="button" value="save">
            <%--<input class="edit_btn" type="button" value="edit">--%>
        </div>
    </div>
</div>

<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">


    $(function () {


        $.post('${pageContext.request.contextPath}/MainInfor_list.action?main_in_id=1',function () {




        });


    });

    $(".save_btn").click(function () {

        var con =  $(".main_cont").val();
       // alert(con);

        $.post('${pageContext.request.contextPath}/MainInfor_save.action?main_infor='+con+'&main_in_id=1',function () {
           // alert(con);
        });
    });
</script>
</body>
</html>
