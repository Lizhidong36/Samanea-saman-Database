<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/28
  Time: 下午1:25
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/SearchInto.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/SearchInto_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/SearchInto_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/SearchInto_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/SearchInto.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/SearchInto_6.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
    <div class="body_center">
        <form action="#">

            <div class="form_top">
                <p>Search</p>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                        Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                    </p>
                </div>
            </div>

            <div class="gene_family">
                <div class="gene_family_top">
                    <p>Gene family:</p>
                </div>
                <div class="gene_family_cont">
                    <p>Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                        Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                    </p>
                </div>
            </div>

            <div class="gene_family">
                <div class="gene_family_top">
                    <p>Glucosinolate genes:</p>
                </div>
                <div class="gene_family_cont">
                    <p>Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                        Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                    </p>
                </div>
            </div>

            <div class="gene_family">
                <div class="gene_family_top">
                    <p>Gene family:</p>
                </div>
                <div class="gene_family_cont">
                    <p>Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                        Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                    </p>
                </div>
            </div>

            <div class="gene_family">
                <div class="gene_family_top">
                    <p>Gene family:</p>
                </div>
                <div class="gene_family_cont">
                    <p>Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                        Datasets of Brassicaceae plants will be provided in BRAD promptly.
                        We will update these datasets when necessary changes are made to the genome references.
                    </p>
                </div>
            </div>
        </form>
    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
