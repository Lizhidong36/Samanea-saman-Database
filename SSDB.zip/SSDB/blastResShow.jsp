<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/11/8
  Time: 下午8:52
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags"  prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/blastResShow.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/blastResShow_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/blastResShow_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/blastResShow_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/blastResShow.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/blastResShow_6.css">');
        }
    </script>
</head>
<body>
<div id="showRes">

    <div class="blast_title">
        <p>Congratulations, ran successfully !</p>
    </div>
    <div class="showRes_btn">
        <input class="btn" type="button" value="Show Result">
        <a href="download_downblastRes.action?fileName=<s:property value="#session.uuidFilenameTitle"/>&type=<s:property value="#session.type"/>">
            <input type="button" class="download_btn" value="Download Result">
        </a>

        <input id="hiddenblastName"  style="display:none"  type="text" value="<s:property value="#session.uuidFilenameTitle"></s:property>" >
    </div>
    <div class="res_filetitle">
        Result id : <s:property value="#session.uuidFilenameTitle"/>
    </div>

</div>
<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript">
    $(".btn").click(function () {

        blastuuidFilenameTitle =   $("#hiddenblastName").val();
        /*alert(blastuuidFilenameTitle);*/


        $(window).attr('location','${pageContext.request.contextPath}/GetResult_blastRes.action?blast_db=<s:property value="#session.type"/>&blastuuidFilenameTitle=' + blastuuidFilenameTitle);

    });
</script>
</body>
</html>
