<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2022/10/16
  Time: 下午5:27
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Duplication Type</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/literuture_24.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_24.css">');

            document.write('<link rel="stylesheet" href="css/duplication_type_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/literuture_18.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_18.css">');


            document.write('<link rel="stylesheet" href="css/duplication_type_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/literuture_15.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_15.css">');


            document.write('<link rel="stylesheet" href="css/duplication_type_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/literuture.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle.css">');

            document.write('<link rel="stylesheet" href="css/duplication_type.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/literuture_6.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_6.css">');


            document.write('<link rel="stylesheet" href="css/duplication_type_6.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <!--body_center-->
    <div id="body_center">

        <div class="body_center_top">
            <p class="b_c_t_p1">Duplication &nbsp;Type</p>
            <div id="s_input">
                <input type="text" id="input_search" value="<s:property value="#parameters.keyword"/>" placeholder="Search gene id/name, chr or description">
            </div>
            <div id="s_button">
                <input type="button" value="Search">
            </div>
        </div>


        <%--<div class="body_center_bottom">
            <a href="https://pubmed.ncbi.nlm.nih.gov/<s:property value="#article.ar_link"/>" target="_blank">
        </div>--%>
        <div class="ssr_list">
            <div class="ssr_list_headerid">Gene Id</div>
            <div class="ssr_list_headernr">Species</div>

<%--            <div class="ssr_list_headerssr">Evalue</div>--%>
            <div class="ssr_list_headersize">Annotation</div>
            <div class="ssr_list_headerstart">Chromosome</div>
            <div class="ssr_list_headertype">Type</div>
<%--            <div class="ssr_list_headerend">End</div>--%>
<%--            <div class="ssr_list_headerssr"><s:property value="#session.last_title_des2"/></div>--%>
<%--            <div class="ssr_list_headerprimer"><s:property value="#session.last_title_des"/></div>--%>
        </div>
<%--        <s:iterator value="list" var="functiongenes">--%>
<%--            <div class="ssr_detail">--%>
<%--                <div class="ssr_list_ID">--%>
<%--                    <a target="_blank" href="http://tbir.njau.edu.cn/JBrowse-1.16.6/?data=Nasturtium_officinale&loc=<s:property value="#functiongenes.glu_species_gene_id"/>&tracks=DNA%2CGFF3%20Annotations&highlight=">--%>
<%--                    <s:property value="#functiongenes.glu_species_gene_id"/>--%>
<%--                    </a>--%>
<%--                </div>--%>
<%--                <div class="ssr_list_nr">--%>
<%--                    <i><s:property value="#functiongenes.glu_species_name"/></i>--%>
<%--                </div>--%>


<%--                <div class="ssr_list_size">--%>
<%--                    <a target="_blank" href="${pageContext.request.contextPath}/literuture_noonesyngeneAnno.action?g_name=<s:property value="#functiongenes.glu_species_gene_id"/>">--%>
<%--                    <span class="icon-eye"></span>--%>
<%--                    </a>--%>
<%--                </div>--%>
<%--                <div class="ssr_list_star">--%>
<%--                    <s:property value="#functiongenes.glu_chr"/>--%>
<%--                </div>--%>
<%--                <div class="ssr_list_type">--%>

<%--                    <s:property value="#functiongenes.glu_ath_gene_id"/>--%>

<%--                </div>--%>
<%--&lt;%&ndash;                <div class="ssr_list_SSR">&ndash;%&gt;--%>
<%--&lt;%&ndash;                    <s:property value="#functiongenes.glu_evalue"/>&ndash;%&gt;--%>
<%--&lt;%&ndash;                </div>&ndash;%&gt;--%>

<%--&lt;%&ndash;                <div class="ssr_list_end"><s:property value="#functiongenes.S_end"/></div>&ndash;%&gt;--%>
<%--&lt;%&ndash;                <a target="_blank" href="${pageContext.request.contextPath}/literuture_onessr.action?ssrid=<s:property value="#functiongenes.glu_pfam"/>">&ndash;%&gt;--%>
<%--&lt;%&ndash;                    <div class="ssr_list_primer"><s:property value="#functiongenes.glu_pfam"/></div>&ndash;%&gt;--%>
<%--&lt;%&ndash;                </a>&ndash;%&gt;--%>


<%--            </div>--%>
<%--        </s:iterator>--%>



        <div id="page" class="page_div"></div>

    </div>
</div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<%--<script src="js/jquery.min.js"></script>--%>
<script type="text/javascript" src="js/paging.js"></script>
<script type="text/javascript">

    //分页
    $("#page").paging({
        pageNo:<s:property value="currentPage"/>,
        totalPage: <s:property value="totalPage"/>,
        totalSize:  <s:property value="totalCount"/>,
        callback: function(num) {
            var keyword =  $("#input_search").val();

            //alert(keyword);

            //alert(num);
            <%--$(window).attr('location','${pageContext.request.contextPath}/literuture_no_duplicationlist.action?gene_function_type=<s:property value="#session.gene_function_type"/>&currPage='+num+'&keyword='+keyword);--%>
        }
    });

    $("#s_button").click(function () {

        var keyword =  $("#input_search").val();

        //alert(keyword);
        <%--$(window).attr('location','${pageContext.request.contextPath}/literuture_no_duplicationlist.action?gene_function_type=<s:property value="#session.gene_function_type"/>&keyword='+keyword);--%>
    });

</script>

<%@include file="footer.jsp"%>

</body>
</html>
