<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/12/8
  Time: 下午6:48
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Pathway Detail</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/testpathway24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/testpathway18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/testpathway15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/testpathway1.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/testpathway6.css">');
        }
    </script>
    <%--<link rel="stylesheet" href="css/testpathway1.css">--%>



</head>
<body>
<%@include file="pathwayheader.jsp"%>
<div id="body">
    <div class="body_center">
        <div id="main" align="center">
        </br>
            <img id="pathwayimg" src="${pageContext.request.contextPath}/getP_primer.action?&uuidFilenametitle=<s:property value="#session.k_num"/>" usemap="#hotpoint"/>
            <map name="hotpoint" id="hotpoint" >
                <s:iterator value="allpathways" var="pathwaydetail">
                    <area shape=rect coords='<s:property value="#pathwaydetail.ko_coords"/>' name='<s:property value="#pathwaydetail.ko_allgene"/>'/>
                </s:iterator>

            </map>
        </div>
        <br>
        <div class="wrap"     style="font-family: 'Roboto', sans-serif;"><ul></ul></div>
    </div>
</div>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">
    $(function(){
        $(".wrap").hide();
        $("area").mouseover(function(e){
            e.stopPropagation();
            var pros=$(this).attr("name");
            var proarr=pros.split(';');
            pros="";

            // for(var i=0;i<proarr.length;i++){
            //     pros+="<li>"+proarr[i]+"</li>";
            // }

            for(var i=0;i<proarr.length;i++){
                pros+="<a href="+'${pageContext.request.contextPath}/literuture_noonesyngeneAnno.action?g_name='+proarr[i]+" target='_blank'><li>"+proarr[i]+"</li></a>";
            }



            $(".wrap ul").html(pros);
            $(".wrap").css({top:e.pageY,left:e.pageX}).show();

            $(".wrap li").mouseover(function(){
                this.style.cursor="pointer";
                this.style.borderBottom="1px dotted #999999";
                this.style.color="orangered";
            });
            $(".wrap li").mouseout(function(){
                this.style.borderBottom="";
                this.style.color="blue";
            });

        })



        $("#main").click(function () { $(".wrap").hide() });


        $("#pathwayimg").load(function() {
            var len=$(this).width();
            if (len>900)
            {
                $(".main").width(len);
                $(".footer").width(len);
            }
        });
    })

</script>
<%@include file="pathayfooter.jsp"%>
</body>
</html>
