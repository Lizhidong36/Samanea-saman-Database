<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/10
  Time: 21:28
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>NCCWDB</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/textselect.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/header_24.css">');
            document.write('<link rel="stylesheet" href="css/style.css">');
            document.write('<link rel="stylesheet" href="css/textselect_24.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');

        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/header_18.css">');
            document.write('<link rel="stylesheet" href="css/style.css">');
            document.write('<link rel="stylesheet" href="css/textselect_18.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/header_15.css">');
            document.write('<link rel="stylesheet" href="css/style.css">');
            document.write('<link rel="stylesheet" href="css/textselect_15.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/header.css">');
            document.write('<link rel="stylesheet" href="css/style.css">');
            document.write('<link rel="stylesheet" href="css/textselect.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/header_6.css">');
            document.write('<link rel="stylesheet" href="css/style.css">');
            document.write('<link rel="stylesheet" href="css/textselect_6.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>
<!--head-->
<div id="header">
    <!--header_top-->
    <div class="header_top">
        <div class="header_top_center">
            <div class="header_top_center_left">
                Welcome to
                <p id="first_word">S</p>
                <p id="two_word">S</p>
<%--                <p id="third_word">r</p>--%>
<%--                <p id="four_word">t</p>--%>
                <p id="five_word">D</p>
                <p id="six_word">B</p>
<%--                 &nbsp;| Since 2018--%>

            </div>

            <div class="header_top_center_right">

<%--                <a href="#">Regist</a>--%>
<%--                <a href="#">Login</a>--%>

<%--                <s:if test="%{#session.curUser == null}">--%>
<%--                    <a href="rejist222.jsp">Regist</a>--%>
<%--                    <a href="login2222.jsp">Login</a>--%>
<%--                </s:if>--%>
<%--                   <s:else>--%>
<%--                       <p class="p1">welcome:</p>--%>
<%--                       <s:property value="#session.curUser.username"></s:property>--%>
<%--                       <a  href="${pageContext.request.contextPath}/LoginAction_loginout.action">Quit</a>--%>
<%--                   </s:else>--%>

            </div>
        </div>
        <!--header_body-->
        <div class="header_body">

            <div class="header_body_center">
                <div class="header_body_center_left">
                    <%--<img src="image/DSC_3302.JPG">--%>
                    <img src="image/yushu.png">
                </div>

                <div class="header_body_center_center">
                    <p><i>Samanea &nbsp;saman</i> &nbsp;Database</p>
                   <%-- <p>&nbsp;V1.0</p>--%>
                </div>

               <div class="header_body_center_right">
<%--                    <div id="container">--%>
<%--                        <div id="content">--%>
<%--                            <div class="first">--%>
<%--                                <form target="_blank" id="head_blast_form" action="${pageContext.request.contextPath}/searchkeyAction_keywordsearch.action" method="post"  enctype="multipart/form-data">--%>
<%--                                    <input name="searchkeyword" id="kw" placeholder="For example: HSF" onkeyup="getContent(this);">--%>
<%--                                    <div class="icon-zoom-in"></div>--%>
<%--                                </form>--%>


<%--                            </div>--%>
<%--                            <div id="append"></div>--%>
<%--                        </div>--%>
<%--                    </div>--%>
<%--                    &lt;%&ndash; <div class="r_but">--%>
<%--                         <input  type="button" value="Search">--%>
<%--                     </div>&ndash;%&gt;--%>
<%--                </div>--%>
<%--                <div id="getdata_error">--%>
<%--                    <span style="color:red"><s:actionerror></s:actionerror></span>--%>
<%--                </div>--%>
                   <img src="image/logo.png" class="right_img_logo">
               </div>
            </div>

        </div>
    </div>
</div>
<div id="header_bottom">
    <div id="header_bottom_center">

        <ul class="firstNav">
            <li>
                <a id="header_bottom_center_s1"  href="${pageContext.request.contextPath}/index.jsp">
                    <span class="icon-home3"></span>
                    Home
                </a>

            </li>
<%--            <li>--%>
<%--                <a href="${pageContext.request.contextPath}/allSpecies.jsp" target="_blank">--%>
<%--                    <span class="icon-profile"></span>--%>
<%--                    Species--%>
<%--                </a>--%>

<%--            </li>--%>


            <li>
                <a id="header_bottom_center_s4" href="${pageContext.request.contextPath}/FunctionIntro_list.action?f_type=Tools" >
                    <span class="icon-wrench"></span>
                    Tools
                </a>
                <ul class="secondNav">

                    <li>
                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=blast&functionType=blast" >Blast+</a>
                    </li>


                    <li>
                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=go&functionType=go" >GO enrichment</a>
                    </li>
                    <li>
                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=kegg&functionType=kegg" >KEGG enrichment</a>
                    </li>

                    <li>
                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=tf&functionType=tf" >Transcription factors</a>
                    </li>

                </ul>
            </li>
            <li>

                <a id="header_bottom_center_s7" href="${pageContext.request.contextPath}/FunctionIntro_list.action?f_type=Search" >
                    <span class="icon-zoom-in"></span>
                    Search
                </a>
                <ul class="secondNav">
                    <li>
                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=batchquery&functionType=blast" >Batch Query</a>
                    </li>


<%--                    <li>--%>
<%--                        <a href="${pageContext.request.contextPath}/homologs.jsp" target="_blank">Homologs</a>--%>
<%--                    </li>--%>
                    <li>
                        <%--                        <a href="${pageContext.request.contextPath}/literuture_geneannolist.action" target="_blank">Gene Annotation</a>--%>
                        <a href="${pageContext.request.contextPath}/geneAnnoSearch.jsp" >Gene Search</a>
                    </li>

                    <li>
<%--                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=seqFetch&functionType=seqFetch&seq_species_types=nhcc" target="_blank">Sequence Fetch</a>--%>
<%--                        <a href="${pageContext.request.contextPath}/selctspecies_functiontype.action?function_types=Sequence_Fetch" target="_blank">Sequence Fetch</a>--%>
                        <a href="${pageContext.request.contextPath}/sequenceFetch.jsp" >Sequence Fetch</a>
                    </li>

<%--                    <li>--%>
<%--                        &lt;%&ndash;                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=seqFetch&functionType=seqFetch&seq_species_types=nhcc" target="_blank">Sequence Fetch</a>&ndash;%&gt;--%>
<%--                        &lt;%&ndash;                        <a href="${pageContext.request.contextPath}/selctspecies_functiontype.action?function_types=Sequence_Fetch" target="_blank">Sequence Fetch</a>&ndash;%&gt;--%>
<%--                        <a href="${pageContext.request.contextPath}/transcriptome.jsp" >Transcriptome</a>--%>
<%--                    </li>--%>

                </ul>
            </li>
            <li>

<%--                <a id="header_bottom_center_s6" href="${pageContext.request.contextPath}/literuture_list.action" >--%>
                <a id="header_bottom_center_s6" href="#" >
                    <span class="icon-file-text"></span>
                    Breeding
                </a>
                <ul class="secondNav">
                    <li>
                        <a href="https://bioinformatics.hainanu.edu.cn/bioplots_war_exploded/primer.jsp" >Primer Design</a>
                    </li>

                    <li>
                        <a href="${pageContext.request.contextPath}/SSRFinder.jsp" >SSR Finder</a>
                    </li>



                </ul>
            </li>

            <li class="current">
                <a id="header_bottom_center_s3" href="${pageContext.request.contextPath}/DownloadDetail_detail.action?download_fileType=genome" >
                    <span class="icon-download2"></span>
                    Download
                </a>

            </li>
<%--            <li>--%>

<%--                <a href="Submit.jsp" target="_blank">--%>
<%--                    <span class="icon-upload2"></span>--%>
<%--                    Data Submission--%>
<%--                </a>--%>

<%--            </li>--%>

            <li>

                <a href="Submit.jsp" target="_blank">
                    <span class="icon-eye"></span>
                    About
                </a>
                <ul class="secondNav">
                    <li>
                        <a href="https://bioinformatics.hainanu.edu.cn/" target="_blank">About Us</a>

                    </li>

<%--                    <li>--%>
<%--                        <a href="https://bioinformatics.hainanu.edu.cn/bioplots_war_exploded/getP_primer.action?&uuidFilenametitle=userguides" >User Guide</a>--%>
<%--                    </li>--%>
                </ul>

            </li>

<%--            <li>--%>

<%--                <a id="header_bottom_center_s6" href="${pageContext.request.contextPath}/literuture_list.action" target="_blank">--%>
<%--                    <span class="icon-file-text"></span>--%>
<%--                    Breeding--%>
<%--                </a>--%>
<%--            </li>--%>



        </ul>
    </div>

</div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript" src="js/selecttet.js"></script>
<script type="text/javascript">

    $(function () {


        $('.firstNav>li.current .secondNav').css('display','none');

       /* $('.firstNav>li').hover(function () {
            $(this).children('.secondNav').stop().slideToggle(200);

        });*/

        $('.firstNav>li').mouseenter(function () {
            $(this).children('.secondNav').stop().slideDown(200);

        });
        $('.firstNav>li').mouseleave(function () {
            $(this).children('.secondNav').stop().slideUp(200);

        });

        $('#header_bottom_center>.firstNav>li>a').mouseenter(function () {
            //alert('aa');
            $(this).css({

                'color':'orangered'
            });
        });
        $('#header_bottom_center>.firstNav>li>a').mouseleave(function () {
            //alert('aa');
            $(this).css({

                'color':'black'
            });
        });
        $('.secondNav>li>a').mouseenter(function () {
            $(this).css({
                'color':'orangered',
                'font-weight':'bold',
                'cursor':'pointer'
            });
        });
        $('.secondNav>li>a').mouseleave(function () {
            $(this).css({
                'color':'black',
                'font-weight':'normal'
            });
        });

        $(".icon-zoom-in").click(function () {


            $("#head_blast_form").submit();
        });

        $('.firstNav>li.current .thirdNav').css('display','none');
        $('.secondNav>li').mouseenter(function () {
            $(this).children('.thirdNav').stop().slideDown(200);

        });
        $('.secondNav>li').mouseleave(function () {
            $(this).children('.thirdNav').stop().slideUp(200);

        });


        $('.thirdNav>li>a').mouseenter(function () {
            $(this).css({
                'color':'orangered',
                'font-weight':'bold',
                'cursor':'pointer'
            });
        });
        $('.thirdNav>li>a').mouseleave(function () {
            $(this).css({
                'color':'black',
                'font-weight':'normal'
            });
        });

        $('.firstNav>li.current .fourNavs').css('display','none');
        $('.thirdNav>li').mouseenter(function () {
            $(this).children('.fourNavs').stop().slideDown(200);

        });
        $('.thirdNav>li').mouseleave(function () {
            $(this).children('.fourNavs').stop().slideUp(200);

        });


        $('.fourNavs>li>a').mouseenter(function () {
            $(this).css({
                'color':'orangered',
                'font-weight':'bold',
                'cursor':'pointer'
            });
        });
        $('.fourNavs>li>a').mouseleave(function () {
            $(this).css({
                'color':'black',
                'font-weight':'normal'
            });
        });
        // $('.firstNav>li.current .secondNav').css('display','none');
        //
        // /* $('.firstNav>li').hover(function () {
        //      $(this).children('.secondNav').stop().slideToggle(200);
        //
        //  });*/
        //
        // $('.firstNav>li').mouseenter(function () {
        //     $(this).children('.secondNav').stop().slideDown(200);
        //
        // });
        // $('.firstNav>li').mouseleave(function () {
        //     $(this).children('.secondNav').stop().slideUp(200);
        //
        // });
        //
        // $('#header_bottom_center>.firstNav>li>a').mouseenter(function () {
        //     //alert('aa');
        //     $(this).css({
        //
        //         'color':'orangered'
        //     });
        // });
        // $('#header_bottom_center>.firstNav>li>a').mouseleave(function () {
        //     //alert('aa');
        //     $(this).css({
        //
        //         'color':'black'
        //     });
        // });
        // $('.secondNav>li>a').mouseenter(function () {
        //     $(this).css({
        //         'color':'orangered',
        //         'font-weight':'bold',
        //         'cursor':'pointer'
        //     });
        // });
        // $('.secondNav>li>a').mouseleave(function () {
        //     $(this).css({
        //         'color':'black',
        //         'font-weight':'normal'
        //     });
        // });
        //
        // $(".icon-zoom-in").click(function () {
        //
        //
        //     $("#head_blast_form").submit();
        // });

    });
</script>
</body>
</html>
