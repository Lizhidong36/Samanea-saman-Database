<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/5/19
  Time: 下午3:24
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags"  prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/GoResult.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/GoResult_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/GoResult_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/GoResult_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/GoResult.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/GoResult_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>

<%@include file="header.jsp"%>

<!--body-->
<div id="body">
    <div class="body_center">
        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/GoEnrich_gorich.action" method="post"  enctype="multipart/form-data">


            <div id="showRes">

                <div class="blast_title">
                    <p>Congratulations, ran successfully !</p>
                </div>
                <div class="showRes_btn">
                    <input class="btn" type="button" value="Show Result">
                    <a href="download_downblastRes.action?fileName=<s:property value="#session.uuidFilenameTitle"/>&type=<s:property value="#session.type"/>">
                        <input type="button" class="download_btn" value="Download Result">
                    </a>

                    <input id="hiddenblastName"  style="display:none"  type="text" value="<s:property value="#session.uuidFilenameTitle"></s:property>" >

                </div>
                <div class="res_filetitle">
                    Result id : <s:property value="#session.uuidFilenameTitle"/>
                </div>

            </div>

            <div class="plot_pdf">

                <iframe id="myimg" src="${pageContext.request.contextPath}/getP_list.action?uuidFilenametitle=<s:property value="#session.uuidFilenameTitle"/>&type=<s:property value="#session.type"/>"  ></iframe>

            </div>



        </form>
    </div>
</div>
<%@include file="footer.jsp"%>


<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript">
    $(".btn").click(function () {

        blastuuidFilenameTitle =   $("#hiddenblastName").val();
       /* alert(blastuuidFilenameTitle);*/


        $(window).attr('location','${pageContext.request.contextPath}/GetResult_blastRes.action?blast_db=<s:property value="#session.type"/>&blastuuidFilenameTitle=' + blastuuidFilenameTitle);

    });
</script>
</body>
</html>
