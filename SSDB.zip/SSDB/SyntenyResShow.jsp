<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/11
  Time: 下午2:12
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags"  prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/blastResShow.css">
    <link rel="stylesheet" href="css/SyntenyResShow.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/blastResShow_24.css">');
            document.write('<link rel="stylesheet" href="css/SyntenyResShow_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/blastResShow_18.css">');
            document.write('<link rel="stylesheet" href="css/SyntenyResShow_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/blastResShow_15.css">');
            document.write('<link rel="stylesheet" href="css/SyntenyResShow_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/blastResShow.css">');
            document.write('<link rel="stylesheet" href="css/SyntenyResShow.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/blastResShow_6.css">');
            document.write('<link rel="stylesheet" href="css/SyntenyResShow_6.css">');
        }
    </script>


</head>
<body>

<div id="showRes">

    <div class="blast_title">
        Congratulations, Synteny Finder ran successfully !
    </div>
    <div class="syn_MCScanX">
        <div class="showRes_btn">
            <input class="btn" type="button" value="Show MCScanX Result">

            <a href="download_downblastRes.action?fileName=<s:property value="#session.uuidFilename"/>&type=<s:property value="#session.type"/>">
                <input type="button" class="download_btn" value="Download Result">
            </a>
            <input id="hiddenblastName"  style="display:none"  type="text" value="<s:property value="#session.uuidFilename"></s:property>" >

             <input id="firsthiddenblastName"  style="display:none"  type="text" value="<s:property value="#session.firstfileNamesTitle"></s:property>" >
            <input id="secondhiddenblastName"  style="display:none"  type="text" value="<s:property value="#session.secondfileNamesTitle"></s:property>" >


        </div>
        <div class="res_filetitle">
            Result Id : <s:property value="#session.uuidFilename"></s:property>

        </div>

    </div>
   <%-- Visualization--%>
    <div class="syn_visu">
        <div class="syn_visu_p">
            <p>
                Visualizing &nbsp;Synteny &nbsp;Finder &nbsp;Result
            </p>
        </div>
        <div class="syn_visu_canshu">
            <div class="syn_visu_canshu_left">
                <p>type:</p>
                <select  class="syn_type">
                    <option value="1">Circle</option>
                    <option value="2">dual plot</option>
                    <option value="3">dotplot</option>
                    <option value="4">bar</option>
                </select>
            </div>
            <div class="syn_visu_canshu_cent">
               <p>width:</p>
                <select  class="syn_width">
                    <option>800</option>
                    <option>600</option>
                    <option>400</option>
                    <option>1000</option>
                </select>
            </div>
            <div class="syn_visu_canshu_right">
               <p>height:</p>
                <select  class="syn_height">
                    <option>800</option>
                    <option>600</option>
                    <option>400</option>
                    <option>1000</option>
                </select>
            </div>
            <div class="syn_visu_canshu_last">
                <p>ext:</p>
                <select  class="pic_type">
                    <option>pdf</option>
                    <option>png</option>
                    <option>svg</option>
                    <option>jpeg</option>
                    <option>eps</option>
                    <option>bmp</option>
                </select>
            </div>
        </div>

        <div class="syn_visu_btn">
            <input type="button" class="syn_btn" value="Visualization">
        </div>
    </div>

</div>
<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript">
    $(".btn").click(function () {

        blastuuidFilenameTitle =   $("#hiddenblastName").val();
       /* alert(blastuuidFilenameTitle);*/

        $(window).attr('location','${pageContext.request.contextPath}/GetResult_blastRes.action?blast_db=<s:property value="#session.type"/>&blastuuidFilenameTitle=' + blastuuidFilenameTitle);


    });

    $(".syn_btn").click(function () {

        synuuidFilenameTitle =   $("#hiddenblastName").val();
       /* alert(synuuidFilenameTitle);*/

        firstfileNamesTitle =   $("#firsthiddenblastName").val();
       /* alert(firstfileNamesTitle);*/

        secondfileNamesTitle =   $("#secondhiddenblastName").val();
       /* alert(secondfileNamesTitle);*/

        var syn_type = $(".syn_type").val();
        /*alert(syn_type);*/

        var syn_width = $(".syn_width").val();
       /* alert(syn_width);*/

        var syn_height = $(".syn_height").val();
        /*alert(syn_height);*/

        var pic_type = $(".pic_type").val();
        /*alert(pic_type);*/

        $(window).attr('location','${pageContext.request.contextPath}/SyntenyVisualization_resShow.action?synuuidFilenameTitle='
            + synuuidFilenameTitle + '&syn_type=' + syn_type+ '&syn_width=' + syn_width + '&syn_height=' + syn_height
            + '&pic_type=' + pic_type + '&firstfileNamesTitle=' + firstfileNamesTitle + '&secondfileNamesTitle=' + secondfileNamesTitle);

    });
</script>
</body>
</html>
