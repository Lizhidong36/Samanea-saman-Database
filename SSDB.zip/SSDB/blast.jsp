<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/10
  Time: 21:59
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Blast+</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/blast.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/blast_24.css">');
            document.write('<link rel="stylesheet" href="css/opti_p.css">');

        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/blast_18.css">');
            document.write('<link rel="stylesheet" href="css/opti_p.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/blast_15.css">');
            document.write('<link rel="stylesheet" href="css/opti_p.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/blast.css">');
            document.write('<link rel="stylesheet" href="css/opti_p.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/blast_6.css">');
            document.write('<link rel="stylesheet" href="css/opti_p.css">');
        }
    </script>


</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">
<%--    <div id="userguidelink">--%>
<%--        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=Blast_1.zip" title="userguide and test data">--%>
<%--            <p class="userguidelink_p">Userguide and demo file</p>--%>
<%--        </a>--%>
<%--    </div>--%>
    <div class="body_center">
        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/LinuxBlastAction_Linuxblast.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p>Blast+</p>
                <select class="par_type" name="par_type">
                    <option>blast</option>
                </select>
            </div>
            <div class="form_type">
                <div class="f_t_lab">
                    <p>Select Position:</p>
                    <select class="blast_type" name="blast_type">
                        <option>blastn</option>
                        <option>blastp</option>
                        <option>blastx</option>
                        <option>tblastn</option>
                        <option>tblastx</option>
                    </select>
                </div>
            </div>
            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Database:</p>
                    <select class="blast_db" name="blast_db">

                       <s:iterator value="allBlastFile" var="BlastFile">
                           <option value="<s:property value="#BlastFile.blast_speciesFileName"></s:property>" >


                                   <s:property value="#BlastFile.balst_speciesName"></s:property>




                           </option>
                       </s:iterator>

                    </select>
                </div>
            </div>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Fasta Query Sequence:</p>
                    <textarea class="blast_seq" name="blast_seq" placeholder="Paste query sequence(s) in FASTA format here ...
For example:
>Bol004797
MTVLKRYVLRLFMSIKYITTNVVDKNNGRVVTTASTVEHAVKNSLECGRT
CNAKAAAILGEVLAMRLKVEGHQDGQGRGIHADVKKEIEKKGFKSRTKVW
AVINSVRNNGVTLILDDFNVDEDKYYRYRSDEGHQ"></textarea>
                    <input type="file" name="upload" id="fileupload">
                </div>
            </div>
            <div class="form_par">
                <div class="f_t_lab">
                    <p>Optional BLAST+ Parameters:</p>
                    <label>Expect Threshold:</label>
                    <select class="blast_eval" name="blast_eval">
                        <option>0.000001</option>
                        <option>0.00001</option>
                        <option>0.0001</option>
                        <option>0.001</option>
                        <option>0.01</option>
                        <option>0.1</option>
                        <option>1.0</option>
                    </select>
                    <br>
                    <label>Result Format:</label>
                    <select class="blast_eval" name="blast_outfmt">
                        <option>6</option>
                        <option>7</option>
                        <option>10</option>
                    </select>
                </div>
            </div>
            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit BLAST+ Search:</p>
                    <input type="button" value="Example" class="blast_example">
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>

<!--footer-->
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        function turn(str) {

            while (str.indexOf("\n") != -1) {
                str = str.substring(0, str.indexOf("\n")) + "<br>"
                    + str.substring(str.indexOf("\n") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\C6MC6M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("|") != -1) {
                str = str.substring(0, str.indexOf("|")) + "\C9MC9M"
                    + str.substring(str.indexOf("|") + 1);
            }
            while (str.indexOf("_") != -1) {
                str = str.substring(0, str.indexOf("_")) + "\C3MC3M"
                    + str.substring(str.indexOf("_") + 1);
            }
            while (str.indexOf("#") != -1) {
                str = str.substring(0, str.indexOf("#")) + "\C5MC5M"
                    + str.substring(str.indexOf("#") + 1);
            }
            while (str.indexOf("=") != -1) {
                str = str.substring(0, str.indexOf("=")) + "\C7MC7M"
                    + str.substring(str.indexOf("=") + 1);
            }
            while (str.indexOf(".") != -1) {
                str = str.substring(0, str.indexOf(".")) + "\C8MC8M"
                    + str.substring(str.indexOf(".") + 1);
            }
            while (str.indexOf("/") != -1) {
                str = str.substring(0, str.indexOf("/")) + "\C4MC4M"
                    + str.substring(str.indexOf("/") + 1);
            }
            while (str.indexOf("-") != -1) {
                str = str.substring(0, str.indexOf("-")) + "\C2MC2M"
                    + str.substring(str.indexOf("-") + 1);
            }
            while (str.indexOf("+") != -1) {
                str = str.substring(0, str.indexOf("+")) + "\C1MC1M"
                    + str.substring(str.indexOf("+") + 1);
            }
            while (str.indexOf(":") != -1) {
                str = str.substring(0, str.indexOf(":")) + "\M6666MM6666M"
                    + str.substring(str.indexOf(":") + 1);
            }
            while (str.indexOf(";") != -1) {
                str = str.substring(0, str.indexOf(";")) + "\M1111MM1111M"
                    + str.substring(str.indexOf(";") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\M2222MM2222M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("\t") != -1) {
                str = str.substring(0, str.indexOf("\t")) + "\M3333MM3333M"
                    + str.substring(str.indexOf("\t") + 1);
            }
            while (str.indexOf(",") != -1) {
                str = str.substring(0, str.indexOf(",")) + "\M4444MM4444M"
                    + str.substring(str.indexOf(",") + 1);
            }
            while (str.indexOf("    ") != -1) {
                str = str.substring(0, str.indexOf("    ")) + "\Cc1MCc1M"
                    + str.substring(str.indexOf("   ") + 1);
            }
            return str;
        };

        $(".blast_sb").click(function () {

            var blast_seq = $(".blast_seq").val();
            var fileupload = $("#fileupload").val();

           /* alert(blast_seq);*/
          /*  alert(fileupload);*/

            if(blast_seq == "" && fileupload == ""){
                alert("please upload fasta sequence file!");
            }

            if( blast_seq != "" && fileupload != ""){
                alert("please input or upload sequence file!");
            }

            if(blast_seq != "" && fileupload == ""){
                cont1 = turn(blast_seq);

                var new_blast_seq = $(".blast_seq").val(cont1);

                $("#blast_form").submit();
            }

            if(blast_seq == "" && fileupload != ""){

                $("#blast_form").submit();
            }

        });

        $(".blast_example").click(function () {


            $(".blast_seq").val(">BraC01g000050.1\n" +
                "MASTPPQNSKKVRNNSGSGQTVKFARRTSSGRYVSLSRDNIELSGEFSGDYSNYTVHIPPTPDNQPMATKAEEQYVSNSLFTGGFNSVTRAHLMDKVIDSDVTHPQMAGAKGSSCAMPACDGKVMKDERGKDVMPCECRFKICRDCFMDAQKETGLCPGCKEQYKIGDLDDDTPDFSSGALPLPAPGKGQRGNNNMSMMKRNQNGEFDHRWLFETQGTYGYGNAYWPQDEMYGDDMDEGMRGGMVETADKPWRPLSRRIPIPAAIISPYRLLIAIRFVVLCFFLTWRIRNPNEDAIWLWLMSIICELWFGFSWILDQIPKLCPINRSTDLEVLRDKFDMPSPSNPTGRSDLPGIDLFVSTADPEKEPPLVTANTMLSILAVDYPVEKVSCYLSDDGGALLSFEAMAEAASFADLWVPFCRKHNIEPRNPDTYFSLKIDPTKNKSRIDFVKDRRKIKREYDEFKVRINGLPDSIRRRSDAFNAREEMKALKQMRESGGDPMEPVKVLKATWMADGTHWPGTWAAATREHSKGDHAGILQVMLKPPSSDPLIGNDSDKIIDFSETDTRLPMFVYVSREKRPGYDHNKKAGAMNALVRASAILSNGPFILNLDCDHYIYNCKAIREGMCFMMDRGGEDICYIQFPQRFEGIDPSDRYANNNTVFFDGNMRALDGVQGPVYVGTGTMFRRFALYGFDPPNPDKILEKKESETEALTTSDFDPDLDVTQLPKRFGNSTLLAESIPIAEFQGRPLADHPAVKYGRPPGALRVPRDPLDATTVAESVSVISCWYEDKTEWGDRVGWIYGSVTEDVVTGYRMHNRGWRSVYCITKRDSFRGSAPINLTDRLHQVLRWATGSVEIFFSRNNAILASKRLKFLQRLAYLNVGIYPFTSLFLILYCFLPAFSLFSGQFIVRTLSISFLVYLLIITICLIGLAVLEVKWSGIGLEEWWRNEQWWLISGTSSHLYAVVQGILKVIAGIEISFTLTTKSGGDDNDDIYADLYIVKWSSLMIPPIVIAMVNIIAIVVAFVRTIYQAVPQWSKLIGGAFFSFWVLAHLYPFAKGLMGRRGKTPTIVFVWAGLIAITISLLWTAINPNSGPVAAAEGVGGGGFQFP\n"
                + ">A0A6B3NTW0\n" + "MIKIVPDPPLATPRKPAYTAFGCCNGNHPPLFSVCDGIELEDALVHLSLQIQCAKQTTAQACERADEQFKNLLMATQHSLELSNALIESVLDGMEAKAASK\n"
                + ">PSR83605\n" + "MDFSRFDFAMVRAATNDFSNGNKLGGGGFGSVYKGQLPNGQEIAVKRLANGAKQGQVEFKNEIVLLARLQHKNLVRLLGFCLEGEERLLVYEFVPNASLDHFIFDPIKRMFLNWEARYKIILGIVEGLVYLHQDSQLRIIHHDLKAGNVLLDCEMNPKIADFGLARLFLVDQSRGNTKRIGGTIGYMPPEYVQYGQFSVKTDVFSFGVLVLEIVSGRKNNGSEEHLISNAWKKWRQGKASRLIDQTLNGGSESEKMRCIHIGLLCVQENVAKRPTMASVALMLNSFSMSLSLPSKPAFLIQSSVVASTALPEKFPSRVTSSDQSLEHTSPDQSLEFSVNPSVNIEDSITLPR"
            );
            $(".blast_type").val("blastp");
            $(".blast_db").val("Samanea_saman_pep.fa");

        });


    });
</script>
</body>
</html>