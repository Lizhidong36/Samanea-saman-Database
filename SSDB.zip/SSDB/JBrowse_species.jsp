<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/22
  Time: 下午9:02
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/JBrowse_species.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/JBrowse_species_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/JBrowse_species_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/JBrowse_species_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/JBrowse_species.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/JBrowse_species_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>

<%@include file="header.jsp"%>

<!--body-->
<div id="body">
    <div class="body_center">
        <form action="#">
            <div class="form_top">
                <p>JBrowse</p>
            </div>

            <div class="form_Arabidopsis_thaliana">
                <div class="f_t_lab">
                    <p class="species_title">Arabidopsis thaliana 10:</p>
                    <ul>
                        <li>Arabidopsis thaliana 10 Genome Browser</li>
                    </ul>

                </div>
            </div>

        </form>
    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
