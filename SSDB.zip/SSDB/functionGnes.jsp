<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/27
  Time: 下午4:41
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Species</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/allSpecies.css">
    <link rel="stylesheet" href="css/body_species.css">--%>
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/allSpecies_24.css">');
            document.write('<link rel="stylesheet" href="css/body_species_24.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/allSpecies_18.css">');
            document.write('<link rel="stylesheet" href="css/body_species_18.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/allSpecies_15.css">');
            document.write('<link rel="stylesheet" href="css/body_species_15.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/allSpecies.css">');
            document.write('<link rel="stylesheet" href="css/body_species.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/allSpecies_6.css">');
            document.write('<link rel="stylesheet" href="css/body_species_6.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>

<div id="body">

    <div id="body_center_center">

        <div class="body_center_center_center">

            <p class="func_title"><s:property value="#session.funktion_types"/></p>
<s:iterator value="specieslinksList" var="specieslinks">
            <div class="b_c_c_c_top1">


                <div class="species_picture">
                    <a href="${pageContext.request.contextPath}/literuture_functiongenelist.action?gene_function_type=<s:property value="#session.funktion_types"/>&spe_ladingname2=<s:property value="#specieslinks.spe_ladingname2"/>&sepnamess=<s:property value="#specieslinks.spe_ladingname1"/>" >
<%--                    <a href="${pageContext.request.contextPath}/SpeciesIndex_getCont.action?spe_ind_pid=<s:property value="#specieslinks.spe_link_id"/>" target="_blank">--%>
                        <img src="image/<s:property value="#specieslinks.spe_images"/>">
                    </a>
                </div>
                <div class="species_name">
                    <a href="${pageContext.request.contextPath}/literuture_functiongenelist.action?gene_function_type=<s:property value="#session.funktion_types"/>&spe_ladingname2=<s:property value="#specieslinks.spe_ladingname2"/>&sepnamess=<s:property value="#specieslinks.spe_ladingname1"/>" >
                          <div class="species_name_commonName">
                            <p><s:property value="#specieslinks.spe_com_name"/></p>
                        </div>
                        <div class="species_name_LDName">
<%--                            <p><i><s:property value="#specieslinks.spe_ladingname1"/> </i><i><s:property value="#specieslinks.spe_ladingname1"/></i></p>--%>
                            <p><i><s:property value="#specieslinks.spe_ladingname1"/> </i></p>
                        </div>
                    </a>
                </div>

            </div>
</s:iterator>
        </div>


    </div>
</div>



<%@include file="footer.jsp"%>
</body>
</html>
