<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/9/4
  Time: 9:59
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@include file="header.jsp"%>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/LiteratureSearchRes.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/LiteratureSearchRes_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/LiteratureSearchRes_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/LiteratureSearchRes_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/LiteratureSearchRes.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/LiteratureSearchRes_6.css">');
        }
    </script>

</head>
<body>

<div id="body">
    <div class="body_center">
        <div class="b_c_top">
            <p>Literature &nbsp;Search &nbsp;Results</p>


        </div>

        <s:iterator value="articleList" var="article">
            <div class="body_center_bottom">
                <a href="https://pubmed.ncbi.nlm.nih.gov/<s:property value="#article.ar_link"/>" target="_blank">
                    <div class="title">
                            <s:property value="#article.ar_title"/>

                    </div>
                </a>
                <div class="author"><s:property value="#article.ar_author"/></div>


                <div class="journal"><s:property value="#article.ar_journal"/></div>

            </div>
        </s:iterator>

    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
