<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2022/10/16
  Time: 下午5:27
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Functional Genes</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/literuture_24.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_24.css">');

            document.write('<link rel="stylesheet" href="css/function_gene_detail_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/literuture_18.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_18.css">');


            document.write('<link rel="stylesheet" href="css/function_gene_detail_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/literuture_15.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_15.css">');


            document.write('<link rel="stylesheet" href="css/function_gene_detail_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/literuture.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle.css">');

            document.write('<link rel="stylesheet" href="css/function_gene_detail.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/literuture_6.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_6.css">');


            document.write('<link rel="stylesheet" href="css/function_gene_detail_6.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <!--body_center-->
    <div id="body_center">

        <div class="body_center_top">
            <p class="b_c_t_p1"><s:property value="#session.funt_type"/> &nbsp;(<i><s:property value="#session.sepnamess"/></i>)</p>
<%--            <p class="b_c_t_p1"><s:property value="#session.function_gene_t1"></s:property>&nbsp;&nbsp;<s:property value="#session.function_gene_t2"></s:property>&nbsp;&nbsp;Genes</p>--%>
<%--            <div id="s_input">--%>
<%--                <input type="text" id="input_search" value="<s:property value="#parameters.keyword"/>" placeholder="Search gene id/name, chr or description">--%>
<%--            </div>--%>
<%--            <div id="s_button">--%>
<%--                <input type="button" value="Search">--%>
<%--            </div>--%>
        </div>


        <%--<div class="body_center_bottom">
            <a href="https://pubmed.ncbi.nlm.nih.gov/<s:property value="#article.ar_link"/>" target="_blank">
        </div>--%>
        <div class="ssr_list">
            <div class="ssr_list_headerid">Gene Id</div>
            <div class="ssr_list_headernr">At Gene</div>

<%--            <div class="ssr_list_headerssr">Evalue</div>--%>
            <div class="ssr_list_headersize">Gene Name</div>
            <div class="ssr_list_headerstart">Annotation / Function</div>
            <div class="ssr_list_headertype">Reference</div>
<%--            <div class="ssr_list_headerend">End</div>--%>
<%--            <div class="ssr_list_headerssr"><s:property value="#session.last_title_des2"/></div>--%>
<%--            <div class="ssr_list_headerprimer"><s:property value="#session.last_title_des"/></div>--%>
        </div>
        <s:iterator value="list" var="function_spe">
            <div class="ssr_detail">
                <div class="ssr_list_ID">
<%--                    <a target="_blank" href="http://tbir.njau.edu.cn/JBrowse-1.16.6/?data=Brassica_campestris_ssp.chinensis_Cultivar_NHCC001_V1&loc=<s:property value="#functiongenes.glu_species_gene_id"/>&tracks=DNA%2CGFF3%20Annotations&highlight=">--%>
                    <s:property value="#function_spe.fu_species_gene_id"/>
<%--                    </a>--%>
                </div>
                <div class="ssr_list_nr">
                    <s:property value="#function_spe.at_name"/>
                </div>


<%--                <div class="ssr_list_size">--%>
<%--                    <a target="_blank" href="${pageContext.request.contextPath}/literuture_onesyngeneAnno.action?g_name=<s:property value="#functiongenes.glu_species_gene_id"/>">--%>
<%--                    <span class="icon-eye"></span>--%>
<%--                    </a>--%>
<%--                </div>--%>
                <div class="ssr_list_star">
                    <i><s:property value="#function_spe.fu_name"/></i>
                </div>
                <div class="ssr_list_type">
<%--                    <a href="<s:property value="#functiongenes.glu_link"/>" target="_blank">--%>
                    <s:property value="#function_spe.fu_detail"/>
<%--                    </a>--%>
                </div>
<%--                <div class="ssr_list_SSR">--%>
<%--                    <s:property value="#functiongenes.glu_evalue"/>--%>
<%--                </div>--%>

<%--                <div class="ssr_list_end"><s:property value="#functiongenes.S_end"/></div>--%>
<%--                <a target="_blank" href="${pageContext.request.contextPath}/literuture_onessr.action?ssrid=<s:property value="#functiongenes.glu_pfam"/>">--%>
                    <div class="ssr_list_primer"><s:property value="#function_spe.fu_ref"/></div>
<%--                </a>--%>


            </div>
        </s:iterator>



        <div id="page" class="page_div"></div>

    </div>
</div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<%--<script src="js/jquery.min.js"></script>--%>
<script type="text/javascript" src="js/paging.js"></script>
<script type="text/javascript">

    //分页
    $("#page").paging({
        pageNo:<s:property value="currentPage"/>,
        totalPage: <s:property value="totalPage"/>,
        totalSize:  <s:property value="totalCount"/>,
        callback: function(num) {
            var keyword =  $("#input_search").val();

            //alert(keyword);

            //alert(num);
            $(window).attr('location','${pageContext.request.contextPath}/literuture_functiongenelist.action?gene_function_type=<s:property value="#session.funt_type"/>&currPage='+num+'&spe_ladingname2=<s:property value="#session.fu_spe"/>&sepnamess=<s:property value="#session.sepnamess"/>');
        }
    });

    $("#s_button").click(function () {

        var keyword =  $("#input_search").val();

        //alert(keyword);
        <%--$(window).attr('location','${pageContext.request.contextPath}/literuture_functiongenelist.action?gene_function_type=<s:property value="#session.gene_function_type"/>&keyword='+keyword);--%>
        $(window).attr('location','${pageContext.request.contextPath}/literuture_functiongenelist.action?gene_function_type=<s:property value="#session.funt_type"/>&currPage='+num+'&spe_ladingname2=<s:property value="#session.fu_spe"/>&sepnamess=<s:property value="#session.sepnamess"/>');

    });

</script>

<%@include file="footer.jsp"%>

</body>
</html>
