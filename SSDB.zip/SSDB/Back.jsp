<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/8/14
  Time: 18:54
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%--<%@include file="backHeader.jsp"%>--%>
<%@taglib uri="/struts-tags" prefix="s"%>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/Back.css">
</head>
<body>
<!--header-->
<div id="header">
    <!--header_top-->
    <div class="header_top">
        <div class="header_top_center">
            <div class="header_top_center_left">
                Welcome &nbsp;to &nbsp;NOGR
            </div>

            <div class="header_top_center_right">
                <%--<span>welcome:</span>
                <span class="back_name"><s:property value="ba_username" ></s:property></span>--%>
                <a href="index1.jsp">Home</a>

            </div>
        </div>

        <!--header_body-->
        <div class="header_body">

            <div class="header_body_center">
                <div class="header_body_center_left">
                    <img src="image/DSC_3302.JPG">
                </div>

                <div class="header_body_center_center">
                    <p>NOGR &nbsp;Background &nbsp;Management &nbsp;System</p>
                    <%--<p>&nbsp;V1.0</p>--%>
                </div>


            </div>

        </div>
    </div>
</div>
<div id="body">

    <div class="body_center">


        <div class="body_center_left">

          <span style="color:red"><s:actionerror></s:actionerror></span>


            <form action="${pageContext.request.contextPath}/Back_login.action" method="post">
                <div>
                    <label>Username</label>
                    <input   name="ba_username" id="username" type="text" placeholder="Enter your username">
                </div>
                <div>
                    <label>Password</label>
                    <input name="ba_password" id="password" type="password" placeholder="Enter your passwrd">
                </div>
                <div class="submit_button">
                    <input type="submit" value="Login">
                </div>
            </form>
        </div>
        <div class="body_center_right">
            <div class="body_center_right_cen">
                <img src="image/DSC_3307.JPG">
            </div>
        </div>
    </div>
</div>
</body>
</html>
