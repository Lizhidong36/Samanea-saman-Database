<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/10/10
  Time: 16:32
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/back_NewsControl.css">
</head>
<body>
<%@include file="backHeader.jsp"%>
<div id="body">
    <div class="body_center">
        <div class="body_center_center">
            <div class="b_c_c_top">
                <div class="b_c_c_top_title">
                    <p>News</p>
                </div>
                <div class="b_c_c_top_addNews">
                    <a href="${pageContext.request.contextPath}/back_AddNews.jsp" target="_blank">
                        <input  type="button" class="add_news" value="Add News">
                    </a>

                </div>


            </div>
            <div class="b_c_c_home">
            <s:iterator value="allBackNews" var="news">
                <div class="b_c_c_home_newsdetail">
                    <div class="b_c_c_home_newsdetail_title">
                        <ul>
                            <li>
                                <a href="${pageContext.request.contextPath}/news_oneNews.action?new_id=<s:property value="#news.new_id"/>" target="_blank"><s:property value="#news.new_desc"/></a>

                            </li>
                        </ul>
                    </div>

                    <div class="b_c_c_home_newsdetail_delete">
                        <a href="${pageContext.request.contextPath}/news_deleteoneNews.action?new_id=<s:property value="#news.new_id"/>" target="_blank"><input type="button" value="Delete"></a>



                    </div>
                    <div class="b_c_c_home_newsdetail_edit">
                        <a href="${pageContext.request.contextPath}/news_editoneNews.action?new_id=<s:property value="#news.new_id"/>" target="_blank"><input type="button" value="Edit"></a>



                    </div>
                </div>



            </s:iterator>
            </div>
        </div>
    </div>
</div>
</body>
</html>
