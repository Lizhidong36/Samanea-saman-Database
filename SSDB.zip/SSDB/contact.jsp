<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/11
  Time: 9:33
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/contact.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/contact_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/contact_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/contact_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/contact.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/contact_6.css">');
        }
    </script>
</head>
<body>

<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <%--body_center--%>
    <div id="body_center">
        <div class="body_center_top">
            <p class="b_c_t_p1">Contact Us</p>
        </div>
        <div class="body_center_bottom">
            <span class="b_c_b_contact">If you have any comments or questions, please contact with:</span>
            <p>feichen@hainanu.edu.cn or 1161550379@qq.com</p>



            <span class="b_c_b_intro">Bioinformatics and Artificial Intelligence Laboratory</span>

            <p></p>

            <span class="b_c_b_intro">Addres: 58 Renmin Avenue, Haikou 570228, Hainan, P.R. China.</span>
        </div>
    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
