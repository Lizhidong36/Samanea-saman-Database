<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/12/14
  Time: 下午7:05
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Pathway</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/pathwaylist_2_4.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/pathwaylist_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/pathwaylist_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/pathwaylist.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/pathwaylist_6.css">');
        }
    </script>
</head>
<body>

<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <%--body_center--%>
    <div id="body_center">
        <div class="body_center_top">
            <p class="b_c_t_p1">Pathway &nbsp;Maps</p>
        </div>
        <div class="body_center_bottom">
            <p class="b_c_t_p2">1. Metabolism</p>
<%--            <p class="b_c_t_p2">1.1 Global and overview maps</p>--%>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko01200" target="_blank">01200</a> Carbon metabolism</p>--%>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko01210" target="_blank">01210</a> 2-Oxocarboxylic acid metabolism</p>--%>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko01212" target="_blank">01212</a> Fatty acid metabolism</p>--%>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko01230" target="_blank">01230</a> Biosynthesis of amino acids</p>--%>
            <p class="b_c_t_p2">1.1 Carbohydrate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00010" target="_blank">00010</a> Glycolysis / Gluconeogenesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00020" target="_blank">00020</a> Citrate cycle (TCA cycle)</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00030" target="_blank">00030</a> Pentose phosphate pathway</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00040" target="_blank">00040</a> Pentose and glucuronate interconversions</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00051" target="_blank">00051</a> Fructose and mannose metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00052" target="_blank">00052</a> Galactose metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00053" target="_blank">00053</a> Ascorbate and aldarate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00500" target="_blank">00500</a> Starch and sucrose metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00520" target="_blank">00520</a> Amino sugar and nucleotide sugar metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00620" target="_blank">00620</a> Pyruvate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00630" target="_blank">00630</a> Glyoxylate and dicarboxylate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00640" target="_blank">00640</a> Propanoate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00650" target="_blank">00650</a> Butanoate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00660" target="_blank">00660</a> C5-Branched dibasic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00562" target="_blank">00562</a> Inositol phosphate metabolism</p>
            <p class="b_c_t_p2">1.2 Energy metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00190" target="_blank">00190</a> Oxidative phosphorylation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00195" target="_blank">00195</a> Photosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00196" target="_blank">00196</a> Photosynthesis - antenna proteins</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00710" target="_blank">00710</a> Carbon fixation in photosynthetic organisms</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00910" target="_blank">00910</a> Nitrogen metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00920" target="_blank">00920</a> Sulfur metabolism</p>
            <p class="b_c_t_p2">1.3 Lipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00061" target="_blank">00061</a> Fatty acid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00062" target="_blank">00062</a> Fatty acid elongation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00071" target="_blank">00071</a> Fatty acid degradation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00073" target="_blank">00073</a> Cutin, suberine and wax biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00100" target="_blank">00100</a> Steroid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00561" target="_blank">00561</a> Glycerolipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00564" target="_blank">00564</a> Glycerophospholipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00565" target="_blank">00565</a> Ether lipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00600" target="_blank">00600</a> Sphingolipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00590" target="_blank">00590</a> Arachidonic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00591" target="_blank">00591</a> Linoleic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00592" target="_blank">00592</a> alpha-Linolenic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko01040" target="_blank">01040</a> Biosynthesis of unsaturated fatty acids</p>
            <p class="b_c_t_p2">1.4 Nucleotide metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00230" target="_blank">00230</a> Purine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00240" target="_blank">00240</a> Pyrimidine metabolism</p>

            <p class="b_c_t_p2">1.5 Amino acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00250" target="_blank">00250</a> Alanine, aspartate and glutamate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00260" target="_blank">00260</a> Glycine, serine and threonine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00270" target="_blank">00270</a> Cysteine and methionine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00280" target="_blank">00280</a> Valine, leucine and isoleucine degradation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00290" target="_blank">00290</a> Valine, leucine and isoleucine biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00300" target="_blank">00300</a> Lysine biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00310" target="_blank">00310</a> Lysine degradation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00220" target="_blank">00220</a> Arginine biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00330" target="_blank">00330</a> Arginine and proline metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00340" target="_blank">00340</a> Histidine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00350" target="_blank">00350</a> Tyrosine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00360" target="_blank">00360</a> Phenylalanine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00380" target="_blank">00380</a> Tryptophan metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00400" target="_blank">00400</a> Phenylalanine, tyrosine and tryptophan biosynthesis</p>



            <p class="b_c_t_p2">1.6 Metabolism of other amino acids</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00410" target="_blank">00410</a> beta-Alanine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00430" target="_blank">00430</a> Taurine and hypotaurine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00440" target="_blank">00440</a> Phosphonate and phosphinate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00450" target="_blank">00450</a> Selenocompound metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00460" target="_blank">00460</a> Cyanoamino acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00480" target="_blank">00480</a> Glutathione metabolism</p>
            <p class="b_c_t_p2">1.7 Glycan biosynthesis and metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00510" target="_blank">00510</a> N-Glycan biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00514" target="_blank">00514</a> Other types of O-glycan biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00531" target="_blank">00531</a> Glycosaminoglycan degradation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00563" target="_blank">00563</a> Glycosylphosphatidylinositol (GPI)-anchor biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00601" target="_blank">00601</a> Glycosphingolipid biosynthesis - lacto and neolacto series</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00603" target="_blank">00603</a> Glycosphingolipid biosynthesis - globo and isoglobo series</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00604" target="_blank">00604</a> Glycosphingolipid biosynthesis - ganglio series</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00511" target="_blank">00511</a> Other glycan degradation</p>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00511" target="_blank">00511</a> Other glycan degradation</p>--%>
            <p class="b_c_t_p2">1.8 Metabolism of cofactors and vitamins</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00730" target="_blank">00730</a> Thiamine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00740" target="_blank">00740</a> Riboflavin metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00750" target="_blank">00750</a> Vitamin B6 metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00760" target="_blank">00760</a> Nicotinate and nicotinamide metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00770" target="_blank">00770</a> Pantothenate and CoA biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00780" target="_blank">00780</a> Biotin metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00785" target="_blank">00785</a> Lipoic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00790" target="_blank">00790</a> Folate biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00670" target="_blank">00670</a> One carbon pool by folate</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00860" target="_blank">00860</a> Porphyrin metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00130" target="_blank">00130</a> Ubiquinone and other terpenoid-quinone biosynthesis</p>
            <p class="b_c_t_p2">1.9 Metabolism of terpenoids and polyketides</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00900" target="_blank">00900</a> Terpenoid backbone biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00902" target="_blank">00902</a> Monoterpenoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00909" target="_blank">00909</a> Sesquiterpenoid and triterpenoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00904" target="_blank">00904</a> Diterpenoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00906" target="_blank">00906</a> Carotenoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00905" target="_blank">00905</a> Brassinosteroid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00908" target="_blank">00908</a> Zeatin biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00903" target="_blank">00903</a> Limonene and pinene degradation</p>
            <p class="b_c_t_p2">1.10 Biosynthesis of other secondary metabolites</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00940" target="_blank">00940</a> Phenylpropanoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00945" target="_blank">00945</a> Stilbenoid, diarylheptanoid and gingerol biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00941" target="_blank">00941</a> Flavonoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00944" target="_blank">00944</a> Flavone and flavonol biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00942" target="_blank">00942</a> Anthocyanin biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00943" target="_blank">00943</a> Isoflavonoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00901" target="_blank">00901</a> Indole alkaloid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00950" target="_blank">00950</a> Isoquinoline alkaloid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00960" target="_blank">00960</a> Tropane, piperidine and pyridine alkaloid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00232" target="_blank">00232</a> Caffeine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00965" target="_blank">00965</a> Betalain biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00966" target="_blank">00966</a> Glucosinolate biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00261" target="_blank">00261</a> Monobactam biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00254" target="_blank">00254</a> Aflatoxin biosynthesis</p>
            <p class="b_c_t_p2">2 Genetic Information Processing</p>
            <p class="b_c_t_p2">2.1 Transcription</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03020" target="_blank">03020</a> RNA polymerase</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03022" target="_blank">03022</a> Basal transcription factors</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03040" target="_blank">03040</a> Spliceosome</p>
            <p class="b_c_t_p2">2.2 Translation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03010" target="_blank">03010</a> Ribosome</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko00970" target="_blank">00970</a> Aminoacyl-tRNA biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03013" target="_blank">03013</a> Nucleocytoplasmic transport</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03015" target="_blank">03015</a> mRNA surveillance pathway</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03008" target="_blank">03008</a> Ribosome biogenesis in eukaryotes</p>
            <p class="b_c_t_p2">2.3 Folding, sorting and degradation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03060" target="_blank">03060</a> Protein export</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04141" target="_blank">04141</a> Protein processing in endoplasmic reticulum</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04130" target="_blank">04130</a> SNARE interactions in vesicular transport</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04120" target="_blank">04120</a> Ubiquitin mediated proteolysis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04122" target="_blank">04122</a> Sulfur relay system</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03050" target="_blank">03050</a> Proteasome</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03018" target="_blank">03018</a> RNA degradation</p>
            <p class="b_c_t_p2">2.4 Replication and repair</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03030" target="_blank">03030</a> DNA replication</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03410" target="_blank">03410</a> Base excision repair</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03420" target="_blank">03420</a> Nucleotide excision repair</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03430" target="_blank">03430</a> Mismatch repair</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03440" target="_blank">03440</a> Homologous recombination</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko03450" target="_blank">03450</a> Non-homologous end-joining</p>
            <p class="b_c_t_p2">3 Environmental Information Processing</p>
            <p class="b_c_t_p2">3.1 Membrane transport</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko02010" target="_blank">02010</a> ABC transporters</p>
            <p class="b_c_t_p2">3.2 Signal transduction</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04016" target="_blank">04016</a> MAPK signaling pathway - plant</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04070" target="_blank">04070</a> Phosphatidylinositol signaling system</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04075" target="_blank">04075</a> Plant hormone signal transduction</p>
            <p class="b_c_t_p2">4 Cellular Processes</p>
            <p class="b_c_t_p2">4.1 Transport and catabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04144" target="_blank">04144</a> Endocytosis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04145" target="_blank">04145</a> Phagosome</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04146" target="_blank">04146</a> Peroxisome</p>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04140" target="_blank">04140</a> Regulation of autophagy</p>--%>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04136" target="_blank">04136</a> Autophagy - other</p>
            <p class="b_c_t_p2">5 Organismal Systems</p>
            <p class="b_c_t_p2">5.1 Environmental adaptation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04712" target="_blank">04712</a> Circadian rhythm - plant</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_nolist.action?k_num=ko04626" target="_blank">04626</a> Plant-pathogen interaction</p>

        </div>
    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
