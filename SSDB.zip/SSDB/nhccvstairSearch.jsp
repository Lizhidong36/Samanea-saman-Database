<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/5/6
  Time: 下午8:04
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Synteny Gene Search</title>
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/literuture_24.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_24.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_24.css">');
            document.write('<link rel="stylesheet" href="css/nhccvstair_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/literuture_18.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_18.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_18.css">');
            document.write('<link rel="stylesheet" href="css/nhccvstair_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/literuture_15.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_15.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_15.css">');
            document.write('<link rel="stylesheet" href="css/nhccvstair_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/literuture.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist.css">');
            document.write('<link rel="stylesheet" href="css/nhccvstair.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/literuture_6.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_6.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_6.css">');
            document.write('<link rel="stylesheet" href="css/nhccvstair_6.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <div id="userguidelink">
        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=synteny_gene_search.zip" title="userguide and test data">
            <p class="userguidelink_p">Userguide and demo file</p>
        </a>
    </div>
    <!--body_center-->
    <div id="body_center">

        <div class="body_center_top">
            <p class="b_c_t_p1">Synteny &nbsp;&nbsp;Gene &nbsp;&nbsp;Search</p>
            <div id="s_input">
                <input type="text" id="input_search" value="<s:property value="#parameters.keyword"/>" placeholder="Gene id. Example:BraC01g032170.1">
            </div>
            <div id="s_button">
                <input type="button" value="Search">
            </div>
        </div>

        <%--<div class="body_center_bottom">
            <a href="https://pubmed.ncbi.nlm.nih.gov/<s:property value="#article.ar_link"/>" target="_blank">
        </div>--%>
        <div class="ssr_list">
            <%--<div class="ssr_list_headerid"><i>Brassica campestris</i> ssp. <i>chinensis</i></div>
            <div class="ssr_list_headernr"><i>Arabidopsis thaliana</i></div>
            <div class="ssr_list_headertype">Evalue</div>--%>
        </div>
        <%--<s:iterator value="list" var="nhccvstair">
            <div class="ssr_detail">
                <a target="_blank" href="${pageContext.request.contextPath}/literuture_onesyngeneAnno.action?g_name=<s:property value="#nhccvstair.n_nhcc"/>">

                <div class="ssr_list_star"><s:property value="#nhccvstair.n_nhcc"/></div>
                </a>
                <div class="ssr_list_end"><s:property value="#nhccvstair.n_tair"/></div>

                    <div class="ssr_list_primer"><s:property value="#nhccvstair.n_evalue"/></div>

            </div>
        </s:iterator>--%>

        <div id="page" class="page_div"></div>

    </div>
</div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<%--<script src="js/jquery.min.js"></script>--%>
<script type="text/javascript" src="js/paging.js"></script>
<script type="text/javascript">

   /* //分页
    $("#page").paging({
        pageNo:<%--<s:property value="currentPage"/>,--%>
        totalPage: <%--<s:property value="totalPage"/>,--%>
        totalSize:  <%--<s:property value="totalCount"/>,--%>
        callback: function(num) {
            var keyword =  $("#input_search").val();

            //alert(keyword);

            //alert(num);
            $(window).attr('location','<%--${pageContext.request.contextPath}--%>/literuture_synlist.action?currPage='+num+'&keyword='+keyword);
        }
    });*/

    $("#s_button").click(function () {

        var keyword =  $("#input_search").val();

        //alert(keyword);
        <%--$(window).attr('location','${pageContext.request.contextPath}/literuture_synlist.action?keyword='+keyword);  即得放开--%>
    });

</script>

<%@include file="footer.jsp"%>
</body>
</html>
