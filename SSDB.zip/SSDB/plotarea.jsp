<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/3/7
  Time: 下午8:23
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <style>
        body{
            padding-top: 60px;

            text-align: center;
        }
    </style>
</head>
<body>

<%--<img src="img/box.png" alt="">--%>

</body>
</html>
