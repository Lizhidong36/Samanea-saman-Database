<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/11
  Time: 9:50
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java"
         pageEncoding="UTF-8"%>
<%@taglib uri="/struts-tags" prefix="s"%>
<%--<%
    String ctx = request.getContextPath();
    pageContext.setAttribute("ctx", ctx);
%>--%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Literature</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/literuture.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/pageStyle.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/literuture_24.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/literuture_18.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/literuture_15.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/literuture.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/literuture_6.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_6.css">');
        }
    </script>

</head>
<body>

<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <!--body_center-->
    <div id="body_center">

        <div class="body_center_top">
            <p class="b_c_t_p1">Article</p>
            <div id="s_input">
                <input type="text" id="input_search" value="<s:property value="#parameters.keyword"/>" placeholder="enter keywords">
            </div>
            <div id="s_button">
                <input type="button" value="Search">
            </div>
        </div>

        <s:iterator value="list" var="article">
            <div class="body_center_bottom">
                <a href="https://pubmed.ncbi.nlm.nih.gov/<s:property value="#article.ar_link"/>" target="_blank">
                    <div class="title">
                        <s:property value="#article.ar_title"/>
                    </div>
                </a>
                <div class="author"><s:property value="#article.ar_author"/>.</div>


                <div class="journal"><s:property value="#article.ar_journal"/></div>
            </div>
        </s:iterator>



        <div id="page" class="page_div"></div>

    </div>
</div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<%--<script src="js/jquery.min.js"></script>--%>
<script type="text/javascript" src="js/paging.js"></script>
<script type="text/javascript">

    //分页
    $("#page").paging({
        pageNo:<s:property value="currentPage"/>,
        totalPage: <s:property value="totalPage"/>,
        totalSize:  <s:property value="totalCount"/>,
        callback: function(num) {
            var keyword =  $("#input_search").val();

            //alert(keyword);

            //alert(num);
            $(window).attr('location','${pageContext.request.contextPath}/literuture_list.action?currPage='+num+'&keyword='+keyword);
        }
    });

    $("#s_button").click(function () {

       var keyword =  $("#input_search").val();

       //alert(keyword);
        $(window).attr('location','${pageContext.request.contextPath}/literuture_list.action?keyword='+keyword);
    });

</script>

<%@include file="footer.jsp"%>
</body>
</html>
