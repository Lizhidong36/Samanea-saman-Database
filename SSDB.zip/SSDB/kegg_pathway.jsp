<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/20
  Time: 下午5:17
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <link rel="stylesheet" href="css/kegg_pathway.css">
</head>
<body>
<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <div class="body_center">
        <form action="#">

            <div class="form_top">
                <p>KEGG &nbsp;&nbsp;PATHWAY</p>
            </div>

            <div class="form_type">
                <p>To search for publications enter keywords in the text boxes below.
                    You can limit your search by selecting the field in the dropdown box.
                    If you have any questions or suggestions, please contact us. Thank you
                    for using NOGR.
                </p>
            </div>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter KO Number:</p>
                    <input id="blastResId" type="text" placeholder="Enter KO Number; For Example: K04494">
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit KO Pathway Search:</p>
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>


        </form>
    </div>
</div>

<!--footer-->
<%@include file="footer.jsp"%>


<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {


        $(".blast_sb").click(function () {
            var koNum = $("#blastResId").val();


            $(window).attr('location','https://www.kegg.jp/kegg-bin/search_pathway_text?map=map&keyword=' + koNum + '&mode=1&viewImage=true');


        });


    });
</script>

</body>
</html>
