<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/10
  Time: 21:46
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="/struts-tags" prefix="s"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/textselect.css">--%>
    <link rel="stylesheet" href="css/style.css">

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/header_24.css">');
            document.write('<link rel="stylesheet" href="css/login_24.css">');
            document.write('<link rel="stylesheet" href="css/textselect_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/header_18.css">');
            document.write('<link rel="stylesheet" href="css/login_18.css">');
            document.write('<link rel="stylesheet" href="css/textselect_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/header_15.css">');
            document.write('<link rel="stylesheet" href="css/login_15.css">');
            document.write('<link rel="stylesheet" href="css/textselect_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/header.css">');
            document.write('<link rel="stylesheet" href="css/login.css">');
            document.write('<link rel="stylesheet" href="css/textselect.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/header_6.css">');
            document.write('<link rel="stylesheet" href="css/login_6.css">');
            document.write('<link rel="stylesheet" href="css/textselect_6.css">');
        }
    </script>


</head>
<body>
<!--header-->
<div id="header">
    <!--header_top-->
    <div class="header_top">
        <div class="header_top_center">
            <div class="header_top_center_left">
                Welcome to
                <p id="first_word">T</p>
                <p id="two_word">B</p>
                <p id="third_word">I</p>
                <p id="four_word">R</p>
            </div>

            <div class="header_top_center_right">

                <a href="index.jsp">Home</a>
                <a href="rejist222.jsp">Regist</a>
            </div>
        </div>

        <div class="header_body">

            <div class="header_body_center">
                <div class="header_body_center_left">
                    <%--<img src="image/DSC_3302.JPG">--%>
                        <img src="image/titlelogo8.jpg">
                </div>

                <div class="header_body_center_center">
                    <p>The &nbsp;&nbsp;<i>Brassicaceae</i> &nbsp;&nbsp;Information &nbsp;&nbsp;Resources</p>
                    <%--<p>&nbsp;V1.0</p>--%>
                </div>

                <div class="header_body_center_right">
                    <div id="container">
                        <div id="content">
                            <div class="first">
                                <form target="_blank" id="head_blast_form" action="${pageContext.request.contextPath}/searchkeyAction_keywordsearch.action" method="post"  enctype="multipart/form-data">
                                    <input name="searchkeyword" id="kw" placeholder="Search TBIR" onkeyup="getContent(this);">
                                    <div class="icon-zoom-in"></div>
                                </form>


                            </div>
                            <div id="append"></div>
                        </div>
                    </div>
                    <%-- <div class="r_but">
                         <input  type="button" value="Search">
                     </div>--%>
                </div>


            </div>

        </div>
    </div>
</div>
<!--body-->
<div id="body">
    <div class="body_center">
        <div class="body_center_left">

            <span id="erroe_infor" style="color:red"><s:actionerror></s:actionerror></span>


            <form action="${pageContext.request.contextPath}/LoginAction_login.action" method="post">
                <div>
                    <label>Username</label>
                    <input   name="username" id="username" type="text" placeholder="Enter your username">
                </div>
                <div>
                    <label>Password</label>
                    <input name="password" id="password" type="password" placeholder="Enter your passwrd">
                </div>
                <div class="submit_button">
                    <input type="submit" value="Login">
                </div>
            </form>
        </div>
        <div class="body_center_right">
            <div class="body_center_right_cen">
                <%--<img src="image/DSC_3307.JPG">--%>
                    <img src="image/Brassica_pekinensis.jpg">
            </div>
        </div>
    </div>
</div>
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript" src="js/selecttet.js"></script>
<script type="text/javascript">
    $(function () {

        $(".icon-zoom-in").click(function () {

            $("#head_blast_form").submit();
        });
    });


</script>
</body>
</html>
