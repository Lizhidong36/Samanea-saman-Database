<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/8/5
  Time: 11:24
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%--<%@include file="header.jsp"%>--%>
<%
    String ctx = request.getContextPath();
    pageContext.setAttribute("ctx", ctx);
%>
<html>
<head>
    <title>Submit</title>
    <%--<link rel="stylesheet" href="css/submitStyle.css">
    <link rel="stylesheet" href="css/submit.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/submitStyle_24.css">');
            document.write('<link rel="stylesheet" href="css/submit_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/submitStyle_18.css">');
            document.write('<link rel="stylesheet" href="css/submit_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/submitStyle_15.css">');
            document.write('<link rel="stylesheet" href="css/submit_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/submitStyle.css">');
            document.write('<link rel="stylesheet" href="css/submit.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/submitStyle_6.css">');
            document.write('<link rel="stylesheet" href="css/submit_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>


    <script type="text/javascript" charset="utf-8" src="${ctx }/js/umedit/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="${ctx }/js/umedit/ueditor.all.min.js"> </script>
    <script type="text/javascript" charset="utf-8" src="${ctx }/js/umedit/lang/zh-cn/zh-cn.js"></script>
</head>
<%@include file="header.jsp"%>
<body>


<div id="body">
    <div id="body_center">
        <div class="b_c_center">
            <div class="sub_title">Data &nbsp;Submission</div>
            <div class="sub_note">
                <p>We encourage users of hortDB to share their data with the research community.
                    You can submit your data by filling in the following contents.
                    Please be sure to fill in your contact information.
                    If you have any questions or suggestions, please contact us.
                    Thank you for using hortDB.
                </p>
                <p></p>
            </div>

            <form id="blog_form" action="${ctx}/SubmitData_add.action" method="post"  enctype="multipart/form-data">
            <div class="sub_desc">
                <p class="sub_title_p">Describe:</p>
                <textarea name="sub_describe" class="sub_desc_tex" placeholder="Enter Upload Content Describe"></textarea>
            </div>
<%--            <div class="sub_them">--%>
<%--                <p class="sub_title_p">Title:</p>--%>
<%--                <input name="sub_title" type="text" class="sub_them_inp" placeholder="Enter Upload Title">--%>
<%--            </div>--%>
<%--            <div class="sub_cate">--%>
<%--                <p class="sub_title_p">Category:</p>--%>
<%--                <select class="sub_cate_se1" name="sub_categorypar">--%>
<%--                    &lt;%&ndash;<option>aaaa</option>--%>
<%--                    <option>bbbb</option>--%>
<%--                    <option>cccc</option>&ndash;%&gt;--%>
<%--                </select>--%>
<%--                <select class="sub_cate_se2" name="sub_categoryson">--%>
<%--                    &lt;%&ndash; <option>aaaa</option>--%>
<%--                     <option>bbbb</option>--%>
<%--                     <option>cccc</option>&ndash;%&gt;--%>
<%--                </select>--%>
<%--            </div>--%>
            <div class="sub_file">
                <p class="sub_title_p">File Or Picture:</p>
                <input type="file" name="upload" id="fileupload"/>
                <img src="" id="imageview" class="item1_img" style="display: none;" >
            </div>

            <div class="sub_pub">
                <p class="sub_title_p">Publication:</p>
                <input name="sub_pubTitle" type="text" class="sub_pub_inp" placeholder="Enter Publication title">
                <input name="sub_pubLink" type="text" class="sub_pub_inp2" placeholder="Enter Publication link">
            </div>

            <div class="sub_autorInf">
                <p class="sub_title_p">Contact Information:</p>
                <input name="sub_unit" type="text" class="sub_autorInf_inp" placeholder="Enter Your Work Laboratory">
                <input name="sub_email" type="text" class="sub_autorInf_inp2" placeholder="Enter Your Email">
            </div>
            <div id="editor" name="sub_content" style="height:450px;"></div>
            <%--<div id="editor" name="sub_content" style="width:936px;height:450px;"></div>--%>

            <div class="sub_btn">
                <p class="sub_title_p">Submit:</p>
                <input type="button" value="Submit" id="send">
            </div>

            </form>

        </div>
    </div>
</div>

<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        var ue = UE.getEditor('editor');

        $.post('${pageContext.request.contextPath}/Category_list.action?pid=0',function (data) {

            console.log(data);
            $(data).each(function (i,obj) {
                console.log(obj.cate_name);
                $(".sub_cate_se1").append("<option value="+obj.cate_id+">"+obj.cate_name+"</option>");
            });

                $(".sub_cate_se1").trigger("change");

        },"json");


        $(".sub_cate_se1").on("change",function () {

            var cate_id =  $(".sub_cate_se1").val();
            //alert(cate_id);
            $.post('${pageContext.request.contextPath}/Category_sonlist.action?cate_id='+cate_id,function (data) {

                console.log(data);
                $(".sub_cate_se2").empty();
                $(data).each(function (i,obj) {
                    console.log(obj.cate_name);

                    $(".sub_cate_se2").append("<option value="+obj.cate_id+">"+obj.cate_name+"</option>");
                });

            },"json");
        });

        $("#fileupload").change(function() {
            var $file = $(this);
            var objUrl = $file[0].files[0];
            //获得一个http格式的url路径:mozilla(firefox)||webkit or chrome
            var windowURL = window.URL || window.webkitURL;
            //createObjectURL创建一个指向该参数对象(图片)的URL
            var dataURL;
            dataURL = windowURL.createObjectURL(objUrl);
            $("#imageview").attr("src",dataURL);
            console.log($('#imageview').attr('style'));
            if($('#imageview').attr('style') === 'display: none;'){
                $('#imageview').attr('style','inline');
                $('#imageview').width("200px");
                $('#imageview').height("200px");
                $('.update_pic').attr('style', 'margin-bottom: 150px;');
            }
        });

        $("#send").click(function () {

            alert('Submit Data!');

            $("#blog_form").submit();

        });
    });
</script>

<%@include file="footer.jsp"%>
</body>
</html>
