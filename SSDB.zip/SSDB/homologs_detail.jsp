<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/4/30
  Time: 上午10:15
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Homologs</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/literuture_24.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_24.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_24.css">');
            document.write('<link rel="stylesheet" href="css/homologs_detail_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/literuture_18.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_18.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_18.css">');
            document.write('<link rel="stylesheet" href="css/homologs_detail_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/literuture_15.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_15.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_15.css">');
            document.write('<link rel="stylesheet" href="css/homologs_detail_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/literuture.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist.css">');
            document.write('<link rel="stylesheet" href="css/homologs_detail.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/literuture_6.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_6.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_6.css">');
            document.write('<link rel="stylesheet" href="css/homologs_detail_6.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <!--body_center-->
    <div id="body_center">

        <div class="body_center_top">
            <p class="b_c_t_p1">Orthogroup: &nbsp;&nbsp;<s:property value="#session.ho_group"/></p>
<%--            <div id="s_input">--%>
<%--                <input type="text" id="input_search" value="<s:property value="#parameters.keyword"/>" placeholder="Example:WRKY,BraC01g000010.1">--%>
<%--            </div>--%>
<%--            <div id="s_button">--%>
<%--                <input type="button" value="Search">--%>
<%--            </div>--%>
        </div>


        <%--<div class="body_center_bottom">
            <a href="https://pubmed.ncbi.nlm.nih.gov/<s:property value="#article.ar_link"/>" target="_blank">
        </div>--%>
        <div class="ssr_list">
<%--            <div class="ssr_list_headerid"><i>B. campestris</i> NHCC001</div>--%>
            <div class="ssr_list_headerid">NHCC001</div>
            <div class="ssr_list_headernr"><i>N. officinale</i></div>
            <div class="ssr_list_headertype"><i>B. rapa</i></div>
            <div class="ssr_list_headerssr"><i>B. juncea</i></div>
            <div class="ssr_list_headersize"><i>B. oleracea</i></div>
            <div class="ssr_list_headersize"><i>B. napus</i></div>
<%--            <div class="ssr_list_headerstart">Swissprot</div>--%>
<%--            <div class="ssr_list_headerend">TrEMBL</div>--%>
<%--            <div class="ssr_list_headerprimer">NR</div>--%>
            <div class="ssr_list_headerprimer"><i>A. thaliana</i></div>
        </div>
        <s:iterator value="tflist" var="homologs_detail">
            <div class="ssr_detail">

                <map name="hotpoint" id="hotpoint" >
                <a href="#" >
                    <div class="ssr_list_ID geneidlist" name='<s:property value="#homologs_detail.ho_nhcc" />'>
                        <s:property value="#homologs_detail.ho_nhcc_num" />
                    </div>
                </a>

                <a href="#" >
                    <div class="ssr_list_nr geneidlist" name='<s:property value="#homologs_detail.ho_dbc" />'>

                        <s:property value="#homologs_detail.ho_dbc_num" />
                    </div>
                </a>

                <a href="#" >
                    <div class="ssr_list_type geneidlist" name="<s:property value="#homologs_detail.ho_bra" />">
                        <s:property value="#homologs_detail.ho_bra_num" />
                    </div>
                </a>

                <a href="#" >
                    <div class="ssr_list_SSR geneidlist" name="<s:property value="#homologs_detail.ho_bju" />">
                        <s:property value="#homologs_detail.ho_bju_num" />
                    </div>
                </a>

                <a href="#" >
                    <div class="ssr_list_size geneidlist" name="<s:property value="#homologs_detail.ho_bol" />">
                        <s:property value="#homologs_detail.ho_bol_num" />
                    </div>
                </a>

                    <a href="#" >
                        <div class="ssr_list_size geneidlist" name="<s:property value="#homologs_detail.ho_bna" />">
                            <s:property value="#homologs_detail.ho_bna_num" />
                        </div>
                    </a>



                <a href="#" >
                    <div class="ssr_list_primer geneidlist" name="<s:property value="#homologs_detail.ho_ath" />">
                        <s:property value="#homologs_detail.ho_ath_num" />
                    </div>
                </a>

                </map>

            </div>

        <br>


        <div class="ssr_list">
            <div class="ssr_list_headerid">Total</div>
            <div class="ssr_list_headernr">Tree</div>

            <%--            <div class="ssr_list_headerstart">Swissprot</div>--%>
            <%--            <div class="ssr_list_headerend">TrEMBL</div>--%>
            <%--            <div class="ssr_list_headerprimer">NR</div>--%>
            <div class="ssr_list_headerprimer">Download</div>
        </div>
        <div class="ssr_detail">
            <a href="#">
                <div class="ssr_list_ID"><s:property value="#homologs_detail.ho_total_num" /></div>
            </a>

            <a href="http://101.35.163.27:8080/DEGS_war_exploded/getP_treedetail?treegroup=<s:property value="#homologs_detail.ho_group" />" target="_blank">
                <div class="ssr_list_nr icon-eye"></div>
            </a>





<%--            <a href="${pageContext.request.contextPath}/download_down.action?fileName=<s:property value="#homologs_detail.ho_group" />.fa">--%>
<%--                <div class="ssr_list_primer icon-download2"></div>--%>
<%--            </a>--%>

        </div>


        </s:iterator>
        <div class="wrap"     style="font-family: 'Roboto', sans-serif;"><ul></ul></div>
    </div>
</div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<%--<script src="js/jquery.min.js"></script>--%>
<%--<script type="text/javascript" src="js/paging.js"></script>--%>
<script type="text/javascript">
    $(function(){
        $(".wrap").hide();
        $(".geneidlist").mouseover(function(e){
            e.stopPropagation();
            var pros=$(this).attr("name");
            var proarr=pros.split(', ');
            pros="";
            var speciespep="";


            // for(var i=0;i<proarr.length;i++){
            //     pros+="<li>"+proarr[i]+"</li>";
            // }

            for(var i=0;i<proarr.length;i++){
                if (proarr[0].indexOf("BraC") != -1){

                    speciespep="Brassica_campestris_ssp.chinensis_Cultivar_NHCC001_gene.gff3.pep";
                       }
                if (proarr[0].indexOf("Noff") != -1){

                    speciespep="Nasturtium_officinale.pep";
                }
                if (proarr[0].indexOf("BraA") != -1){

                    speciespep="Brapa_genome_v3.0_pep.fasta";
                }
                if (proarr[0].indexOf("Bju") != -1){

                    speciespep="B_juncea_v1.5_pep.fa";
                }
                if (proarr[0].indexOf("Bol") != -1){

                    speciespep="B.oleracea_v1.0.chromosomes.pep";
                }
                if (proarr[0].indexOf("GSB") != -1){

                    speciespep="B_napus_Darmor_bzh_pep.fa";
                }
                if (proarr[0].indexOf("AT") != -1){

                    speciespep="Arabidopsis_thaliana_v10_pep.txt";
                }
                pros+="<a href="+"${pageContext.request.contextPath}/BatchQuery_list.action?organism_type="+speciespep+'&content='+proarr[i]+" target='_blank'><li>"+proarr[i]+"</li></a>";

            }



            $(".wrap ul").html(pros);
            $(".wrap").css({top:e.pageY,left:e.pageX}).show();

            $(".wrap li").mouseover(function(){
                this.style.cursor="pointer";
                this.style.borderBottom="1px dotted #999999";
                this.style.color="orangered";
            });
            $(".wrap li").mouseout(function(){
                this.style.borderBottom="";
                this.style.color="blue";
            });

        })



        $("#body_center").click(function () { $(".wrap").hide() });


        $("#pathwayimg").load(function() {
            var len=$(this).width();
            if (len>900)
            {
                $(".main").width(len);
                $(".footer").width(len);
            }
        });
    })

</script>

<%@include file="footer.jsp"%>


</body>
</html>
