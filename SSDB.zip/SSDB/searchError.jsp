<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/11/6
  Time: 下午5:35
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>

<h2>There were no results matching the query.</h2>
</body>
</html>
