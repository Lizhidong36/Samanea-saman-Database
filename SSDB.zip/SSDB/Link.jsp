<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/8/27
  Time: 9:47
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Link</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/news.css">
    <link rel="stylesheet" href="css/Link.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/news_24.css">');
            document.write('<link rel="stylesheet" href="css/Link_24.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/news_18.css">');
            document.write('<link rel="stylesheet" href="css/Link_18.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/news_15.css">');
            document.write('<link rel="stylesheet" href="css/Link_15.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/news.css">');
            document.write('<link rel="stylesheet" href="css/Link.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/news_6.css">');
            document.write('<link rel="stylesheet" href="css/Link_6.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>
</head>
<body>

<%@include file="header.jsp"%>

<%--<div id="body">
                <span class="geno">Gene expression</span>

                    <a href="http://www.plantgdb.org/prj/PLEXdb/" target="_blank">
                        PLEXdb
                    </a>
                    <a href="https://www.ebi.ac.uk/arrayexpress/" target="_blank">
                        ArrayExpress
                    </a>
                <span class="geno">Gene Indices and EST resources</span>
                    <a href="http://www.plantgdb.org/prj/PLEXdb/" target="_blank">
                        The Gene Index project
                    </a>
</div>--%>

<div id="body">
    <!--body_center-->
    <div id="body_center">
        <div class="body_center_center">
            <div class="body_center_center_top">
                <p>Link</p>
            </div>
            <div class="body_center_center_bottom">

                <div class="linksource">
                    <div class="linkName">Arabis alpina</div>
                    <div class="linkurl">
                        <a href="http://www.arabis-alpina.org/index.html" target="_blank">
                            <span class="icon-home3"></span>
                        Genomic resources for <i>Arabis alpina</i>
                        </a>
                    </div>

                </div>


                <div class="linksource">
                    <div class="linkName">Arabidopsis thaliana</div>
                    <div class="linkurl">
                        <a href="https://www.arabidopsis.org/" target="_blank">
                            <span class="icon-home3"></span>
                            The <i>Arabidopsis</i> Information Resource (TAIR)
                        </a>
                    </div>

                </div>


                <div class="linksource">
                    <div class="linkName">Brassica napus</div>
                    <div class="linkurl">
                        <a href="http://www.genoscope.cns.fr/brassicanapus/" target="_blank">
                            <span class="icon-home3"></span>
                            <i>Brassica napus</i> Genome Resources
                        </a>
                        <br>
                        <a href="http://cbi.hzau.edu.cn/bnapus/" target="_blank">
                            <span class="icon-home3"></span>
                            <i>Brassica napus</i> pan-genome information resource (BnIR)
                        </a>
                    </div>
                </div>

                <div class="linksource">
                    <div class="linkName">Brassica oleracea</div>
                    <div class="linkurl">
                        <a href="http://www.ocri-genomics.org/bolbase/index.html" target="_blank">
                            <span class="icon-home3"></span>
                            Bolbase
                        </a>
                    </div>

                </div>

                <div class="linksource">
                    <div class="linkName">Brassica rapa</div>
                    <div class="linkurl">
                        <a href="http://brassicadb.org/brad/index.php" target="_blank">
                            <span class="icon-home3"></span>
                            Brassica database (BRAD)
                        </a>
                    </div>

                </div>

                <div class="linksource">
                    <div class="linkName">Barbarea vulgaris</div>
                    <div class="linkurl">
                        <a href="http://185.45.23.197:5080/Barbarea.html" target="_blank">
                            <span class="icon-home3"></span>
                            <i>Barbarea vulgaris</i> Genome Database
                        </a>
                    </div>

                </div>

                <div class="linksource">
                    <div class="linkName">Raphanus raphanistrum</div>
                    <div class="linkurl">
                        <a href="http://radish.plantbiology.msu.edu/index.php?title=Main_Page" target="_blank">
                            <span class="icon-home3"></span>
                            RadishDB
                        </a>
                    </div>

                </div>

                <div class="linksource">
                    <div class="linkName">Raphanus sativus</div>
                    <div class="linkurl">
                        <a href="http://radish.kazusa.or.jp/" target="_blank">
                            <span class="icon-home3"></span>
                            <i>Raphanus sativus</i> Genome DataBase
                        </a>
                        <br>
                        <a href="http://radish-genome.org/Data_resource/index.php" target="_blank">
                            <span class="icon-home3"></span>
                            Radish genome database (RadishGD)
                        </a>
                        <br>
                        <a href="http://www.nodai-genome-d.org/download.html" target="_blank">
                            <span class="icon-home3"></span>
                            NODAI Radish genome database
                        </a>
                    </div>
                </div>


                <div class="linksource">
                    <div class="linkName">Cucurbitaceae</div>
                    <div class="linkurl">
                        <a href="http://cucurbitgenomics.org/" target="_blank">
                            <span class="icon-home3"></span>
                            CuGenDB
                        </a>
                    </div>

                </div>

                <div class="linksource">
                    <div class="linkName">Rosaceae</div>
                    <div class="linkurl">
                        <a href="https://www.rosaceae.org/" target="_blank">
                            <span class="icon-home3"></span>
                            GDR
                        </a>
                    </div>

                </div>

                <div class="linksource">
                    <div class="linkName">Malvaceae Juss.</div>
                    <div class="linkurl">
                        <a href="http://magen.whu.edu.cn/" target="_blank">
                            <span class="icon-home3"></span>
                            MaGenDB
                        </a>
                    </div>

                </div>

                <div class="linksource">
                    <div class="linkName">Apiaceae Lindl.</div>
                    <div class="linkurl">
                        <a href="http://cgdb.bio2db.com/" target="_blank">
                            <span class="icon-home3"></span>
                            Coriander Genome Database (CGDB)
                        </a>
                    </div>

                </div>

                <div class="linksource">
                    <div class="linkName">Juglandaceae</div>
                    <div class="linkurl">
                        <a href="http://www.juglandaceae.net/" target="_blank">
                            <span class="icon-home3"></span>
                            Portal of Juglandaceae (PJU)
                        </a>
                    </div>

                </div>


                <div class="linksource">
                    <div class="linkName">Plant Gemome </div>
                    <div class="linkurl">
                        <a href="https://phytozome.jgi.doe.gov/pz/portal.html" target="_blank">
                            <span class="icon-home3"></span>
                            Phytozome
                        </a>
                        <br>
                        <a href="http://plants.ensembl.org/index.html" target="_blank">
                            <span class="icon-home3"></span>
                            Ensembl Plants
                        </a>
                        <br>
                        <a href="https://www.ncbi.nlm.nih.gov/genome/?term=" target="_blank">
                            <span class="icon-home3"></span>
                            NCBI Genome
                        </a>
                        <br>
                        <a href="http://www.plantgdb.org/prj/PLEXdb/" target="_blank">
                            <span class="icon-home3"></span>
                            PlantGDB
                        </a>
                        <br>
                        <a href="https://genomevolution.org/coge/" target="_blank">
                            <span class="icon-home3"></span>
                            CoGe
                        </a>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<%@include file="footer.jsp"%>
</body>
</html>
