<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/10/26
  Time: 下午3:02
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/back_AddRecentUpdate.css">
</head>
<body>

<%@include file="backHeader.jsp"%>
<div id="body">
    <div class="body_center">
        <div class="body_center_center">

            <div class="b_c_c_top">
                <p>Add &nbsp;Recent &nbsp;Update</p>
            </div>

            <form action="${pageContext.request.contextPath}/recentUpdate_addOneUpdate.action">

                <div class="b_c_c_describe">
                    <p>Update Describe:</p>
                    <textarea class="news_desc" name="re_desc"></textarea>

                </div>

                <div class="b_c_c_date">
                    <p>Date:</p>
                    <input type="text" class="new_data" name="re_date">
                </div>

                <div class="b_c_c_detail">
                    <p>Update Link:</p>
                    <textarea class="news_detail" name="re_link"></textarea>
                </div>

                <div class="b_c_c_submit">
                    <p>Save:</p>
                    <input type="submit" value="Save" class="save">
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
