<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/10/25
  Time: 上午9:48
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/back_EditNews.css">
</head>
<body>

<%@include file="backHeader.jsp"%>
<%--body--%>
<div id="body">
    <div class="body_center">
        <div class="body_center_center">
            <div class="b_c_c_top">
                <p>Edit &nbsp;News</p>
            </div>

            <form action="${pageContext.request.contextPath}/news_UpdateOneNews.action">

                <div class="b_c_c_describe">
                    <p>News Describe:</p>
                    <textarea class="news_desc" name="new_desc"><s:property value="#session.oneNews.new_desc"/></textarea>
                    <input type="text" class="new_id" name="new_id" value="<s:property value="#session.oneNews.new_id"/>">

                </div>

                <div class="b_c_c_date">
                    <p>Date:</p>
                    <input type="text" class="new_data" name="new_data" value="<s:property value="#session.oneNews.new_data"/>">
                </div>

                <div class="b_c_c_detail">
                    <p>News Detail:</p>
                    <textarea class="news_detail" name="new_detail"><s:property value="#session.oneNews.new_detail"/></textarea>
                </div>

                <div class="b_c_c_submit">
                    <p>Update:</p>
                    <input type="submit" value="Update" class="save">
                </div>
            </form>


        </div>
    </div>
</div>
</body>
</html>
