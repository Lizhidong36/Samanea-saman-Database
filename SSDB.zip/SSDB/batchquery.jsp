<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/10
  Time: 21:59
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Batch Query</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/batchquery.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/batchquery_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/batchquery_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/batchquery_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/batchquery.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/batchquery_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">
<%--    <div id="userguidelink">--%>
<%--        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=Batch_Query_1.zip" title="userguide and test data">--%>
<%--            <p class="userguidelink_p">Userguide and demo file</p>--%>
<%--        </a>--%>
<%--    </div>--%>
    <div class="body_center">
        <form id="blast_form" action="${pageContext.request.contextPath}/BatchQuery_list.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p>Batch &nbsp;Query</p>
            </div>

            <div class="form_type">
                <div class="f_t_lab">
                <p>Select Database:</p>
                <select class="blast_type" name="organism_type" >

                    <s:iterator value="allBlastFile" var="BlastFile">
                        <option value="<s:property value="#BlastFile.blast_speciesFileName"></s:property>"><s:property value="#BlastFile.balst_speciesName"></s:property> </option>
                    </s:iterator>

                    <%-- <option value="Brapa_genome_v3.0_pep.fasta">B. nigra (pep)</option>--%>
                </select>
                </div>
            </div>


            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Feature ID:</p>
                    <div id="error" style="color:red"><s:actionerror></s:actionerror></div>
                    <textarea class="blast_seq" name="content" placeholder="Paste query id(s) ...
For example:
Ssa12007152.t1
Ssa01000675.t1"></textarea>
                    <input type="file" name="upload" id="fileupload">
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Retrieve:</p>
                    <input type="button" value="Example" class="blast_example">
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>
        </form>

    </div>
</div>
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    function turn(str) {

        while (str.indexOf("\n") != -1) {
            str = str.substring(0, str.indexOf("\n")) + "<br>"
                + str.substring(str.indexOf("\n") + 1);
        }
        while (str.indexOf(" ") != -1) {
            str = str.substring(0, str.indexOf(" ")) + "\C6MC6M"
                + str.substring(str.indexOf(" ") + 1);
        }
        while (str.indexOf("|") != -1) {
            str = str.substring(0, str.indexOf("|")) + "\C9MC9M"
                + str.substring(str.indexOf("|") + 1);
        }
        while (str.indexOf("_") != -1) {
            str = str.substring(0, str.indexOf("_")) + "\C3MC3M"
                + str.substring(str.indexOf("_") + 1);
        }
        while (str.indexOf("#") != -1) {
            str = str.substring(0, str.indexOf("#")) + "\C5MC5M"
                + str.substring(str.indexOf("#") + 1);
        }
        while (str.indexOf("=") != -1) {
            str = str.substring(0, str.indexOf("=")) + "\C7MC7M"
                + str.substring(str.indexOf("=") + 1);
        }
        while (str.indexOf(".") != -1) {
            str = str.substring(0, str.indexOf(".")) + "\C8MC8M"
                + str.substring(str.indexOf(".") + 1);
        }
        while (str.indexOf("/") != -1) {
            str = str.substring(0, str.indexOf("/")) + "\C4MC4M"
                + str.substring(str.indexOf("/") + 1);
        }
        while (str.indexOf("-") != -1) {
            str = str.substring(0, str.indexOf("-")) + "\C2MC2M"
                + str.substring(str.indexOf("-") + 1);
        }
        while (str.indexOf("+") != -1) {
            str = str.substring(0, str.indexOf("+")) + "\C1MC1M"
                + str.substring(str.indexOf("+") + 1);
        }
        while (str.indexOf(":") != -1) {
            str = str.substring(0, str.indexOf(":")) + "\M6666MM6666M"
                + str.substring(str.indexOf(":") + 1);
        }
        while (str.indexOf(";") != -1) {
            str = str.substring(0, str.indexOf(";")) + "\M1111MM1111M"
                + str.substring(str.indexOf(";") + 1);
        }
        while (str.indexOf(" ") != -1) {
            str = str.substring(0, str.indexOf(" ")) + "\M2222MM2222M"
                + str.substring(str.indexOf(" ") + 1);
        }
        while (str.indexOf("\t") != -1) {
            str = str.substring(0, str.indexOf("\t")) + "\M3333MM3333M"
                + str.substring(str.indexOf("\t") + 1);
        }
        while (str.indexOf(",") != -1) {
            str = str.substring(0, str.indexOf(",")) + "\M4444MM4444M"
                + str.substring(str.indexOf(",") + 1);
        }
        while (str.indexOf("    ") != -1) {
            str = str.substring(0, str.indexOf("    ")) + "\Cc1MCc1M"
                + str.substring(str.indexOf("   ") + 1);
        }
        return str;
    };

    $(".blast_sb").click(function () {
       var content =  $(".blast_seq").val();
       var organism_type =  $(".blast_type").val();
       var fileupload =  $("#fileupload").val();


       if(content == "" && fileupload == ""){
           alert("please input or upload sequence file!");
       }

        if(content != "" && fileupload != ""){
            alert("please input or upload sequence file!");
        }

        if(content != "" && fileupload == ""){
            cont1 = turn(content);

            var new_blast_seq = $(".blast_seq").val(cont1);

            $("#blast_form").submit();
        }

        if(content == "" && fileupload != ""){
            $("#blast_form").submit();
        }

    });

    $(".blast_example").click(function () {


        $(".blast_type").val("Samanea_saman_pep.fa");
        $(".blast_seq").val("Ssa01000675.t1\n" +
            "Ssa01002576.t1\n"
        );

    });

</script>
</body>
</html>