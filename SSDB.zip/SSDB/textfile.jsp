<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2024/4/7
  Time: 下午3:39
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
</head>
<body>
<form name="form" method="post" action="javascript:;">
    <input type="file" name="picpath" id="picpath"style="display: none;"
           onchange="document.form.path.value=this.value" multiple="multiple" accept="image/*" />
    <input name="path" readonly>
    <input type="button" value="上传照片" onclick="document.form.picpath.click()">
</form>
</body>
</html>