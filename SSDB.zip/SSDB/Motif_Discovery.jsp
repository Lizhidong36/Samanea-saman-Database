<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/1/5
  Time: 下午4:08
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Motif Discovery</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/Motif_Discovery.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Discovery_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Discovery_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Discovery_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Discovery.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Discovery_6.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>
<div id="body">

    <div id="userguidelink">
        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=Motif_Discovery_1.zip" title="userguide and test data">
            <p class="userguidelink_p">Userguide and demo file</p>
        </a>
    </div>
    <div class="body_center">
        <form id="blast_form" target="_blank" action="${pageContext.request.contextPath}/Motif_discovery.action" method="post" enctype="multipart/form-data">
            <div class="form_top">
                <p>Motif &nbsp;Discovery</p>
            </div>

            <div class="form_type">
                <div class="f_t_lab">
                    <p>Select the sequence alphabet:</p>
                    <select class="motif_type" name="motif_type">
                        <option value="dna">DNA</option>
                        <option value="rna">RNA</option>
                        <option value="protein">Protein</option>
                    </select>
                </div>
            </div>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Input the primary sequences:</p>
                    <textarea class="blast_seq" name="blast_seq" placeholder="Paste query sequence(s) in FASTA format here ...
For example:
>Bol004797
MTVLKRYVLRLFMSIKYITTNVVDKNNGRVVTTASTVEHAVKNSLECGRT
CNAKAAAILGEVLAMRLKVEGHQDGQGRGIHADVKKEIEKKGFKSRTKVW
AVINSVRNNGVTLILDDFNVDEDKYYRYRSDEGHQ"></textarea>
                    <input type="file" name="upload" id="fileupload">
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select the site distribution:</p>
                    <select class="motif_mod" name="motif_mod">
                        <option value="oops">One Occurrence Per Sequence (oops)</option>
                        <option value="zoops">Zero or One Occurrence Per Sequence (zoops)</option>
                        <option value="anr">Any Number of Repetitions (anr)</option>
                    </select>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select the number of motifs:</p>
                    <select class="motif_num" name="motif_num">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">2</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="15">15</option>
                        <option value="20">20</option>
                        <option value="35">35</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select the minimum motif width:</p>
                    <select class="motif_minWide" name="motif_minWide">
                        <option value="6">6</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">2</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="15">15</option>
                        <option value="20">20</option>
                    </select>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select the maximum motif width:</p>
                    <select class="motif_maxWide" name="motif_maxWide">
                        <option value="30">50</option>
                        <option value="30">60</option>
                        <option value="30">70</option>
                        <option value="30">80</option>
                        <option value="30">90</option>
                        <option value="30">100</option>
                        <option value="30">150</option>
                    </select>
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit Motif Discovery:</p>
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>
        </form>
    </div>
</div>
<%@include file="footer.jsp"%>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        function turn(str) {

            while (str.indexOf("\n") != -1) {
                str = str.substring(0, str.indexOf("\n")) + "<br>"
                    + str.substring(str.indexOf("\n") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\C6MC6M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("|") != -1) {
                str = str.substring(0, str.indexOf("|")) + "\C9MC9M"
                    + str.substring(str.indexOf("|") + 1);
            }
            while (str.indexOf("_") != -1) {
                str = str.substring(0, str.indexOf("_")) + "\C3MC3M"
                    + str.substring(str.indexOf("_") + 1);
            }
            while (str.indexOf("#") != -1) {
                str = str.substring(0, str.indexOf("#")) + "\C5MC5M"
                    + str.substring(str.indexOf("#") + 1);
            }
            while (str.indexOf("=") != -1) {
                str = str.substring(0, str.indexOf("=")) + "\C7MC7M"
                    + str.substring(str.indexOf("=") + 1);
            }
            while (str.indexOf(".") != -1) {
                str = str.substring(0, str.indexOf(".")) + "\C8MC8M"
                    + str.substring(str.indexOf(".") + 1);
            }
            while (str.indexOf("/") != -1) {
                str = str.substring(0, str.indexOf("/")) + "\C4MC4M"
                    + str.substring(str.indexOf("/") + 1);
            }
            while (str.indexOf("-") != -1) {
                str = str.substring(0, str.indexOf("-")) + "\C2MC2M"
                    + str.substring(str.indexOf("-") + 1);
            }
            while (str.indexOf("+") != -1) {
                str = str.substring(0, str.indexOf("+")) + "\C1MC1M"
                    + str.substring(str.indexOf("+") + 1);
            }
            while (str.indexOf(":") != -1) {
                str = str.substring(0, str.indexOf(":")) + "\M6666MM6666M"
                    + str.substring(str.indexOf(":") + 1);
            }
            while (str.indexOf(";") != -1) {
                str = str.substring(0, str.indexOf(";")) + "\M1111MM1111M"
                    + str.substring(str.indexOf(";") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\M2222MM2222M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("\t") != -1) {
                str = str.substring(0, str.indexOf("\t")) + "\M3333MM3333M"
                    + str.substring(str.indexOf("\t") + 1);
            }
            while (str.indexOf(",") != -1) {
                str = str.substring(0, str.indexOf(",")) + "\M4444MM4444M"
                    + str.substring(str.indexOf(",") + 1);
            }
            while (str.indexOf("    ") != -1) {
                str = str.substring(0, str.indexOf("    ")) + "\Cc1MCc1M"
                    + str.substring(str.indexOf("   ") + 1);
            }
            return str;
        };

        $(".blast_sb").click(function () {

            var blast_seq = $(".blast_seq").val();
            var fileupload = $("#fileupload").val();


            if(blast_seq == "" && fileupload == ""){
                alert("please upload fasta sequence file!");
            }

            if( blast_seq != "" && fileupload != ""){
                alert("please input or upload sequence file!");
            }

            if(blast_seq != "" && fileupload == ""){
                cont1 = turn(blast_seq);

                var new_blast_seq = $(".blast_seq").val(cont1);

                $("#blast_form").submit();
            }

            if(blast_seq == "" && fileupload != ""){

                $("#blast_form").submit();
            }

        });


    });
</script>

</body>
</html>
