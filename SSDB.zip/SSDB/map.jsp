<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/7/5
  Time: 下午3:09
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/map.css">
</head>
<body>


   <div class="mmp" style="width: 800px;height: 800px">
       <script type="text/javascript" src="//rf.revolvermaps.com/0/0/8.js?i=5qonczefwci&amp;m=0&amp;c=ff0000&amp;cr1=ffffff&amp;f=arial&amp;l=33&amp;s=340" async="async"></script>
   </div>


</body>
</html>
