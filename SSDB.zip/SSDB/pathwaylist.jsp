<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/12/14
  Time: 下午7:05
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Pathway</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/pathwaylist_2_4.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/pathwaylist_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/pathwaylist_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/pathwaylist.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/pathwaylist_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>
</head>
<body>

<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <%--body_center--%>
    <div id="body_center">
        <div class="body_center_top">
            <p class="b_c_t_p1">Pathway &nbsp;Maps</p>
        </div>
        <div class="body_center_bottom">
            <p class="b_c_t_p2">1. Metabolism</p>
<%--            <p class="b_c_t_p2">1.1 Global and overview maps</p>--%>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko01200" target="_blank">01200</a> Carbon metabolism</p>--%>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko01210" target="_blank">01210</a> 2-Oxocarboxylic acid metabolism</p>--%>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko01212" target="_blank">01212</a> Fatty acid metabolism</p>--%>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko01230" target="_blank">01230</a> Biosynthesis of amino acids</p>--%>
            <p class="b_c_t_p2">1.2 Carbohydrate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00010&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00010</a> Glycolysis / Gluconeogenesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00020&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00020</a> Citrate cycle (TCA cycle)</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00030&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00030</a> Pentose phosphate pathway</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00040&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00040</a> Pentose and glucuronate interconversions</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00051&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00051</a> Fructose and mannose metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00052&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00052</a> Galactose metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00053&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00053</a> Ascorbate and aldarate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00500&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00500</a> Starch and sucrose metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00520&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00520</a> Amino sugar and nucleotide sugar metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00620&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00620</a> Pyruvate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00630&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00630</a> Glyoxylate and dicarboxylate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00640&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00640</a> Propanoate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00650&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00650</a> Butanoate metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00660&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00660</a> C5-Branched dibasic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00562&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00562</a> Inositol phosphate metabolism</p>
            <p class="b_c_t_p2">1.3 Energy metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00190&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00190</a> Oxidative phosphorylation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00195&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00195</a> Photosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00196&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00196</a> Photosynthesis - antenna proteins</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00710&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00710</a> Carbon fixation in photosynthetic organisms</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00910&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00910</a> Nitrogen metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00920&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00920</a> Sulfur metabolism</p>
            <p class="b_c_t_p2">1.4 Lipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00061&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00061</a> Fatty acid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00062&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00062</a> Fatty acid elongation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00071&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00071</a> Fatty acid degradation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00073&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00073</a> Cutin, suberine and wax biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00100&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00100</a> Steroid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00561&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00561</a> Glycerolipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00564&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00564</a> Glycerophospholipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00565&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00565</a> Ether lipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00600&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00600</a> Sphingolipid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00590&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00590</a> Arachidonic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00591&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00591</a> Linoleic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00592&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00592</a> alpha-Linolenic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko01040&spe_name=<s:property value="#session.tf_species"/>" target="_blank">01040</a> Biosynthesis of unsaturated fatty acids</p>
            <p class="b_c_t_p2">1.5 Nucleotide metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00230&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00230</a> Purine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00240&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00240</a> Pyrimidine metabolism</p>
            <p class="b_c_t_p2">1.6 Metabolism of other amino acids</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00410&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00410</a> beta-Alanine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00430&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00430</a> Taurine and hypotaurine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00450&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00450</a> Selenocompound metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00460&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00460</a> Cyanoamino acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00480&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00480</a> Glutathione metabolism</p>
            <p class="b_c_t_p2">1.7 Glycan biosynthesis and metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00510&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00510</a> N-Glycan biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00514&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00514</a> Other types of O-glycan biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00531&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00531</a> Glycosaminoglycan degradation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00563&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00563</a> Glycosylphosphatidylinositol (GPI)-anchor biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00603&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00603</a> Glycosphingolipid biosynthesis - globo and isoglobo series</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00604&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00604</a> Glycosphingolipid biosynthesis - ganglio series</p>
<%--            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00511" target="_blank">00511</a> Other glycan degradation</p>--%>
            <p class="b_c_t_p2">1.8 Metabolism of cofactors and vitamins</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00730&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00730</a> Thiamine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00740&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00740</a> Riboflavin metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00750&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00750</a> Vitamin B6 metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00760&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00760</a> Nicotinate and nicotinamide metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00770&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00770</a> Pantothenate and CoA biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00780&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00780</a> Biotin metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00785&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00785</a> Lipoic acid metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00790&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00790</a> Folate biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00670&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00670</a> One carbon pool by folate</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00860&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00860</a> Porphyrin metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00130&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00130</a> Ubiquinone and other terpenoid-quinone biosynthesis</p>
            <p class="b_c_t_p2">1.9 Metabolism of terpenoids and polyketides</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00900&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00900</a> Terpenoid backbone biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00902&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00902</a> Monoterpenoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00909&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00909</a> Sesquiterpenoid and triterpenoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00904&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00904</a> Diterpenoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00906&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00906</a> Carotenoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00905&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00905</a> Brassinosteroid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00908&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00908</a> Zeatin biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00903&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00903</a> Limonene and pinene degradation</p>
            <p class="b_c_t_p2">1.10 Biosynthesis of other secondary metabolites</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00940&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00940</a> Phenylpropanoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00945&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00945</a> Stilbenoid, diarylheptanoid and gingerol biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00941&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00941</a> Flavonoid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00944&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00944</a> Flavone and flavonol biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00942&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00942</a> Anthocyanin biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00901&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00901</a> Indole alkaloid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00950&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00950</a> Isoquinoline alkaloid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00960&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00960</a> Tropane, piperidine and pyridine alkaloid biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00232&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00232</a> Caffeine metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00966&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00966</a> Glucosinolate biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00261&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00261</a> Monobactam biosynthesis</p>
            <p class="b_c_t_p2">1.11 Xenobiotics biodegradation and metabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00940&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00940</a> Phenylpropanoid biosynthesis</p>
            <p class="b_c_t_p2">2 Genetic Information Processing</p>
            <p class="b_c_t_p2">2.1 Transcription</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03020&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03020</a> RNA polymerase</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03022&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03022</a> Basal transcription factors</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03040&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03040</a> Spliceosome</p>
            <p class="b_c_t_p2">2.2 Translation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03010&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03010</a> Ribosome</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko00970&spe_name=<s:property value="#session.tf_species"/>" target="_blank">00970</a> Aminoacyl-tRNA biosynthesis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03013&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03013</a> Nucleocytoplasmic transport</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03015&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03015</a> mRNA surveillance pathway</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03008&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03008</a> Ribosome biogenesis in eukaryotes</p>
            <p class="b_c_t_p2">2.3 Folding, sorting and degradation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03060&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03060</a> Protein export</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04141&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04141</a> Protein processing in endoplasmic reticulum</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04130&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04130</a> SNARE interactions in vesicular transport</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04120&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04120</a> Ubiquitin mediated proteolysis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04122&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04122</a> Sulfur relay system</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03050&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03050</a> Proteasome</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03018&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03018</a> RNA degradation</p>
            <p class="b_c_t_p2">2.4 Replication and repair</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03030&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03030</a> DNA replication</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03410&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03410</a> Base excision repair</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03420&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03420</a> Nucleotide excision repair</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03430&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03430</a> Mismatch repair</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03440&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03440</a> Homologous recombination</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko03450&spe_name=<s:property value="#session.tf_species"/>" target="_blank">03450</a> Non-homologous end-joining</p>
            <p class="b_c_t_p2">3 Environmental Information Processing</p>
            <p class="b_c_t_p2">3.1 Membrane transport</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko02010&spe_name=<s:property value="#session.tf_species"/>" target="_blank">02010</a> ABC transporters</p>
            <p class="b_c_t_p2">3.2 Signal transduction</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04070&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04070</a> Phosphatidylinositol signaling system</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04075&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04075</a> Plant hormone signal transduction</p>
            <p class="b_c_t_p2">4 Cellular Processes</p>
            <p class="b_c_t_p2">4.1 Transport and catabolism</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04144&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04144</a> Endocytosis</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04145&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04145</a> Phagosome</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04146&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04146</a> Peroxisome</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04140&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04140</a> Regulation of autophagy</p>
            <p class="b_c_t_p2">5 Organismal Systems</p>
            <p class="b_c_t_p2">5.1 Environmental adaptation</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04712&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04712</a> Circadian rhythm - plant</p>
            <p class="b_c_t_p3"><a href="${pageContext.request.contextPath}/getPathwaydetail_list.action?k_num=ko04626&spe_name=<s:property value="#session.tf_species"/>" target="_blank">04626</a> Plant-pathogen interaction</p>

        </div>
    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
