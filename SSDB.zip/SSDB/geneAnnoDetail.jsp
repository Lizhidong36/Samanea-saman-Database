<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/5/3
  Time: 下午2:57
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Gene Function</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoDetail_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoDetail_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoDetail_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoDetail.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoDetail_6.css">');
        }
    </script>
</head>
<body>

<%@include file="header.jsp"%>

<!--body-->
<div id="body">

<s:iterator value="tflist" var="geneannt">
    <div class="body_center">
        <form target="_blank" id="blast_form">
            <div class="form_top">
                <p><s:property value="#geneannt.g_name" /></p>
<%--                <p><s:property value="#session.onessrtitle"/></p>--%>

            </div>
<%--<s:iterator value="tflist" var="geneannt">--%>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>GO:</p>
                    <textarea  class="blast_seq" name="blast_seq"><s:property value="#geneannt.g_go" /></textarea>
                </div>
            </div>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>KEGG:</p>
                    <textarea  class="blast_seq" name="blast_seq"><s:property value="#geneannt.g_keggs" /></textarea>
                </div>
            </div>
            <%--<div class="form_seq">
                <div class="f_t_lab">
                    <p>KOG:</p>
                    <textarea  class="blast_seq" name="blast_seq"><s:property value="#geneannt.g_kog" /></textarea>
                </div>
            </div>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>KOG class:</p>
                    <textarea  class="blast_seq" name="blast_seq"><s:property value="#geneannt.g_kogclass" /></textarea>
                </div>
            </div>--%>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Pfam:</p>
                    <textarea  class="blast_seq" name="blast_seq"><s:property value="#geneannt.g_pfams" /></textarea>
                </div>
            </div>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Swissprot:</p>
                    <textarea  class="blast_seq" name="blast_seq"><s:property value="#geneannt.g_swiss" /></textarea>
                </div>
            </div>
            <%--<div class="form_seq">
                <div class="f_t_lab">
                    <p>TrEMBL:</p>
                    <textarea  class="blast_seq" name="blast_seq"><s:property value="#geneannt.g_tre" /></textarea>
                </div>
            </div>--%>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>NR:</p>
                    <textarea  class="blast_seq" name="blast_seq"><s:property value="#geneannt.g_nr" /></textarea>
                </div>
            </div>
           <%-- <div class="form_seq">
                <div class="f_t_lab">
                    <p>NT:</p>
                    <textarea  class="blast_seq" name="blast_seq"><s:property value="#geneannt.g_nt" /></textarea>
                </div>
            </div>--%>


            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Sequences:</p>
                    <a href="${pageContext.request.contextPath}/BatchQuery_list.action?organism_type=<s:property value="#session.cds_file"/>&content=<s:property value="#geneannt.g_name" />" target="_blank">
                        <input type="button" value="CDS" class="blast_sb">
                    </a>
                    <a href="${pageContext.request.contextPath}/BatchQuery_list.action?organism_type=<s:property value="#session.pep_file"/>&content=<s:property value="#geneannt.g_name" />" target="_blank">
                        <input type="button" value="PEP" class="blast_sb">
                    </a>
                    <a href="<s:property value="#session.jbrowse_link"/>&loc=<s:property value="#geneannt.g_name" />&tracks=DNA%2CGFF3%20Annotations&highlight=" target="_blank">
                        <input type="button" value="GENE" class="blast_sb">
                    </a>

                </div>
            </div>
</s:iterator>
        </form>
    </div>
</div>

<!--footer-->
<%@include file="footer.jsp"%>
</body>
</html>
