<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/10
  Time: 21:59
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SequenceFetch</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/blast.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/blast_24.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/blast_18.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/blast_15.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/blast.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/blast_6.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch_6.css">');
        }
    </script>


</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">
<%--    <div id="userguidelink">--%>
<%--        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=sequenceLength.txt" title="userguide and test data">--%>
<%--            <p class="userguidelink_p">Chromosome length information</p>--%>
<%--        </a>--%>
<%--    </div>--%>
    <div class="body_center">
        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/BatchQuery_sequenceFetchdetail.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p>Sequence Fetch</p>
                <%--<select class="par_type" name="par_type">
                    <option>blast</option>
                </select>--%>
                <input name="seq_species_type" style="display: none" value="<s:property value="#session.seq_species_types"/>">

            </div>
           <%-- <div class="form_type">
                <div class="f_t_lab">
                    <p>Select Position:</p>
                    <select class="blast_type" name="blast_type">
                        <option>blastn</option>
                        <option>blastp</option>
                        <option>blastx</option>
                        <option>tblastn</option>
                        <option>tblastx</option>
                    </select>
                </div>
            </div>--%>
            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Species:</p>
                    <select id="sub_cate_se1" class="blast_db" name="seq_species_type">

<%--                       <s:iterator value="allBlastFile" var="BlastFile">--%>
<%--                           <option value="<s:property value="#BlastFile.blast_speciesFileName"></s:property>"><s:property value="#BlastFile.balst_speciesName"></s:property> </option>--%>
<%--                       </s:iterator>--%>

                    </select>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Chromosome:</p>
                    <select id="sub_cate_se2" class="blast_db " name="blast_db">

<%--                        <s:iterator value="allBlastFile" var="BlastFile">--%>
<%--                            <option value="<s:property value="#BlastFile.blast_speciesFileName"></s:property>"><s:property value="#BlastFile.balst_speciesName"></s:property> </option>--%>
<%--                        </s:iterator>--%>

                    </select>
                </div>
            </div>
            <%--<div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Fasta Query Sequence:</p>
                    <textarea class="blast_seq" name="blast_seq" placeholder="Paste query sequence(s) in FASTA format here ...
For example:
>Bol004797
MTVLKRYVLRLFMSIKYITTNVVDKNNGRVVTTASTVEHAVKNSLECGRT
CNAKAAAILGEVLAMRLKVEGHQDGQGRGIHADVKKEIEKKGFKSRTKVW
AVINSVRNNGVTLILDDFNVDEDKYYRYRSDEGHQ"></textarea>
                    <input type="file" name="upload" id="fileupload">
                </div>
            </div>--%>
            <div class="form_par">
                <div class="f_t_lab">
                    <p>Select Position:</p>
                    <label>Position &nbsp; &nbsp;Start:</label>
                    <input type="text" class="blast_eval" name="chr_star" id="chr_star">

                    <br>
                    <label>Position &nbsp; &nbsp;End:</label>
                    <input type="text" class="blast_eval" name="chr_end" id="chr_end">


                    <br>
                    <label>Position &nbsp; &nbsp;Strand:</label>
                    <select class="blast_eval" name="chr_strand" id="chr_strand">
                        <option>+</option>
                        <option>-</option>

                    </select>





                </div>

            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Sequence Fetch:</p>
                    <input type="button" value="Example" class="blast_example">
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>

<!--footer-->
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        $.post('${pageContext.request.contextPath}/Category_list.action?pid=4',function (data) {

            console.log(data);
            $(data).each(function (i,obj) {
                console.log(obj.cate_name);
                $("#sub_cate_se1").append("<option value="+obj.cate_id+">" +obj.cate_name  + obj.cate_details + "</option>");
            });

            $("#sub_cate_se1").trigger("change");

        },"json");


        $("#sub_cate_se1").on("change",function () {

            var cate_id =  $("#sub_cate_se1").val();
            //alert(cate_id);
            $.post('${pageContext.request.contextPath}/Category_sonlist.action?cate_id='+cate_id,function (data) {

                console.log(data);
                $("#sub_cate_se2").empty();
                $(data).each(function (i,obj) {
                    console.log(obj.cate_name);

                    $("#sub_cate_se2").append("<option value="+obj.cate_name+">"+obj.cate_name+"</option>");
                });

            },"json");
        });


        $(".blast_sb").click(function () {


            var chr_star = $("#chr_star").val();
            var chr_end = $("#chr_end").val();


           /* alert(blast_seq);*/
          /*  alert(fileupload);*/

            if(chr_star == "" && chr_end == ""){
                alert("please input start and end position!");
            }

            if( chr_star != "" && chr_end == ""){
                alert("please input end position!!");
            }

            if(chr_star == "" && chr_end != ""){
                alert("please input start position!!");
            }

            if(chr_star != "" && chr_end != ""){

                $("#blast_form").submit();
            }

        });

        $(".blast_example").click(function () {


            $("#chr_end").val("1000");
            $("#chr_star").val("200");

        });




    });
</script>
</body>
</html>