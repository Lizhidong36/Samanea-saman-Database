<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/8/15
  Time: 21:11
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@include file="backHeader.jsp"%>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <link rel="stylesheet" href="css/LoginControl.css">
</head>
<body>

<div id="body">
    <div class="body_center">
        <div class="body_center_center">

            <div class="title">
                Access &nbsp;Control
            </div>
            <div class="login_con">
                <p>Login Control:</p>
                <input class="all_access" type="button" value="Allow &nbsp;Access">
                <input class="no_access" type="button" value="Access &nbsp;Denied">
            </div>
            <div class="advance_control">
                <p>Advanced Privilege Control:</p>
                <div class="a_c_d">
                    <span>
                    Select &nbsp;User:
                    </span>
                    <select class="a_c_sel">
                        <%--<option>ccccc</option>
                        <option>bbbbb</option>--%>
                    </select>
                </div>
                <div class="give_advan_pri">
                    <input class="give_privilege" type="button" value="Give Advanced Privilege">
                </div>


            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<script type="text/javascript">

    $(function () {


        $.post('${pageContext.request.contextPath}/LoginControl_list.action',function (data) {

            console.log(data);
            
            $(data).each(function (i,obj) {
                console.log(obj.username);

                $(".a_c_sel").append("<option value="+obj.id+">"+obj.username+"</option>");
            });


        },"json");

        $(".no_access").click(function () {

            alert("Reject all user access");

            $.post('${pageContext.request.contextPath}/LoginControl_rejest.action',function () {

            });
        });

        $(".all_access").click(function () {

            alert("Allow all user access");

            $.post('${pageContext.request.contextPath}/LoginControl_allow.action',function () {

            });
        });

        $(".give_privilege").click(function () {

          var id =   $(".a_c_sel").val();
          alert(id);

            $.post('${pageContext.request.contextPath}/LoginControl_advancePrivilege.action?id='+id,function () {

               /* console.log(data);

                $(data).each(function (i,obj) {
                    console.log(obj.username);

                    $(".a_c_sel").append("<option value="+obj.id+">"+obj.username+"</option>");
                });*/

            });

        });
    });


</script>
</body>
</html>
