<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/10/4
  Time: 13:29
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Download List</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/DownloadGenome.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/DownloadGenome_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/DownloadGenome_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/DownloadGenome_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/DownloadGenome.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/DownloadGenome_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
    <div id="body_center">
        <div class="body_center_center">
            <div class="body_center_top">
                <p class="b_c_t_p1"><s:property value="#session.overview"/></p>
            </div>
            <%--文件下载功能--%>
           <%-- <a href="download_down.action?fileName=<s:property value="#DownloadDetail.download_speciesName"/>">--%>

            <div class="sub_species">

                <s:iterator value="fileList" var="DownloadDetail">
                    <div class="spe">
                        <a target="_blank" href="${pageContext.request.contextPath}/downloadFile_fileShow.action?download_speciesName=<s:property value="#DownloadDetail.download_speciesName"/>&download_fileType=<s:property value="#session.overview"/>">
                            <span class="icon-download2"></span>
                            <i><s:property value="#DownloadDetail.download_speciesName"></s:property></i>
                        </a>
                    </div>
                </s:iterator>

            </div>
        </div>
    </div>
</div>
<!--footer-->
<%@include file="footer.jsp"%>
</body>
</html>
