<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/7/24
  Time: 上午10:31
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/DownloadGenome.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/DownloadGenome_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/DownloadGenome_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/DownloadGenome_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/DownloadGenome.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/DownloadGenome_6.css">');
        }
    </script>

</head>
<body>


<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
    <div id="body_center">
        <div class="body_center_center">
            <div class="body_center_top">
                <p class="b_c_t_p1"><s:property value="#session.download_speciesName"/></p>
            </div>
            <%--文件下载功能--%>
            <%-- <a href="download_down.action?fileName=<s:property value="#DownloadDetail.download_speciesName"/>">--%>

            <div class="sub_species">

                <s:iterator value="speciesFile" var="DownloadFile">
                    <div class="spe">
                        <%--<a href="download_down.action?fileName=<s:property value="#DownloadFile.download_fileName"/>">--%>
                        <a href="${pageContext.request.contextPath}/Spernaseq_contlist.action?spe_geo_num=<s:property value="#DownloadFile.download_fileName"/>" target="_blank">
                            <span class="icon-download2"></span>
                            <s:property value="#DownloadFile.download_fileName"></s:property>
                        </a>
                    </div>
                </s:iterator>

            </div>
        </div>
    </div>
</div>
<!--footer-->
<%@include file="footer.jsp"%>

</body>
</html>
