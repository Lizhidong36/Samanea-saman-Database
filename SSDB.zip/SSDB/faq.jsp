<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/11
  Time: 9:41
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FAQ</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/faq.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/faq_24.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/faq_18.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/faq_15.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/faq.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/faq_6.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <!--body_center-->
    <div id="body_center">
        <div class="body_center_top">
            <p class="b_c_t_p1">Frequently &nbsp;Asked &nbsp;Questions &nbsp; About &nbsp;Horticultural &nbsp;Plant &nbsp;Database</p>
        </div>
        <div class="body_center_bottom">

            <s:iterator value="allFaq" var="faq">

                <div class="b_c_b_Q1">
                    <div >
                        <p>
                            <s:property value="#faq.faq_ques"></s:property>
                        </p>

                    </div>
                    <div class="b_c_b_Q2">
<%--                        <p class="b_c_b_Q2"><s:property value="#faq.faq_ans"></s:property></p>--%>
                        <s:property value="#faq.faq_ans"></s:property>
                    </div>
                </div>

            </s:iterator>



        </div>
    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
