<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/9
  Time: 下午2:15
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Synteny Gene Search</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/Synteny2.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/Synteny2_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/Synteny2_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/Synteny2_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/Synteny2.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/Synteny2_6.css">');
        }
    </script>

</head>
<body>

<%@include file="header.jsp"%>

<!--body-->
<div id="body">
    <div id="userguidelink">
        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=Synteny_Finder_1.zip" title="userguide and test data">
            <p class="userguidelink_p">Userguide and demo file</p>
        </a>
    </div>
    <div class="body_center">
        <form id="syn_form" action="${pageContext.request.contextPath}/Synteny2_search.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p>Synteny &nbsp;&nbsp;Finder</p>
            </div>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Fasta Reference Protein Sequence:</p>
                    <input type="file" name="ref_seqUpload" class="ref_seq">

                </div>
            </div>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Fasta Reference GFF:</p>
                    <input type="file" name="ref_gffUpload" class="ref_gff">
                </div>
            </div>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Fasta Query Protein Sequence:</p>
                    <input type="file" name="query_seqUpload" class="query_seq">

                </div>
            </div>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Fasta Reference GFF:</p>
                    <input type="file" name="query_gffUpload" class="query_gff">
                    <%--<input type="file" name="query_gff" class="query_gff">--%>
                    <%--<textarea class="query_gff"></textarea>--%>
                </div>
            </div>
            <div class="form_par">
                <div class="f_t_lab">

                    <p>Optional BLAST+ Parameters:</p>
                    <label class="lab_one">Expect Threshold:</label>
                    <select name="blast_eval" class="blast_eval">
                        <option>0.000001</option>
                        <option>0.00001</option>
                        <option>0.0001</option>
                        <option>0.001</option>
                        <option>0.01</option>
                        <option>0.1</option>
                        <option>1.0</option>
                    </select>
                </div>
            </div>

            <div class="form_par">
                <div class="f_t_lab">
                    <p>Optional MCScanX Parameters:</p>
                    <label class="lab_two">gap:</label>
                    <select name="mscans_m" class="mscans_m">
                        <option>25</option>
                        <option>20</option>
                        <option>15</option>
                        <option>10</option>
                        <option>5</option>
                        <option>4</option>
                        <option>3</option>
                        <option>2</option>
                        <option>1</option>
                    </select>
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Synteny Gene Search:</p>
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>

<!--footer-->
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript">

    $(function () {



        $(".blast_sb").click(function () {


           /* alert('submit');*/
            $("#syn_form").submit();

            /*alert('000');*/

        });
    });
</script>

</body>
</html>
