<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/10
  Time: 21:55
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/rejist.css">
    <link rel="stylesheet" href="css/textselect.css">--%>
    <link rel="stylesheet" href="css/style.css">


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/header_24.css">');
            document.write('<link rel="stylesheet" href="css/rejist_24.css">');
            document.write('<link rel="stylesheet" href="css/textselect_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/header_18.css">');
            document.write('<link rel="stylesheet" href="css/rejist_18.css">');
            document.write('<link rel="stylesheet" href="css/textselect_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/header_15.css">');
            document.write('<link rel="stylesheet" href="css/rejist_15.css">');
            document.write('<link rel="stylesheet" href="css/textselect_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/header.css">');
            document.write('<link rel="stylesheet" href="css/rejist.css">');
            document.write('<link rel="stylesheet" href="css/textselect.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/header_6.css">');
            document.write('<link rel="stylesheet" href="css/rejist_6.css">');
            document.write('<link rel="stylesheet" href="css/textselect_6.css">');
        }
    </script>


</head>
<body>
<!--header-->
<div id="header">
    <!--header_top-->
    <div class="header_top">
        <div class="header_top_center">
            <div class="header_top_center_left">
                Welcome to
                <p id="first_word">T</p>
                <p id="two_word">B</p>
                <p id="third_word">I</p>
                <p id="four_word">R</p>
            </div>

            <div class="header_top_center_right">

                <a href="index.jsp">Home</a>
                <a href="login2222.jsp">Login</a>
            </div>
        </div>
        <!--header_body-->
        <div class="header_body">

            <div class="header_body_center">
                <div class="header_body_center_left">
                   <%-- <img src="image/DSC_3302.JPG">--%>
                       <img src="image/titlelogo8.jpg">
                </div>

                <div class="header_body_center_center">
                    <p>The &nbsp;&nbsp;<i>Brassicaceae</i> &nbsp;&nbsp;Information &nbsp;&nbsp;Resources</p>
                    <%--<p>&nbsp;V1.0</p>--%>
                </div>

               <%-- <div class="header_body_center_right">
                    <div class="r_sea">
                        <input  class="r_s_inp" type="text" placeholder="keyword">
                    </div>
                    <div class="r_but">
                        <input  type="button" value="Search">
                    </div>

                </div>--%>
                <div class="header_body_center_right">
                    <div id="container">
                        <div id="content">
                            <div class="first">
                                <form target="_blank" id="head_blast_form" action="${pageContext.request.contextPath}/searchkeyAction_keywordsearch.action" method="post"  enctype="multipart/form-data">
                                    <input name="searchkeyword" id="kw" placeholder="Search TBIR" onkeyup="getContent(this);">
                                    <div class="icon-zoom-in"></div>
                                </form>


                            </div>
                            <div id="append"></div>
                        </div>
                    </div>
                    <%-- <div class="r_but">
                         <input  type="button" value="Search">
                     </div>--%>
                </div>
            </div>

        </div>
    </div>
</div>

<%--action="${pageContext.request.contextPath}/LoginAction_rejist.action"--%>
<!--body-->
<div id="body">
    <div class="body_center">
        <div class="body_left">

            <span id="erroe_infor" style="color:red"><s:actionerror></s:actionerror></span>
            <form  id="reg_form" method="post">
                <div>
                    <label>Username</label>
                    <input id="username" name="username" type="text" placeholder="Enter your username">
                </div>
                <div>
                    <label>Work &nbsp;units</label>
                    <input id="workaddress" name="workaddress" type="text" placeholder="Enter your work units">
                </div>
                <div>
                    <label>Email &nbsp;address</label>
                    <input id="emailaddress" name="emailaddress" type="text" placeholder="Enter your email">
                </div>
                <div>
                    <label>Password</label>
                    <input id="pwd" name="password" type="password" placeholder="Enter your passwrd" >
                </div>
                <div>
                    <label>Confirm &nbsp;password</label>
                    <input id="pwd2" type="password" placeholder="Confirm your password">
                </div>

                <div class="submit_button">
                    <input type="button" value="Regist">
                </div>

            </form>
        </div>
        <div class="body_right">
            <div class="body_right_cen">
                <%--<img src="image/DSC_3305.JPG">--%>
                    <img src="image/Brassica_pekinensis.jpg">
            </div>

        </div>
    </div>

</div>
<!--footer-->
<%@include file="footer.jsp"%>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript" src="js/selecttet.js"></script>
<script type="text/javascript">
    $(function () {

        $(".submit_button").click(function () {

            var username =  $("#username").val();
            var pwd =  $("#pwd").val();
            var pwd2 =  $("#pwd2").val();
            var workaddress = $("#workaddress").val();
            var emailaddress = $("#emailaddress").val();


            if(username == ""){
                alert("Please input username");
                return;
            }
            if(pwd == ""){
                alert("Please input password");
                return;
            }
            if(pwd2 == ""){
                alert("Password is error");
                return;
            }

            if(workaddress == ""){
                alert("Please input your work units");
                return;

            }
            if(emailaddress == ""){

                alert("Please input your email address");
                return;
            }

            if(pwd == pwd2){

                $(window).attr('location','${pageContext.request.contextPath}/LoginAction_rejist.action?username='+username+'&password='+pwd+'&cont_id=1'+ '&workaddress='+workaddress + '&emailaddress=' + emailaddress);

            }else{
                alert("密码不同");
                return;
            }
        });

        $(".icon-zoom-in").click(function () {


            $("#head_blast_form").submit();
        });
    });


</script>
</body>
</html>
