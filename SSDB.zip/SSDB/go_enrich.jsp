<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/11/22
  Time: 下午2:53
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>GO/KEGG Enrichment</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/go_enrich.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/go_enrich_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/go_enrich_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/go_enrich_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/go_enrich.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/go_enrich_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">

<%--    <div id="userguidelink">--%>
<%--        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=GO_AND_KEGG_enrichment_1.zip" title="userguide and test data">--%>
<%--            <p class="userguidelink_p">Userguide and demo file</p>--%>
<%--        </a>--%>


<%--    </div>--%>
    <div class="body_center">
        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/GoEnrich_gorich.action" method="post"  enctype="multipart/form-data">

            <div class="form_top">
                <p><s:property value="#session.titlename"></s:property></p>
                <input  style="display:none" id="enrichType" name="enrichType" type="text" value="<s:property value="#session.richtype" />">
            </div>

            <div class="form_type">
                <div class="f_t_lab">
                    <p>Select database:</p>
                    <select class="blast_db" name="blast_db">

                        <s:iterator value="allBlastFile" var="BlastFile">
                            <option value="<s:property value="#BlastFile.blast_speciesFileName"></s:property>"><s:property value="#BlastFile.balst_speciesName"></s:property> </option>
                        </s:iterator>

                    </select>
                </div>
            </div>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter the list of IDs:</p>
                    <textarea name="blast_seq" class="blast_seq" placeholder="Paste query id(s) ...
For example:
Ssa01001535.t1
Ssa01001468.t1"></textarea>
                    <input type="file" name="upload" id="fileupload">
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Choose the p-value correction method:</p>
                    <select class="go_method_type" name="methodType">
                        <option value="BH">BH</option>
                        <option value="fdr">fdr</option>
                        <option value="BY">BY</option>
                        <option value="holm">holm</option>
                        <option value="hochberg">hochberg</option>
                        <option value="hommel">hommel</option>
                        <option value="bonferroni">bonferroni</option>
                        <option value="none">none</option>
                    </select>
                </div>
            </div>

            <div class="form_par">
                <div class="f_t_lab">
                    <p>Optional parameters:</p>
                    <label>PvalueCutoff:</label>
                    <input id="pvalue"  class="blast_eval" name="pvalue" value="0.05">

                    <br>
                    <label>QvalueCutoff:</label>
                    <input id="qvalue" class="blast_eval" name="qvalue" value="0.95">

                </div>
            </div>

            <div class="form_vis">
                <div class="f_t_lab">

                    <p>Visualization:</p>
                    <input value="barplot" class="tran_pro" type="radio" name="control_type" checked>
                    <label class="tran_pro_label"> Barplot</label>
                    <input value="dotplot" class="tran_pro" type="radio" name="control_type">
                    <label class="tran_pro_label"> Dotplot</label>
                    <input value="cnetplot" class="tran_pro" type="radio" name="control_type">
                    <label class="tran_pro_label"> Cnetplot</label>
                    <input value="emapplot" class="tran_pro" type="radio" name="control_type">
                    <label class="tran_pro_label"> Emapplot</label>
                    <input value="heatplot" class="tran_pro" type="radio" name="control_type">
                    <label class="tran_pro_label"> Heatplot</label>

                </div>
                <div id="barplot_par">
                    <label class="barplot_par_lab">Number:</label>
                    <input type="text" value="10" step="1" max="100" min="1" name="bar_number" class="bar_number">
                    <br>
                    <label class="barplot_par_lab">Text font size:</label>
                    <input type="text" value="10.0" step="0.1" max="15.0" min="1.0" name="bar_textsize" class="bar_textsize">
                    <br>
                    <label class="barplot_par_lab">Lab size:</label>
                    <input type="text" value="10.0" step="0.1" max="15.0" min="1.0" name="bar_xylabsize" class="bar_xylabsize">
                    <br>
                    <label class="barplot_par_lab">Title size:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="1.0" name="bar_titlesize" class="bar_titlesize">
                    <br>
                    <label class="barplot_par_lab">Legend size:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="1.0" name="bar_legendsize" class="bar_legendsize">
                    <br>
                    <label class="barplot_par_lab">Legend title size:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="1.0" name="bar_legendtitlesize" class="bar_legendtitlesize">
                    <br>
                    <label class="barplot_par_lab">Width:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="bar_width" class="bar_width">
                    <br>
                    <label class="barplot_par_lab">Height:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="bar_height" class="bar_height">
                </div>
                <div id="dotplot_par" style="display: none">
                    <label class="barplot_par_lab">Number:</label>
                    <input type="text" value="10" step="1" max="100" min="1" name="dot_number" class="dot_number">
                    <br>
                    <label class="barplot_par_lab">Text font size:</label>
                    <input type="text" value="10.0" step="0.1" max="15.0" min="1.0" name="dot_textsize" class="dot_textsize">
                    <br>
                    <label class="barplot_par_lab">Lab size:</label>
                    <input type="text" value="10.0" step="0.1" max="15.0" min="1.0" name="dot_xylabsize" class="dot_xylabsize">
                    <br>
                    <label class="barplot_par_lab">Title size:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="1.0" name="dot_titlesize" class="dot_titlesize">
                    <br>
                    <label class="barplot_par_lab">Legend size:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="1.0" name="dot_legendsize" class="dot_legendsize">
                    <br>
                    <label class="barplot_par_lab">Legend title size:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="1.0" name="dot_legendtitlesize" class="dot_legendtitlesize">
                    <br>
                    <label class="barplot_par_lab">Width:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="dot_width" class="dot_width">
                    <br>
                    <label class="barplot_par_lab">Height:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="dot_height" class="dot_height">
                    <br>
                    <label class="barplot_par_lab">Low range:</label>
                    <input type="text" value="2" step="1" max="5" min="1" name="dot_lowrange" class="dot_lowrange">
                    <br>
                    <label class="barplot_par_lab">High range:</label>
                    <input type="text" value="6" step="1" max="16" min="3" name="dot_highrange" class="dot_highrange">
                </div>
                <div id="cnetplot_par" style="display: none">
                    <label class="barplot_par_lab">Number:</label>
                    <input type="text" value="10" step="1" max="100" min="1" name="cnet_number" class="cnet_number">
                    <br>
                    <label class="barplot_par_lab">Width:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="cnet_width" class="cnet_width">
                    <br>
                    <label class="barplot_par_lab">Height:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="cnet_height" class="cnet_height">
                    <br>
                    <label class="barplot_par_lab">Low range:</label>
                    <input type="text" value="2" step="1" max="5" min="1" name="cnet_lowrange" class="cnet_lowrange">
                    <br>
                    <label class="barplot_par_lab">High range:</label>
                    <input type="text" value="6" step="1" max="16" min="3" name="cnet_heighrange" class="cnet_heighrange">
                    <br>
                    <label class="barplot_par_lab">Circular:</label>
                    <select name="cnet_circular" class="cnet_circular">
                        <option value="TRUE">T</option>
                        <option value="FALSE">F</option>

                    </select>
                </div>
                <div id="emapplot_par" style="display: none">
                    <label class="barplot_par_lab">Number:</label>
                    <input type="text" value="10" step="1" max="100" min="1" name="eam_number" class="eam_number">
                    <br>
                    <label class="barplot_par_lab">Width:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="eam_width" class="eam_width">
                    <br>
                    <label class="barplot_par_lab">Height:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="eam_height" class="eam_height">
                    <br>
                    <label class="barplot_par_lab">Low range:</label>
                    <input type="text" value="2" step="1" max="5" min="1" name="eam_lowrange" class="eam_lowrange">
                    <br>
                    <label class="barplot_par_lab">High range:</label>
                    <input type="text" value="6" step="1" max="16" min="3" name="eam_heighrange" class="eam_heighrange">
                </div>
                <div id="heatplot_par" style="display: none">
                    <label class="barplot_par_lab">Number:</label>
                    <input type="text" value="10" step="1" max="100" min="1" name="hea_number" class="hea_number">
                    <br>
                    <label class="barplot_par_lab">Width:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="hea_width" class="hea_width">
                    <br>
                    <label class="barplot_par_lab">Height:</label>
                    <input type="text" value="8.0" step="0.1" max="15.0" min="2.0" name="hea_height" class="hea_height">
                </div>
            </div>


            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit:</p>
                    <input type="button" value="Example" class="blast_example">
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>
        </form>
    </div>
</div>

<%@include file="footer.jsp"%>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">


    $(function () {

        function turn(str) {

            while (str.indexOf("\n") != -1) {
                str = str.substring(0, str.indexOf("\n")) + "<br>"
                    + str.substring(str.indexOf("\n") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\C6MC6M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("|") != -1) {
                str = str.substring(0, str.indexOf("|")) + "\C9MC9M"
                    + str.substring(str.indexOf("|") + 1);
            }
            while (str.indexOf("_") != -1) {
                str = str.substring(0, str.indexOf("_")) + "\C3MC3M"
                    + str.substring(str.indexOf("_") + 1);
            }
            while (str.indexOf("#") != -1) {
                str = str.substring(0, str.indexOf("#")) + "\C5MC5M"
                    + str.substring(str.indexOf("#") + 1);
            }
            while (str.indexOf("=") != -1) {
                str = str.substring(0, str.indexOf("=")) + "\C7MC7M"
                    + str.substring(str.indexOf("=") + 1);
            }
            while (str.indexOf(".") != -1) {
                str = str.substring(0, str.indexOf(".")) + "\C8MC8M"
                    + str.substring(str.indexOf(".") + 1);
            }
            while (str.indexOf("/") != -1) {
                str = str.substring(0, str.indexOf("/")) + "\C4MC4M"
                    + str.substring(str.indexOf("/") + 1);
            }
            while (str.indexOf("-") != -1) {
                str = str.substring(0, str.indexOf("-")) + "\C2MC2M"
                    + str.substring(str.indexOf("-") + 1);
            }
            while (str.indexOf("+") != -1) {
                str = str.substring(0, str.indexOf("+")) + "\C1MC1M"
                    + str.substring(str.indexOf("+") + 1);
            }
            while (str.indexOf(":") != -1) {
                str = str.substring(0, str.indexOf(":")) + "\M6666MM6666M"
                    + str.substring(str.indexOf(":") + 1);
            }
            while (str.indexOf(";") != -1) {
                str = str.substring(0, str.indexOf(";")) + "\M1111MM1111M"
                    + str.substring(str.indexOf(";") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\M2222MM2222M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("\t") != -1) {
                str = str.substring(0, str.indexOf("\t")) + "\M3333MM3333M"
                    + str.substring(str.indexOf("\t") + 1);
            }
            while (str.indexOf(",") != -1) {
                str = str.substring(0, str.indexOf(",")) + "\M4444MM4444M"
                    + str.substring(str.indexOf(",") + 1);
            }
            while (str.indexOf("    ") != -1) {
                str = str.substring(0, str.indexOf("    ")) + "\Cc1MCc1M"
                    + str.substring(str.indexOf("   ") + 1);
            }
            return str;
        };


        $('.tran_pro').click(function () {

            var val=$('input:radio[name="control_type"]:checked').val();
            // alert(val);
            if(val== 'barplot'){
                $('#barplot_par').css('display','block');
            }else{
                $('#barplot_par').css('display','none');
            }

            if(val== 'dotplot'){
                $('#dotplot_par').css('display','block');
            }else{
                $('#dotplot_par').css('display','none');
            }

            if(val== 'cnetplot'){
                $('#cnetplot_par').css('display','block');
            }else{
                $('#cnetplot_par').css('display','none');
            }

            if(val== 'emapplot'){
                $('#emapplot_par').css('display','block');
            }else{
                $('#emapplot_par').css('display','none');
            }

            if(val== 'heatplot'){
                $('#heatplot_par').css('display','block');
            }else{
                $('#heatplot_par').css('display','none');
            }

        });

        $(".blast_sb").click(function () {

            var blast_seq = $(".blast_seq").val();
            var fileupload = $("#fileupload").val();
            var pvalue = $("#pvalue").val();
            var qvalue = $("#qvalue").val();
            var tran_pro=$('input:radio[name="control_type"]:checked').val();

            /*alert(blast_seq);
            alert(fileupload);
            alert(pvalue);
            alert(qvalue);
            alert(tran_pro);*/

            if(blast_seq == "" &&fileupload == ""){
                alert("please input or upload id file!")
            }
            if(blast_seq != "" && fileupload != ""){
               alert("please input or upload id file!");
            }
            if((blast_seq != "" && fileupload == "") | (blast_seq == "" && fileupload != "")){

              /*  alert("3/4");*/

                if(tran_pro == "barplot"){
                    var bar_number = $(".bar_number").val();
                    var bar_textsize = $(".bar_textsize").val();
                    var bar_xylabsize = $(".bar_xylabsize").val();
                    var bar_titlesize = $(".bar_titlesize").val();
                    var bar_legendsize = $(".bar_legendsize").val();
                    var bar_legendtitlesize = $(".bar_legendtitlesize").val();
                    var bar_width = $(".bar_width").val();
                    var bar_height = $(".bar_height").val();

                    if(bar_number != "" && bar_textsize != "" && bar_xylabsize != "" && bar_titlesize != "" && bar_legendsize != "" && bar_legendtitlesize != "" && bar_width != "" && bar_height != "" && blast_seq != "" && fileupload == "" && pvalue != "" && qvalue != ""){

                       /* alert("b-1");*/
                        cont1 = turn(blast_seq);
                        var new_blast_seq = $(".blast_seq").val(cont1);
                        $("#blast_form").submit();
                    }
                    if(bar_number != "" && bar_textsize != "" && bar_xylabsize != "" && bar_titlesize != "" && bar_legendsize != "" && bar_legendtitlesize != "" && bar_width != "" && bar_height != "" && blast_seq == "" && fileupload != "" && pvalue != "" && qvalue != ""){
                        /*alert("b-2");*/
                        $("#blast_form").submit();
                    }
                    if(bar_number == "" | bar_textsize == "" | bar_xylabsize == "" | bar_titlesize == "" | bar_legendsize == "" | bar_legendtitlesize == "" | bar_width == "" | bar_height == "" ){
                       /* alert("b-3");*/
                        alert("please choose visualization parameters");
                    }
                }

                if(tran_pro == "dotplot"){
                    var dot_number = $(".dot_number").val();
                    var dot_textsize = $(".dot_textsize").val();
                    var dot_xylabsize = $(".dot_xylabsize").val();
                    var dot_titlesize = $(".dot_titlesize").val();
                    var dot_legendsize = $(".dot_legendsize").val();
                    var dot_legendtitlesize = $(".dot_legendtitlesize").val();
                    var dot_width = $(".dot_width").val();
                    var dot_height = $(".dot_height").val();
                    var dot_lowrange = $(".dot_lowrange").val();
                    var dot_highrange = $(".dot_highrange").val();

                    if(dot_number != "" && dot_textsize != "" && dot_xylabsize != "" && dot_titlesize != "" && dot_legendsize != "" && dot_legendtitlesize != "" && dot_width != "" && dot_height != "" && dot_lowrange != "" && dot_highrange != "" && blast_seq != "" && fileupload == ""){
                       /* alert("d-1");*/
                        cont1 = turn(blast_seq);
                        var new_blast_seq = $(".blast_seq").val(cont1);
                        $("#blast_form").submit();
                    }
                    if(dot_number != "" && dot_textsize != "" && dot_xylabsize != "" && dot_titlesize != "" && dot_legendsize != "" && dot_legendtitlesize != "" && dot_width != "" && dot_height != "" && dot_lowrange != "" && dot_highrange != "" && blast_seq == "" && fileupload != ""){
                       /* alert("d-2");*/
                        $("#blast_form").submit();
                    }
                    if(dot_number == "" | dot_textsize == "" | dot_xylabsize == "" | dot_titlesize == "" | dot_legendsize == "" | dot_legendtitlesize == "" | dot_width == "" | dot_height == "" | dot_lowrange == "" | dot_highrange == ""){
                        /*alert("d-3")*/
                        alert("please choose visualization parameters");
                    }
                }

                if(tran_pro == "cnetplot"){
                    var cnet_number = $(".cnet_number").val();
                    var cnet_width = $(".cnet_width").val();
                    var cnet_height = $(".cnet_height").val();
                    var cnet_lowrange = $(".cnet_lowrange").val();
                    var cnet_heighrange = $(".cnet_heighrange").val();

                    if(cnet_number != "" && cnet_width != "" && cnet_height != "" && cnet_lowrange != "" && cnet_heighrange != "" && blast_seq != "" & fileupload == ""){
                        /*alert("c-1");*/
                        cont1 = turn(blast_seq);
                        var new_blast_seq = $(".blast_seq").val(cont1);
                        $("#blast_form").submit();
                    }
                    if(cnet_number != "" && cnet_width != "" && cnet_height != "" && cnet_lowrange != "" && cnet_heighrange != "" && blast_seq == "" & fileupload != ""){
                        /*alert("c-2");*/
                        $("#blast_form").submit();
                    }
                    if(cnet_number == "" | cnet_width == "" | cnet_height == "" | cnet_lowrange == "" | cnet_heighrange == ""){
                        /*alert("c-3");*/
                        alert("please choose visualization parameters");
                    }

                }

                if(tran_pro == "emapplot"){
                    var eam_number = $(".eam_number").val();
                    var eam_width = $(".eam_width").val();
                    var eam_height = $(".eam_height").val();
                    var eam_lowrange = $(".eam_lowrange").val();
                    var eam_heighrange = $(".eam_heighrange").val();

                    if(eam_number != "" && eam_width != "" && eam_height != "" && eam_lowrange != "" && eam_heighrange != "" && blast_seq != "" && fileupload == ""){
                        /*alert("e-1");*/
                        cont1 = turn(blast_seq);
                        var new_blast_seq = $(".blast_seq").val(cont1);
                        $("#blast_form").submit();

                    }
                    if(eam_number != "" && eam_width != "" && eam_height != "" && eam_lowrange != "" && eam_heighrange != "" && blast_seq == "" && fileupload != ""){
                        /*alert("e-2");*/
                        $("#blast_form").submit();
                    }

                    if(eam_number == "" | eam_width == "" | eam_height == "" | eam_lowrange == "" | eam_heighrange == ""){
                      /*  alert("e-3");*/
                        alert("please choose visualization parameters");
                    }
                }

                if(tran_pro == "heatplot"){
                    var hea_number = $(".hea_number").val();
                    var hea_width = $(".hea_width").val();
                    var hea_height = $(".hea_height").val();

                    if(hea_number != "" && hea_width != "" && hea_height != "" && blast_seq != "" && fileupload == ""){
                        /*alert("h-1");*/
                        cont1 = turn(blast_seq);
                        var new_blast_seq = $(".blast_seq").val(cont1);
                        $("#blast_form").submit();

                    }
                    if(hea_number != "" && hea_width != "" && hea_height != "" && blast_seq == "" && fileupload != ""){
                       /* alert("h-2");*/
                        $("#blast_form").submit();
                    }
                    if(hea_number == "" | hea_width == "" | hea_height == ""){
                       /* alert("h-3");*/
                        alert("please choose visualization parameters");
                    }

                }

            }

        });

        $(".blast_example").click(function () {


            $(".blast_seq").val("Ssa01001468.t1\n" +
                "Ssa12007152.t1\n"+
                "Ssa03012623.t1\n"+
                "Ssa01000024.t1\n"+
                "Ssa01000279.t1\n"+
                "Ssa01000675.t1\n"+
                "Ssa01000954.t1\n"+
                "Ssa01001357.t1\n"+
                "Ssa01001697.t1\n"+
                "Ssa01002576.t1\n"+
                "Ssa10003150.t1\n"+
                "Ssa10003373.t1\n"+
                "Ssa10003757.t1\n"+
                "Ssa10004152.t1\n"+
                "Ssa10004372.t1\n"+
                "Ssa10004525.t1\n"+
                "Ssa10004676.t1\n"+
                "Ssa11005040.t1\n"+
                "Ssa11005222.t1\n"+
                "Ssa11005231.t1\n"+
                "Ssa11005447.t1\n"+
                "Ssa11005837.t1\n"+
                "Ssa11006066.t1\n"+
                "Ssa11006073.t1\n"+
                "Ssa11006189.t1\n"+
                "Ssa12006537.t2\n"+
                "Ssa12007055.t1\n"+
                "Ssa12007527.t1\n"+
                "Ssa13008062.t1\n"+
                "Ssa13008491.t1\n"+
                "Ssa13008999.t1\n"+
                "Ssa13009407.t1\n"+
                "Ssa02009735.t1\n"+
                "Ssa02010254.t2\n"+

                "Ssa02011625.t1\n"+
                "Ssa02011667.t1\n"+
                "Ssa02012132.t1\n"+
                "Ssa03012254.t1\n"+
                "Ssa03012506.t1\n"+
                "Ssa04014420.t1\n"+
                "Ssa04015283.t1\n"+
                "Ssa07021091.t1\n"+
                "Ssa01001326.t1\n"+
                "Ssa03013037.t1\n"+
                "Ssa07020860.t1\n"+
                "Ssa02010437.t2\n"+
                "Ssa02010588.t1\n"+
                "Ssa07021157.t1\n"+
                "Ssa07021696.t1\n"+
                "Ssa08023362.t1\n"+
                "Ssa01000166.t1\n"+
                "Ssa13009051.t1\n"+
                "Ssa07020584.t1\n"+
                "Ssa04014415.t2\n"+

                "Ssa10004775.t1\n"+
                "Ssa04015579.t1\n"+
                "Ssa08022465.t1\n"+
                "Ssa09024453.t1\n"+
                "Ssa01000252.t1\n"+
                "Ssa01000473.t1\n"+
                "Ssa01000983.t1\n"+
                "Ssa01001572.t1\n"+
                "Ssa01002192.t1\n"+
                "Ssa10003030.t1\n"+
                "Ssa10003282.t1\n"+
                "Ssa10003688.t2\n"+
                "Ssa10003688.t1\n"+
                "Ssa10004495.t1\n"+
                "Ssa05016064.t1\n"+
                "Ssa05016170.t1\n"+
                "Ssa05017126.t1\n"+
                "Ssa06017876.t1\n"+
                "Ssa06019595.t1\n"+
                "Ssa07021397.t2\n"
            );
            $("input[value='dotplot']").attr('checked','true');


        });

    });

</script>
</body>
</html>
