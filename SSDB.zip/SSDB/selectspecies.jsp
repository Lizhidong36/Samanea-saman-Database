<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2022/12/25
  Time: 下午4:42
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags"  prefix="s"%>
<html>
<head>
    <title>NCCWDB</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/SELECTSPECIES_24.css">');
            document.write('<link rel="stylesheet" href="css/body_species_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/SELECTSPECIES_18.css">');
            document.write('<link rel="stylesheet" href="css/body_species_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/SELECTSPECIES_15.css">');
            document.write('<link rel="stylesheet" href="css/body_species_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/SELECTSPECIES.css">');
            document.write('<link rel="stylesheet" href="css/body_species.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/SELECTSPECIES_6.css">');
            document.write('<link rel="stylesheet" href="css/body_species_6.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>
<div id="body">

    <div id="body_center_center">
<%--        <div class="body_center_center_center">--%>

<%--            <p class="type_name"><s:property value="#session.function_types"/></p>--%>
<%--            <div class="b_c_c_c_top1">--%>


<%--                <div class="species_picture">--%>
<%--                    <a href="${pageContext.request.contextPath}/<s:property value="#session.nhcclink"/>" target="_blank">--%>
<%--                        <img src="image/Brassica_pekinensis.jpg">--%>
<%--                    </a>--%>
<%--                </div>--%>
<%--                <div class="species_name">--%>
<%--                    <a href="${pageContext.request.contextPath}/<s:property value="#session.nhcclink"/>" target="_blank">--%>
<%--                        <div class="species_name_commonName">--%>
<%--                            <p >Non-heading Chinese Cabbage</p>--%>
<%--                        </div>--%>
<%--                        <div class="species_name_LDName">--%>
<%--                            <p><i>Brassica campestris </i>(syn. <i>Brassica rapa</i>) ssp. <i>chinensis</i></p>--%>
<%--                        </div>--%>
<%--                    </a>--%>
<%--                </div>--%>

<%--            </div>--%>
<%--            <div class="b_c_c_c_top3">--%>
<%--                <div class="species_picture">--%>
<%--                    <a href="${pageContext.request.contextPath}/<s:property value="#session.watercresslink"/>" target="_blank">--%>
<%--                        <img src="image/DSC_3304.JPG">--%>
<%--                    </a>--%>
<%--                </div>--%>
<%--                <div class="species_name">--%>
<%--                    <a href="${pageContext.request.contextPath}/<s:property value="#session.watercresslink"/>" target="_blank">--%>
<%--                        <div class="species_name_commonName">--%>
<%--                            <p>Watercress</p>--%>
<%--                        </div>--%>
<%--                        <div class="species_name_LDName">--%>
<%--                            <p><i>Nasturtium officinale</i></p>--%>
<%--                        </div>--%>
<%--                    </a>--%>
<%--                </div>--%>
<%--            </div>--%>

<%--        </div>--%>
    </div>
</div>

<%@include file="footer.jsp"%>
</body>
</html>
