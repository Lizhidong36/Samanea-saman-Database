<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/10/25
  Time: 下午10:05
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags"  prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/back_recentUpdateControl.css">
</head>
<body>

<%@include file="backHeader.jsp"%>
<%--body--%>
<div id="body">
    <div class="body_center">
        <div class="body_center_center">

            <div class="b_c_c_top">
                <div class="b_c_c_top_title">
                    <p>Recent Update</p>
                </div>
                <div class="b_c_c_top_addNews">
                    <a href="${pageContext.request.contextPath}/back_AddRecentUpdate.jsp" target="_blank">
                        <input  type="button" class="add_news" value="Add Update">
                    </a>

                </div>


            </div>

            <div class="b_c_c_home">
                <s:iterator value="backallUpdate" var="backupdate">
                    <div class="b_c_c_home_newsdetail">
                        <div class="b_c_c_home_newsdetail_title">
                            <ul>
                                <li>

                                    <%--<a href="${pageContext.request.contextPath}/news_oneNews.action?new_id=<s:property value="#backupdate.re_id"/>" target="_blank"><s:property value="#backupdate.re_desc"/></a>--%>
                                    <a href="${pageContext.request.contextPath}/<s:property value="#backupdate.re_link"/>" target="_blank"><s:property value="#backupdate.re_desc"/></a>
                                </li>
                            </ul>
                        </div>

                        <div class="b_c_c_home_newsdetail_delete">
                            <a href="${pageContext.request.contextPath}/recentUpdate_deleteOneUpdate.action?re_id=<s:property value="#backupdate.re_id"/>" target="_blank"><input type="button" value="Delete"></a>

                        </div>

                        <div class="b_c_c_home_newsdetail_edit">
                            <a href="${pageContext.request.contextPath}/recentUpdate_editOneUpdate.action?re_id=<s:property value="#backupdate.re_id"/>" target="_blank"><input type="button" value="Edit"></a>

                        </div>
                    </div>

                </s:iterator>
            </div>
        </div>
    </div>
</div>
</body>
</html>
