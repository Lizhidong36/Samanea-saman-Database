<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/4/28
  Time: 下午7:40
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>SSR Primer</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/SSRPrimer_24.css">');

        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/SSRPrimer_18.css">');

        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/SSRPrimer_15.css">');

        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/SSRPrimer.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/SSRPrimer_6.css">');

        }
    </script>
</head>
<body>
    <div class="body_top">
        <div class="body_top_ssr"><s:property value="#session.onessrtitle"/></div>
        <div class="body_top_ssrtitle">
            <div class="ssr_p">FORWARD PRIMER (5'-3')</div>
            <div class="ssr_tm">Tm(℃)</div>
            <div class="ssr_size">Size(bp)</div>
            <div class="ssr_p">REVERSE PRIMER (5'-3')</div>
            <div class="ssr_tm">Tm(℃)</div>
            <div class="ssr_size">Size(bp)</div>
            <div class="ssr_prosize">Product size (bp)</div>
            <div class="ssr_size">Start</div>
            <div class="ssr_sizeEND">End</div>
        </div>

<s:iterator value="tflist" var="SSR">
        <div class="body_top_ssrtitle">
            <div class="ssr_p"><s:property value="#SSR.S_for1" /></div>
            <div class="ssr_tm"><s:property value="#SSR.S_for1_tm" /></div>
            <div class="ssr_size"><s:property value="#SSR.S_for1_size" /></div>
            <div class="ssr_p"><s:property value="#SSR.S_re1" /></div>
            <div class="ssr_tm"><s:property value="#SSR.S_re1_tm" /></div>
            <div class="ssr_size"><s:property value="#SSR.S_re1_size" /></div>
            <div class="ssr_prosize"><s:property value="#SSR.S_pro1_size" /></div>
            <div class="ssr_size"><s:property value="#SSR.S_pro1_star" /></div>
            <div class="ssr_sizeEND"><s:property value="#SSR.S_pro1_end" /></div>
            <div class="ssr_p"><s:property value="#SSR.S_for2" /></div>
            <div class="ssr_tm"><s:property value="#SSR.S_for2_tm" /></div>
            <div class="ssr_size"><s:property value="#SSR.S_for2_size" /></div>
            <div class="ssr_p"><s:property value="#SSR.S_re2" /></div>
            <div class="ssr_tm"><s:property value="#SSR.S_re2_tm" /></div>
            <div class="ssr_size"><s:property value="#SSR.S_re2_size" /></div>
            <div class="ssr_prosize"><s:property value="#SSR.S_pro2_size" /></div>
            <div class="ssr_size"><s:property value="#SSR.S_pro2_star" /></div>
            <div class="ssr_sizeEND"><s:property value="#SSR.S_pro2_end" /></div>
            <div class="ssr_p"><s:property value="#SSR.S_for3" /></div>
            <div class="ssr_tm"><s:property value="#SSR.S_for3_tm" /></div>
            <div class="ssr_size"><s:property value="#SSR.S_for3_size" /></div>
            <div class="ssr_p"><s:property value="#SSR.S_re3" /></div>
            <div class="ssr_tm"><s:property value="#SSR.S_re3_tm" /></div>
            <div class="ssr_size"><s:property value="#SSR.S_re3_size" /></div>
            <div class="ssr_prosize"><s:property value="#SSR.S_pro3_size" /></div>
            <div class="ssr_size"><s:property value="#SSR.S_pro3_star" /></div>
            <div class="ssr_sizeEND"><s:property value="#SSR.S_pro3_end" /></div>
        </div>
</s:iterator>

    </div>
</body>
</html>
