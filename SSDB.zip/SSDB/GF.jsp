<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/12/5
  Time: 下午6:12
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Gene Family</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/TF_24.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/TF_18.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/TF_15.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/TF.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/TF_6.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">
    <div class="body_center">

        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/GfAction_list.action" method="post"  enctype="multipart/form-data">

            <div class="form_top">
                <p>Gene &nbsp;family</p>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Database:</p>
                    <select class="hmmer_db" name="allgf_species">
                        <s:iterator value="allBlastFile" var="BlastFile" >
                            <option  value="<s:property value="#BlastFile.blast_speciesFileName"></s:property>"><s:property value="#BlastFile.balst_speciesName"></s:property> </option>
                        </s:iterator>
                    </select>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Gene Family:</p>
                    <select class="hmmer_db" name="allgf_family">
                        <s:iterator value="allGF" var="gfamily" >
                            <option  value="<s:property value="#gfamily.gf_name"/>"><s:property value="#gfamily.gf_name"/> </option>
                        </s:iterator>
                    </select>
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Search Gene Family:</p>
                    <input type="button" value="Example" class="blast_example">
                    <input type="submit" value="Submit" class="blast_sb">
                </div>
            </div>
        </form>

    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
