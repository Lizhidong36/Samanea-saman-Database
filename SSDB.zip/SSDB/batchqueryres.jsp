<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/8/4
  Time: 20:22
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib  uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
</head>
<body>

<s:iterator value="Reslist" var="brapep">
    <div>
        <s:property value="#brapep.braid"></s:property>
    </div>
    <div>
        <s:property value="#brapep.brapep"></s:property>
    </div>
</s:iterator>
</body>
</html>
