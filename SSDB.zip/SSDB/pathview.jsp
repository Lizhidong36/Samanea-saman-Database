<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/8/29
  Time: 下午4:18
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Pathway Maps</title>
    <link href="image/favicon.ico" rel="shortcut icon">
  <%--  <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/TF.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/TF_24.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/TF_18.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/TF_15.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/TF.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/TF_6.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>


</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">
    <div class="body_center">

        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/TfAction_pathwaylist.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p>Pathway &nbsp;Maps</p>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Species:</p>
                    <select class="hmmer_db" name="alltf_species">

                        <option  value="Acer_truncatum">Acer truncatum [Ma Q,et al. Plant J. 2020]</option>
                        <%--                            <option  value="Aegle_marmelos">Actinidia chinensis [Pilkington SM,et al. BMC Genomics. 2018]</option>--%>
                        <option  value="Aegle_marmelos">Aegle marmelos [Citrus Pan-genome to Breeding Database]</option>
                        <option  value="Allium_cepa">Allium cepa [Finkers R,et al. G3 (Bethesda). 2021]</option>
                        <option  value="Allium_fistulosum">Allium fistulosum [Liao N,et al. Nat Commun. 2022]</option>
                        <option  value="Allium_sativum">Allium sativum [Sun X,et al. Mol Plant. 2020]</option>
                        <%--                            <option  value="">Ananas comosus</option>--%>
                        <option  value="Apium_graveolens">Apium graveolens [Li MY,et al. Hortic Res. 2020]</option>
                        <option  value="Arctium_lappa">Arctium lappa [Yang Y,et al. Mol Ecol Resour. 2022]</option>
                        <option  value="Areca_catechu">Areca catechu [ Yang Y,et al. Mol Ecol Resour. 2021]</option>
                        <%--                            <option  value="">Artemisia annua</option>--%>
                        <option  value="Asparagus_officinalis">Asparagus officinalis [Harkess A,et al. Nat Commun. 2017]</option>
                        <%--                            <option  value="Averrhoa_carambola">Atalantia buxifolia</option>--%>
                        <option  value="Averrhoa_carambola">Averrhoa carambola [Wu S,et al. Hortic Res. 2020]</option>
                        <option  value="Benincasa_hispida">Benincasa hispida [Xie D,et al. Nat Commun. 2019]</option>
                        <option  value="Beta_vulgaris">Beta vulgaris [Rodríguez Del Río Á,et al. Plant J. 2019]</option>
                        <option  value="Brassica_juncea">Brassica juncea [Yang J,et al. Nat Genet. 2016]</option>
                        <option  value="Brassica_napus">Brassica napus [Chalhoub B,et al. Science. 2014]</option>
                        <option  value="Brassica_nigra">Brassica nigra [Yang J,et al. Nat Genet. 2016]</option>
                        <option  value="Brassica_oleracea">Brassica oleracea [Liu S, et al. Nat Commun. 2014]</option>
                        <option  value="Brassica_rapa">Brassica rapa [Wang X,et al. Nat Genet. 2011]</option>
                        <option  value="Cajanus_cajan">Cajanus cajan [Marla SS,et al. Front Genet. 2020]</option>
                        <option  value="Camellia_sinensis">Camellia sinensis [Zhang W,et al. Nat Commun. 2020]</option>
                        <option  value="Camptotheca_acuminata">Camptotheca acuminata [Zhao D,et al. Gigascience. 2017]</option>
                        <option  value="Cannabis_sativa">Cannabis sativa [Gao S,et al. Hortic Res. 2020]</option>
                        <option  value="Capsella_rubella">Capsella rubella [Slotte T,et al. Nat Genet. 2013]</option>
                        <option  value="Capsicum_annuum">Capsicum annuum [Kim S,et al. Nat Genet. 2014]</option>
                        <option  value="Capsicum_baccatum">Capsicum baccatum [Kim S,et al. Genome Biol. 2017]</option>
                        <option  value="Carica_papaya">Carica papaya [Ming R,et al. Nature. 2008]</option>
                        <option  value="Castanea_mollissima">Castanea mollissima [Hoff KJ,et al. Bioinformatics. 2016]</option>
                        <%--                            <option  value="Cerasus_x_kanzakura">Catharanthus roseus</option>--%>
                        <option  value="Cerasus_x_kanzakura">Cerasus x kanzakura [Shirasawa K,et al. DNA Res. 2021]</option>
                        <%--                            <option  value="">Chiococca alba</option>--%>
                        <option  value="Chrysanthemum_nankingense">Chrysanthemum nankingense [Song C, Liu Y,et al. Mol Plant. 2018]</option>
                        <option  value="Cicer_arietinum">Cicer arietinum [Parween S,et al. Sci Rep. 2015]</option>
                        <option  value="Citropsis_gilletiana">Citropsis gilletiana [Liu H,et al. Mol Plant. 2022]</option>
                        <option  value="Citrullus_lanatus">Citrullus lanatus [Deng Y,et al. Mol Plant. 2022]</option>
                        <%--                            <option  value="Citrus_clementina">Citrus australasica</option>--%>
                        <option  value="Citrus_clementina">Citrus clementina [Grimplet J,et al. Curr Genomics. 2022]</option>
                        <option  value="Citrus_grandis">Citrus grandis [Liu H,et al. Mol Plant. 2022]</option>
                        <option  value="Citrus_hongheensis">Citrus hongheensis [Liu H,et al. Mol Plant. 2022]</option>
                        <option  value="Citrus_ichangensis">Citrus ichangensis [Wang X,et al. Nat Genet. 2017]</option>
                        <option  value="Citrus_mangshanensis">Citrus mangshanensis [Liu H,et al. Mol Plant. 2022]</option>
                        <option  value="Citrus_maxima">Citrus maxima [Liu H,et al. Mol Plant. 2022]</option>
                        <option  value="Citrus_medica">Citrus medica [Wang X,et al. Nat Genet. 2017]</option>
                        <option  value="Citrus_reticulatav1.0">Citrus reticulata [Wang L,et al. Mol Plant. 2018]</option>
                        <option  value="Citrus_sinensis">Citrus sinensis [Liu H,et al. Mol Plant. 2022]</option>
                        <option  value="Clausena_lansium_v1.0">Clausena lansium [Liu H,et al. Mol Plant. 2022]</option>
                        <option  value="Cocos_nucifera_tall">Cocos nucifera [Wang S,et al. Genome Biol. 2021]</option>
                        <option  value="Coffea_arabica">Coffea arabica [Tropical Crop Omics Database]</option>
                        <option  value="Coffea_canephora">Coffea canephora [Raharimalala N,et al. Sci Rep. 2021]</option>
                        <option  value="Coffea_eugenioides">Coffea eugenioides [Santos ML,et al. Plant Sci. 2022]</option>
                        <option  value="Coffea_humblotiana">Coffea humblotiana [Raharimalala N,et al. Sci Rep. 2021]</option>
                        <option  value="Corchorus_capsularis">Corchorus capsularis [Islam MS,et al. Nat Plants. 2017]</option>
                        <option  value="Corchorus_olitorius">Corchorus olitorius [Sarkar D,et al. Genom Data. 2017]</option>
                        <option  value="Coriandrum_sativum">Coriandrum sativum [Song X,et al. Plant Biotechnol J. 2020]</option>
                        <option  value="Crataegus_pinnatifida_var_major_Genome_v1.0">Crataegus pinnatifida [Zhang T,et al. J Integr Plant Biol. 2022]</option>
                        <option  value="Cucumis_melo">Cucumis melo [Li G,et al. Hortic Res. 2023]</option>
                        <option  value="Cucumis_sativus">Cucumis sativus [Huang S,et al. Nat Genet. 2009]</option>
                        <option  value="Cucurbita_argyrosperma">Cucurbita argyrosperma [Barrera-Redondo J,et al. Mol Plant. 2019]</option>
                        <option  value="Cucurbita_maxima">Cucurbita maxima [Sun H,et al. Mol Plant. 2017]</option>
                        <option  value="Cucurbita_moschata">Cucurbita moschata [Barrera-Redondo J,et al. Mol Plant. 2019]</option>
                        <option  value="Cucurbita_pepo">Cucurbita pepo [Montero-Pau J,et al. Plant Biotechnol J. 2018]</option>
                        <option  value="Cuscuta_australis">Cuscuta australis [Sun G,et al. Nat Commun. 2018]</option>
                        <option  value="Cynara_cardunculus">Cynara cardunculus [Scaglione D,et al. Sci Rep. 2016]</option>
                        <option  value="Dendrobium_catenatum">Dendrobium catenatum [Zhang GQ,et al. Sci Rep. 2016]</option>
                        <option  value="Dianthus_caryophyllus">Dianthus caryophyllus [Yagi M,et al. DNA Res. 2014]</option>
                        <option  value="Dimocarpus_longan_longan_JDB">Dimocarpus longan Lour [Wang J,et al. Hortic Res. 2022]</option>
                        <option  value="Dionaea_muscipula">Dionaea muscipula [Palfalvi G,et al. Curr Biol. 2020]</option>
                        <option  value="Dioscorea_dumetorum">Dioscorea dumetorum [Palfalvi G,et al. Curr Biol. 2020]</option>
                        <option  value="Dioscorea_rotundata">Dioscorea rotundata [Tamiru M,et al. BMC Biol. 2017]</option>
                        <option  value="Diospyros_kaki_Thumb">Diospyros kaki Thumb [https://drive.google.com/drive/folders/1at4LgvkDJ7E3itCrCBS0EWvdlvXbriDt]</option>
                        <option  value="Diospyros_lotus">Diospyros lotus [Akagi T,et al. PLoS Genet. 2020]</option>
                        <option  value="Durio_zibethinus">Durio zibethinus [Teh BT,et al. Nat Genet. 2017]</option>
                        <option  value="Erigeron_breviscapus">Erigeron breviscapus [Yang J,et al. Gigascience. 2017]</option>
                        <option  value="Eriobotrya_japonica">Eriobotrya japonica [Jiang S,et al. Gigascience. 2020]</option>
                        <option  value="Eschscholzia_californica">Eschscholzia californica [Hori K,et al. Plant Cell Physiol. 2018]</option>
                        <option  value="Euryale_ferox">Euryale ferox [Yang Y,et al. Nat Plants. 2020]</option>
                        <option  value="Ficus_carica">Ficus carica [Mori K,et al. Sci Rep. 2017]</option>
                        <option  value="Fortunella_hindsii_v1.0">Fortunella hindsii [Liu H,et al. Mol Plant. 2022]</option>
                        <option  value="Fragaria_vesca">Fragaria vesca [Zhou Y,et al. Hortic Res. 2023]</option>
                        <%--                            <option  value="Ginkgo_biloba">Gardenia jasminoides</option>--%>
                        <option  value="Ginkgo_biloba">Ginkgo biloba [Guan R,et al. Gigascience. 2016]</option>
                        <option  value="Glebionis_coronaria">Glebionis coronaria [Wang S,et al. DNA Res. 2022]</option>
                        <option  value="Gnetum_montanum">Gnetum montanum [Wan T,et al. Nat Plants. 2018]</option>
                        <option  value="Handroanthus_impetiginosus">Handroanthus impetiginosus [Sunil M,et al. DNA Res. 2014]</option>
                        <option  value="Hibiscus_cannabinus">Hibiscus cannabinus [Zhang L,et al. Plant Biotechnol J. 2020]</option>
                        <option  value="Hibiscus_syriacus">Hibiscus syriacus [Kim YM,et al. DNA Res. 2017]</option>
                        <%--                            <option  value="Ipomoea_batatas">Ipomoea aquatica</option>--%>
                        <option  value="Ipomoea_batatas">Ipomoea batatas [Li M,et al. BMC Plant Biol. 2019]</option>
                        <option  value="Ipomoea_nil">Ipomoea nil [Hoshino A,et al. Nat Commun. 2016]</option>
                        <option  value="Juglans_regia">Juglans regia [Stevens KA,et al. G3 (Bethesda). 2018]</option>
                        <option  value="Lablab_purpureus">Lablab purpureus [Chang Y,et al. Gigascience. 2019]</option>
                        <option  value="Lagenaria_siceraria">Lagenaria siceraria [Wu S,et al. Plant J. 2017]</option>
                        <option  value="Litchi_chinensis_lychee_FZX">Litchi chinensis Sonn [Hu G,et al. Nat Genet. 2022]</option>
                        <option  value="Luffa_acutangula">Luffa acutangula [Pootakham W,et al. Mol Ecol Resour. 2021]</option>
                        <option  value="Luffa_cylindrica">Luffa cylindrica [Zhang T,et al. Mol Ecol Resour. 2020]</option>
                        <option  value="Luvunga_scandens_v1.0">Luvunga scandens [Liu H,et al. Mol Plant. 2022]</option>
                        <option  value="Macleaya_cordata">Macleaya cordata [Liu X,et al. Mol Plant. 2017]</option>
                        <option  value="Malus_baccata_v1.0">Malus baccata [Chen X,et al. G3 (Bethesda). 2019]</option>
                        <option  value="Malus_domestica_cv_Gala_Haploid">Malus domestica [Daccord N,et al. Nat Genet. 2017]</option>
                        <option  value="Malus_fusca v1.1">Malus fusca [Mansfeld BN,et al. Plant J. 2023]</option>
                        <option  value="Malus_sieversii_Haploid_Consensus">Malus sieversii [Sun X,et al. Nat Genet. 2020]</option>
                        <option  value="Mangifera_indica_mango_Tommy-Atkins">Mangifera indica [Mango Genome Consortium,et al. BMC Plant Biol. 2021]</option>
                        <option  value="Marchantia_polymorpha">Marchantia polymorpha [Montgomery SA,et al. Curr Biol. 2020]</option>
                        <%--                            <option  value="Mesembryanthemum_crystallinum">Medicago sativa [Chen H,et al. Nat Commun. 2020]</option>--%>
                        <option  value="Mesembryanthemum_crystallinum">Mesembryanthemum crystallinum [Shen S,et al. Plant Biotechnol J. 2022]</option>
                        <option  value="Momordica_charantia">Momordica charantia [Urasaki N,et al. DNA Res. 2017]</option>
                        <option  value="Moringa_oleifera">Moringa oleifera [Chang Y,et al. Gigascience. 2019]</option>
                        <option  value="Morus_notabilisT2T">Morus notabilis [Ma B,et al. Hortic Res. 2023]</option>
                        <option  value="Murraya_paniculata_v1.0">Murraya paniculata [CPBD: Citrus Pan-genome to Breeding Database]</option>
                        <option  value="Musa_acuminata_banana_DH-Pahang">Musa acuminata [D'Hont A,et al. Nature. 2012]</option>
                        <%--                            <option  value="Nelumbo_nucifera">Musa itinerans</option>--%>
                        <option  value="Nelumbo_nucifera">Nelumbo nucifera [Shi T,et al. Mol Biol Evol. 2020]</option>
                        <option  value="Nicotiana_sylvestris">Nicotiana sylvestris [Sierro N,et al. Genome Biol. 2013]</option>
                        <option  value="Ocimum_basilicum">Ocimum basilicum [Bornowski N,et al. DNA Res. 2020]</option>
                        <option  value="Olea_europaea">Olea europaea [Cruz F,et al. Gigascience. 2016]</option>
                        <option  value="Origanum_majorana">Origanum majorana [Bornowski N,et al. DNA Res. 2020]</option>
                        <option  value="Origanum_vulgare">Origanum vulgare [Bornowski N,et al. DNA Res. 2020]</option>
                        <option  value="Panax_ginseng">Panax ginseng [Kim NH,et al. Plant Biotechnol J. 2018]</option>
                        <option  value="Panax_notoginseng">Panax notoginseng [https://ftp.cngb.org/pub/CNSA/data2/CNP0001042/CNS0223752/CNA0013972/]</option>
                        <option  value="Panicum_miliaceum">Panicum miliaceum [Shi J,et al. Nat Commun. 2019]</option>
                        <option  value="Papaver_somniferum">Papaver somniferum [Guo L,et al. Science. 2018]</option>
                        <option  value="Perilla_frutescens">Perilla frutescens [Tamura K,et al. DNA Res. 2023]</option>
                        <option  value="Persea_americana">Persea americana [Rendón-Anaya M,et al. Proc Natl Acad Sci U S A. 2019]</option>
                        <%--                            <option  value="Phaseolus_acutifolius">Phalaenopsis equestris</option>--%>
                        <option  value="Phaseolus_acutifolius">Phaseolus acutifolius [Moghaddam SM,et al. Nat Commun. 2021]</option>
                        <option  value="Phaseolus_vulgaris">Phaseolus vulgaris [Vlasova A,et al. Genome Biol. 2016]</option>
                        <option  value="Phoenix_dactylifera">Phoenix dactylifera [ArecaceaeMDB: Arecaceae Multi-omics Database]</option>
                        <option  value="Physalis_pubescens_v1.0">Physalis pubescens [Lu J,et al. Hortic Res. 2021]</option>
                        <option  value="Piper_nigrum">Piper nigrum [Hu L,et al. Nat Commun. 2019]</option>
                        <option  value="Pisum_sativum">Pisum sativum [Yuanyuan Hao,et al. Scientia Horticulturae. 2021]</option>
                        <option  value="Platycodon_grandiflorus">Platycodon grandiflorus [Kim J,et al. Hortic Res. 2020]</option>
                        <option  value="Poncirus_trifoliata_v1.0">Poncirus trifoliata [Grimplet J,et al. Curr Genomics. 2022]</option>
                        <option  value="Populus_alba">Populus alba [Ma J,et al. Plant Biotechnol J. 2019]</option>
                        <option  value="Potentilla_anserina_Genome v1.0">Potentilla anserina [Gan X,et al. Genes (Basel). 2021]</option>
                        <option  value="Prunus_armeniaca_Marouch">Prunus armeniaca [Groppi A,et al. Nat Commun. 2021]</option>
                        <option  value="Prunus_avium_Tieton_Genome_v2.0">Prunus avium [Wang J,et al. PeerJ. 2020]</option>
                        <option  value="Prunus_dulcis_Texas_Genome v2.0">Prunus dulcis [Alioto T,et al. Plant J. 2020]</option>
                        <option  value="Prunus_mume_Tortuosa">Prunus mume [Zheng T,et al. New Phytol. 2022]</option>
                        <option  value="Prunus_persica_Zhongyoutao">Prunus persica [Genome Database for Rosaceae]</option>
                        <%--                            <option  value="Prunus_yedoensis">Prunus salicina</option>--%>
                        <option  value="Prunus_yedoensis">Prunus yedoensis [Shirasawa K,et al. DNA Res. 2019]</option>
                        <option  value="Punica_granatum">Punica granatum [Qin G,et al. Plant J. 2017]</option>
                        <option  value="Raphanus_sativus">Raphanus sativus [Shirasawa K,et al. DNA Res. 2020]</option>
                        <option  value="Rosa_chinensis_Old_Blush_homozygous">Rosa chinensis [Raymond O,et al. Nat Genet. 2018]</option>
                        <option  value="Rosa_multiflora">Rosa multiflora [Nakamura N,et al. DNA Res. 2018]</option>
                        <option  value="Rosmarinus_officinalis">Rosmarinus officinalis [Bornowski N,et al. DNA Res. 2020]</option>
                        <option  value="Rubus_occidentalis_Whole_Genome_v3.0">Rubus occidentalis [VanBuren R,et al. Gigascience. 2018]</option>
                        <%--                            <option  value="Saccharum_spontaneum_sugarcane_AP85_44">Saccharum officinarum</option>--%>
                        <option  value="Saccharum_spontaneum_sugarcane_AP85_44">Saccharum spontaneum [Zhang J,et al. Nat Genet. 2018]</option>
                        <option  value="Salvia_splendens">Salvia splendens [Dong AX,et al. Gigascience. 2018]</option>
                        <option  value="Sechium_edule">Sechium edule [Fu A,et al. Hortic Res. 2021]</option>
                        <%--                            <option  value="">Selaginella moellendorffii</option>--%>
                        <option  value="Senna_tora">Senna tora [Kang SH,et al. Nat Commun. 2020]</option>
                        <option  value="Sinapis_alba">Sinapis alba [Kumari P,et al. PLoS One. 2020]</option>
                        <option  value="Siraitia_grosvenorii">Siraitia grosvenorii [Xia M,et al. Gigascience. 2018]</option>
                        <option  value="Solanum_lycopersicum">Solanum lycopersicum [Xue JY,et al. Hortic Res. 2023]</option>
                        <option  value="Solanum_melongena">Solanum melongena [Barchi L,et al. Sci Rep. 2019]</option>
                        <option  value="Solanum_tuberosum">Solanum tuberosum [Zhou Q,et al. Nat Genet. 2020]</option>
                        <option  value="Spinacia_oleracea">Spinacia oleracea [Xu C,et al. Nat Commun. 2017]</option>
                        <option  value="Strobilanthes_cusia">Strobilanthes cusia [Xu W,et al. Plant J. 2020]</option>
                        <option  value="Tarenaya_hassleriana">Tarenaya hassleriana [Cheng S,et al. Plant Cell. 2013]</option>
                        <option  value="Theobroma_cacao_cacao_B97_61">Theobroma cacao [Argout X,et al. BMC Genomics. 2017]</option>
                        <option  value="Thlaspi_arvense(v1.1)">Thlaspi arvense [Geng Y,et al. BMC Biol. 2021]</option>
                        <option  value="Toona_sinensis">Toona sinensis [Ji YT,et al. Mol Ecol Resour. 2021]</option>
                        <option  value="Trichosanthes_anguina">Trichosanthes anguina [Ma L,et al. Hortic Res. 2020]</option>
                        <option  value="Trifolium_pratense">Trifolium pratense [De Vega JJ,et al. Sci Rep. 2015]</option>
                        <option  value="Vaccinium_darrowi">Vaccinium darrowii [Cui F,et al. Plant Commun. 2022]</option>
                        <option  value="Vaccinium_duclouxii">Vaccinium duclouxii [Zeng T,et al. Hortic Res. 2023]</option>
                        <option  value="Vaccinium_macrocarpon">Vaccinium macrocarpon [Diaz-Garcia L,et al. Front Plant Sci. 2021]</option>
                        <option  value="Vaccinium_myrtillus_isolate_NK2018">Vaccinium myrtillus [Wu C,et al. Mol Ecol Resour. 2022]</option>
                        <option  value="Vanilla_planifolia">Vanilla planifolia [Hasing T,et al. Nat Food. 2020]</option>
                        <option  value="Vigna_unguiculata">Vigna unguiculata [Xia Q,et al. Sci Data. 2019]</option>
                        <option  value="Vitis_vinifera_L">Viti vinifera [Xiaoya Shi,et al. Horticulture Research. 2023]</option>
                        <%--                            <option  value="">Zingiber officinale</option>--%>
                        <option  value="Ziziphus_jujuba">Ziziphus jujuba [Huang J,et al. PLoS Genet. 2016]</option>


                    </select>
                </div>
            </div>

<%--            <div class="form_par">--%>
<%--                <div class="f_t_lab">--%>
<%--                    <p>Select Family:</p>--%>
<%--                    <s:iterator value="allTF" var="tffamily">--%>
<%--                        <input value="<s:property value="#tffamily.tf_name"/>" class="tran_pro" type="radio" name="alltf_family">--%>
<%--                        <label class="tran_pro_label"> <s:property value="#tffamily.tf_name"/></label>--%>
<%--                    </s:iterator>--%>

<%--                </div>--%>
<%--            </div>--%>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Search Pathway Maps:</p>
                    <input type="button" value="Example" class="blast_example">
                    <input type="submit" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>

    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
