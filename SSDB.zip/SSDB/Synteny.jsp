<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/3
  Time: 下午8:10
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <link rel="stylesheet" href="css/Synteny.css">
</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">
    <div class="body_center">
        <form action="#">
            <div class="form_top">
                <p>Synteny &nbsp;&nbsp;Finder</p>
            </div>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Fasta Reference Sequence:</p>
                    <textarea class="ref_seq"></textarea>
                </div>
            </div>
            <div class="form_refgff">
                <div class="f_t_lab">
                    <p>Enter Fasta Reference GFF:</p>
                    <textarea class="ref_gff"></textarea>
                </div>
            </div>
            <div class="form_queryseq">
                <div class="f_t_lab">
                    <p>Enter Fasta Query Sequence:</p>
                    <textarea class="query_seq"></textarea>
                </div>
            </div>
            <div class="form_querygff">
                <div class="f_t_lab">
                    <p>Enter Fasta Reference GFF:</p>
                    <textarea class="query_gff"></textarea>
                </div>
            </div>
            <div class="form_evalue">
                <div class="f_t_lab">

                    <p>Optional BLAST+ Parameters:</p>
                    <label>Expect Threshold:</label>
                    <select class="blast_eval">
                        <option>0.000001</option>
                        <option>0.00001</option>
                        <option>0.0001</option>
                        <option>0.001</option>
                        <option>0.01</option>
                        <option>0.1</option>
                        <option>1.0</option>
                    </select>
                </div>
            </div>

            <div class="form_gap">
                <div class="f_t_lab">
                    <p>Optional MCScanX Parameters:</p>
                    <label>gap:</label>
                    <select class="mscans_m">
                        <option>25</option>
                        <option>20</option>
                        <option>15</option>
                        <option>10</option>
                        <option>5</option>
                        <option>4</option>
                        <option>3</option>
                        <option>2</option>
                        <option>1</option>
                    </select>
                </div>
            </div>


            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Synteny Gene Search:</p>
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>

<!--footer-->
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript">

    $(function () {

    function turn(str) {

        while (str.indexOf("\n") != -1) {
            str = str.substring(0, str.indexOf("\n")) + "<br>"
                + str.substring(str.indexOf("\n") + 1);
        }
        while (str.indexOf(" ") != -1) {
            str = str.substring(0, str.indexOf(" ")) + "\C6MC6M"
                + str.substring(str.indexOf(" ") + 1);
        }
        while (str.indexOf("|") != -1) {
            str = str.substring(0, str.indexOf("|")) + "\C9MC9M"
                + str.substring(str.indexOf("|") + 1);
        }
        while (str.indexOf("_") != -1) {
            str = str.substring(0, str.indexOf("_")) + "\C3MC3M"
                + str.substring(str.indexOf("_") + 1);
        }
        while (str.indexOf("#") != -1) {
            str = str.substring(0, str.indexOf("#")) + "\C5MC5M"
                + str.substring(str.indexOf("#") + 1);
        }
        while (str.indexOf("=") != -1) {
            str = str.substring(0, str.indexOf("=")) + "\C7MC7M"
                + str.substring(str.indexOf("=") + 1);
        }
        while (str.indexOf(".") != -1) {
            str = str.substring(0, str.indexOf(".")) + "\C8MC8M"
                + str.substring(str.indexOf(".") + 1);
        }
        while (str.indexOf("/") != -1) {
            str = str.substring(0, str.indexOf("/")) + "\C4MC4M"
                + str.substring(str.indexOf("/") + 1);
        }
        while (str.indexOf("-") != -1) {
            str = str.substring(0, str.indexOf("-")) + "\C2MC2M"
                + str.substring(str.indexOf("-") + 1);
        }
        while (str.indexOf("+") != -1) {
            str = str.substring(0, str.indexOf("+")) + "\C1MC1M"
                + str.substring(str.indexOf("+") + 1);
        }
        while (str.indexOf(":") != -1) {
            str = str.substring(0, str.indexOf(":")) + "\M6666MM6666M"
                + str.substring(str.indexOf(":") + 1);
        }
        while (str.indexOf(";") != -1) {
            str = str.substring(0, str.indexOf(";")) + "\M1111MM1111M"
                + str.substring(str.indexOf(";") + 1);
        }
        while (str.indexOf(" ") != -1) {
            str = str.substring(0, str.indexOf(" ")) + "\M2222MM2222M"
                + str.substring(str.indexOf(" ") + 1);
        }
        while (str.indexOf("\t") != -1) {
            str = str.substring(0, str.indexOf("\t")) + "\M3333MM3333M"
                + str.substring(str.indexOf("\t") + 1);
        }
        while (str.indexOf(",") != -1) {
            str = str.substring(0, str.indexOf(",")) + "\M4444MM4444M"
                + str.substring(str.indexOf(",") + 1);
        }
        while (str.indexOf("    ") != -1) {
            str = str.substring(0, str.indexOf("    ")) + "\Cc1MCc1M"
                + str.substring(str.indexOf("   ") + 1);
        }
        return str;
    };

        $(".blast_sb").click(function () {

            var ref_seq1 = $(".ref_seq").val();
            var ref_gff1 = $(".ref_gff").val();
            var query_seq1 = $(".query_seq").val();
            var query_gff1 = $(".query_gff").val();
            var blast_eval = $(".blast_eval").val();
            var mscans_m = $(".mscans_m").val();


            alert(ref_seq1);
            alert(ref_gff1);
            alert(query_seq1);
            alert(query_gff1);
            alert(blast_eval);
            alert(mscans_m);


            var ref_seq = turn(ref_seq1);
            var ref_gff = turn(ref_gff1);
            var query_seq = turn(query_seq1);
            var query_gff = turn(query_gff1);


            $.post('${pageContext.request.contextPath}/Synteny_search.action?ref_seq='+ref_seq
                +'&ref_gff='+ref_gff+'&query_seq='+query_seq+'&query_gff='+query_gff
                + '&blast_eval=' + blast_eval + '&mscans_m=' + mscans_m,function (data) {


            },"json");


            /*$(window).attr('location','<%--${pageContext.request.contextPath}--%>/Synteny_search.action?ref_seq='+ref_seq
                +'&ref_gff='+ref_gff+'&query_seq='+query_seq+'&query_gff='+query_gff
                + '&blast_eval=' + blast_eval + '&mscans_m=' + mscans_m);*/
        });
    });
</script>
</body>
</html>
