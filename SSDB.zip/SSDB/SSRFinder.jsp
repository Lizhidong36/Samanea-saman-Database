<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/1/14
  Time: 下午2:29
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>SSR Finder</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">--%>
    <%--<link rel="stylesheet" href="css/motiftools.css">
    <link rel="stylesheet" href="css/Motif_enrichment.css">--%>
   <%-- <link rel="stylesheet" href="css/SSRFinder.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/SSRFinder_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/SSRFinder_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/SSRFinder_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/SSRFinder.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/SSRFinder_6.css">');
        }
    </script>


</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
<%--    <div id="userguidelink">--%>
<%--        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=SSR_Finder_1.zip" title="userguide and test data">--%>
<%--            <p class="userguidelink_p">Userguide and demo file</p>--%>
<%--        </a>--%>
<%--    </div>--%>
    <div class="body_center">
        <form target="_blank" id="mot_enr_form" action="${pageContext.request.contextPath}/ssr_finder.action" method="post" enctype="multipart/form-data">
            <div class="form_top">
                <p>SSR &nbsp;Finder</p>
            </div>
            <div class="form_type">
                <div class="f_d_div">
                    <span class="intro_p">
                        SSR Finder tools build by MISA program. You can paste or upload your sequence(s) to find SSR and design primer by using SSR Finder tools.
                    </span>
                </div>
            </div>
            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Fasta Query Sequence:</p>
                    <textarea class="blast_seq" name="blast_seq" placeholder="Paste query sequence(s) in FASTA format here ...
For example:
>AT1G01073
ATGCTTATCAGTATCAGCCCACTGATATTTGTGATACCAGTATCATCTGACGTGGCTTCTTCTGATTGGTTACATTTGACAAAAGCAAAAAATATTATATATATTTATTAA"></textarea>

                    <input type="file" name="sequpload" id="fileupload">
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit SSR  Finder:</p>
                    <input type="button" value="Example" class="blast_example">
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        function turn(str) {

            while (str.indexOf("\n") != -1) {
                str = str.substring(0, str.indexOf("\n")) + "<br>"
                    + str.substring(str.indexOf("\n") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\C6MC6M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("|") != -1) {
                str = str.substring(0, str.indexOf("|")) + "\C9MC9M"
                    + str.substring(str.indexOf("|") + 1);
            }
            while (str.indexOf("_") != -1) {
                str = str.substring(0, str.indexOf("_")) + "\C3MC3M"
                    + str.substring(str.indexOf("_") + 1);
            }
            while (str.indexOf("#") != -1) {
                str = str.substring(0, str.indexOf("#")) + "\C5MC5M"
                    + str.substring(str.indexOf("#") + 1);
            }
            while (str.indexOf("=") != -1) {
                str = str.substring(0, str.indexOf("=")) + "\C7MC7M"
                    + str.substring(str.indexOf("=") + 1);
            }
            while (str.indexOf(".") != -1) {
                str = str.substring(0, str.indexOf(".")) + "\C8MC8M"
                    + str.substring(str.indexOf(".") + 1);
            }
            while (str.indexOf("/") != -1) {
                str = str.substring(0, str.indexOf("/")) + "\C4MC4M"
                    + str.substring(str.indexOf("/") + 1);
            }
            while (str.indexOf("-") != -1) {
                str = str.substring(0, str.indexOf("-")) + "\C2MC2M"
                    + str.substring(str.indexOf("-") + 1);
            }
            while (str.indexOf("+") != -1) {
                str = str.substring(0, str.indexOf("+")) + "\C1MC1M"
                    + str.substring(str.indexOf("+") + 1);
            }
            while (str.indexOf(":") != -1) {
                str = str.substring(0, str.indexOf(":")) + "\M6666MM6666M"
                    + str.substring(str.indexOf(":") + 1);
            }
            while (str.indexOf(";") != -1) {
                str = str.substring(0, str.indexOf(";")) + "\M1111MM1111M"
                    + str.substring(str.indexOf(";") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\M2222MM2222M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("\t") != -1) {
                str = str.substring(0, str.indexOf("\t")) + "\M3333MM3333M"
                    + str.substring(str.indexOf("\t") + 1);
            }
            while (str.indexOf(",") != -1) {
                str = str.substring(0, str.indexOf(",")) + "\M4444MM4444M"
                    + str.substring(str.indexOf(",") + 1);
            }
            while (str.indexOf("    ") != -1) {
                str = str.substring(0, str.indexOf("    ")) + "\Cc1MCc1M"
                    + str.substring(str.indexOf("   ") + 1);
            }
            return str;
        };

        $('.blast_sb').click(function () {

            var blast_seq = $(".blast_seq").val();
            var sequpload = $('#fileupload').val();

            if(blast_seq == "" && sequpload == ""){
                alert("please upload your sequence");
            }
            if(blast_seq != "" && sequpload != ""){
                alert("please input or upload sequence file!");
            }
            if(blast_seq != "" && sequpload == ""){

                cont1 = turn(blast_seq);

                var new_blast_seq = $(".blast_seq").val(cont1);

                $("#mot_enr_form").submit();
            }
            if(blast_seq == "" && sequpload != ""){

                $("#mot_enr_form").submit();
            }

        });

        $(".blast_example").click(function () {


            $(".blast_seq").val(">AT1G01030\n" +
                "ATGGATCTATCCCTGGCTCCGACAACAACAACAAGTTCCGACCAAGAACAAGACAGAGACCAAGAATTAACCTCCAACATCGGAGCAAGCAGCAGCTCCGGTCCCAGCGGAAACAACAACAACCTTCCGATGATGATGATTCCACCTCCGGAGAAAGAACACATGTTCGACAAAGTGGTAACACCAAGCGACGTCGGAAAACTCAACAGACTCGTGATCCCTAAACAACACGCTGAGAGGTATTTCCCTCTAGACTCCTCAAACAACCAAAACGGCACGCTTTTGAACTTCCAAGACAGAAACGGCAAGATGTGGAGATTCCGTTACTCGTATTGGAACTCTAGCCAGAGCTACGTTATGACCAAAGGATGGAGCCGTTTCGTCAAAGAGAAAAAGCTCGATGCAGGAGACATTGTCTCTTTCCAACGAGGCATCGGAGATGAGTCAGAAAGATCCAAACTTTACATAGATTGGAGGCATAGACCCGACATGAGCCTCGTTCAAGCACATCAGTTTGGTAATTTTGGTTTCAATTTCAATTTCCCGACCACTTCTCAATATTCCAACAGATTTCATCCATTGCCAGAATATAACTCCGTCCCGATTCACCGGGGCTTAAACATCGGAAATCACCAACGTTCCTATTATAACACCCAGCGTCAAGAGTTCGTAGGGTATGGTTATGGGAATTTAGCTGGAAGGTGTTACTACACGGGATCACCGTTGGATCATAGGAACATTGTTGGATCAGAGCCGTTGGTTATAGACTCAGTCCCTGTGGTTCCCGGGAGATTAACTCCGGTGATGTTACCGCCGCTTCCTCCGCCTCCTTCTACGGCGGGAAAGAGACTAAGGCTCTTTGGGGTGAATATGGAATGTGGCAATGACTATAATCAACAAGAAGAGTCATGGTTGGTGCCACGTGGCGAAATTGGTGCATCTTCTTCTTCTTCTTCAGCTCTACGACTAAATTTATCGACTGATCATGATGATGATAATGATGATGGTGATGATGGCGATGATGATCAATTTGCTAAGAAAGGGAAGTCTTCACTTTCTCTCAATTTCAATCCATGA\n"
                + ">AT1G01260\n" + "ATGAATATTGGTCGCCTAGTGTGGAACGAGGACGATAAAGCGATTGTTGCGTCATTACTGGGCAAACGAGCTCTCGATTACTTGCTTTCCAACTCTGTTTCCAATGCTAATCTCTTGATGACTCTAGGAAGCGACGAGAATCTGCAGAACAAGCTCTCGGATCTCGTCGAGAGACCCAACGCTTCTAATTTCTCTTGGAACTACGCCATTTTCTGGCAGATTTCCAGGTCAAAGGCCGGAGATTTGGTTCTCTGTTGGGGCGATGGATATTGCAGAGAGCCTAAAGAAGGAGAGAAATCAGAGATCGTTAGGATTCTAAGTATGGGAAGAGAAGAAGAAACGCATCAGACTATGAGAAAGAGAGTATTGCAAAAGCTTCATGATTTGTTTGGTGGCTCAGAAGAAGAGAACTGTGCTTTAGGACTAGATAGAGTTACTGACACTGAGATGTTTCTTCTTTCTTCTATGTATTTCTCATTCCCTCGAGGTGAAGGTGGTCCAGGCAAGTGTTTTGCCTCTGCTAAACCTGTTTGGTTATCCGATGTCGTCAATTCGGGTTCTGATTATTGCGTTAGATCGTTTCTTGCTAAATCTGCTGGCATTCAGACTGTTGTTTTGGTTCCTACTGATCTTGGTGTTGTTGAGTTAGGCTCAACTTCATGTTTGCCTGAAAGTGAAGACTCAATCTTGTCTATAAGATCATTGTTTACCAGTAGTTTGCCTCCGGTTAGAGCTGTTGCTTTACCTGTTACTGTAGCTGAAAAGATTGATGATAACAGAACGAAGATATTCGGCAAGGATTTGCACAATTCAGGGTTTCTTCAACATCATCAGCATCACCAACAACAACAACAACAACCACCGCAACAGCAACAGCATAGACAGTTTAGAGAGAAACTCACGGTTAGAAAAATGGATGATAGAGCTCCCAAGAGATTAGATGCTTATCCGAATAATGGGAACAGGTTTATGTTTTCGAACCCAGGCACCAACAACAACACTCTTCTGAGTCCTACTTGGGTTCAACCTGAGAACTACACGAGGCCAATCAACGTGAAGGAAGTTCCAAGCACGGATGAGTTCAAGTTTTTACCTTTGCAGCAATCATCGCAGAGGCTGCTTCCTCCTGCTCAAATGCAGATAGATTTCTCTGCTGCGAGTTCAAGGGCTTCAGAGAATAATTCAGATGGAGAAGGAGGAGGGGAATGGGCAGATGCAGTGGGTGCTGATGAATCTGGTAACAACAGACCAAGAAAACGCGGAAGGAGACCTGCCAACGGAAGAGCGGAAGCTTTGAACCATGTAGAAGCAGAGAGGCAGAGGCGTGAGAAGCTTAACCAGAGGTTTTACGCTCTGAGATCCGTTGTTCCCAACATATCCAAGATGGACAAAGCGTCCTTGTTGGGAGACGCGGTTTCTTATATAAACGAGCTTCACGCGAAGCTAAAGGTCATGGAAGCAGAGAGAGAGAGGTTAGGGTATAGCTCAAATCCACCTATCAGCTTGGATTCAGATATAAATGTTCAAACCTCAGGTGAAGATGTCACAGTGAGGATAAACTGTCCGTTGGAGTCTCATCCGGCTTCCAGAATCTTCCATGCGTTTGAAGAGAGTAAAGTAGAAGTGATAAACTCGAACCTGGAAGTTTCTCAGGACACAGTGTTGCATACGTTTGTAGTCAAATCTGAAGAATTAACGAAAGAGAAGCTGATATCGGCCTTGTCTAGAGAGCAAACAAATTCAGTTCAGTCAAGAACATCATCAGGTAGATAG\n"
                  );

        });

    });
</script>
</body>
</html>
