<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/12/6
  Time: 上午10:38
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Gene Family</title>
    <link href="image/favicon.ico" rel="shortcut icon">

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>


<div id="body">
    <div class="body_center">

        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/TfAction_list.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p><s:property value="#session.allgf_family"/></p>
            </div>

            <div class="form_database" id="ft_title">

                <div class="tf_id">
                    Gene &nbsp;ID
                </div>
                <div class="tf_cds">
                    CDS
                </div>
                <div class="tf_pep">
                    PEP
                </div>
                <div class="pfam_num">
                    Pfam &nbsp;ID
                </div>
               <%-- <div class="tf_domain">
                    Domain
                </div>
                <div class="tf_evalue">
                    Pfam &nbsp;Evalue
                </div>--%>
                <div class="gf_name">
                    Domain
                </div>
            </div>


            <s:iterator value="allgfamily" var="allgf">
                <div class="form_database">

                    <div class="tf_id">
<%--                        <a target="_blank" href="http://tbir.njau.edu.cn/JBrowse-1.16.6/?data=<s:property value="#session.jbliks"/>&loc=<s:property value="#allgf.allgf_geneid" />&tracks=DNA%2CGFF3%20Annotations&highlight=">--%>
                        <a  href="#">

                        <s:property value="#allgf.allgf_geneid" />

                        </a>

                    </div>
                    <div class="tf_cds">
                        <a href="${pageContext.request.contextPath}/BatchQuery_list.action?organism_type=<s:property value="#session.tfile_cds"/>&content=<s:property value="#allgf.allgf_geneid" />" target="_blank">
                            CDS
                        </a>
                    </div>
                    <div class="tf_pep">
                        <a href="${pageContext.request.contextPath}/BatchQuery_list.action?organism_type=<s:property value="#session.tfile_pep"/>&content=<s:property value="#allgf.allgf_geneid" />" target="_blank">
                            PEP
                        </a>
                    </div>
                    <div class="pfam_num">
                        <a href="http://pfam.xfam.org/family/<s:property value="#allgf.allgf_pfamid" />" target="_blank">
                            <s:property value="#allgf.allgf_pfamid" />
                        </a>

                    </div>
                    <%--<div class="tf_domain">
                        <s:property value="#alltf.alltf_domain" />
                    </div>
                    <div class="tf_evalue">
                        <s:property value="#alltf.alltf_evalue" />
                    </div>--%>
                    <div class="gf_name">
                        <s:property value="#allgf.allgf_family" />
                    </div>
                    <span class="tf_species">
                        <s:property value="#allgf.allgf_species" />
                    </span>
                </div>
            </s:iterator>



        </form>

    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
