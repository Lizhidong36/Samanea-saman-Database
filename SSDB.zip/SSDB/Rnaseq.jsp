<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/6/30
  Time: 下午5:39
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<%@ taglib prefix="sL" uri="/struts-tags" %>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/body_kuangjia.css">
    <link rel="stylesheet" href="css/Rnaseq.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/body_kuangjia_24.css">');
            document.write('<link rel="stylesheet" href="css/Rnaseq_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/body_kuangjia_18.css">');
            document.write('<link rel="stylesheet" href="css/Rnaseq_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/body_kuangjia_15.css">');
            document.write('<link rel="stylesheet" href="css/Rnaseq_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/body_kuangjia.css">');
            document.write('<link rel="stylesheet" href="css/Rnaseq.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/body_kuangjia_6.css">');
            document.write('<link rel="stylesheet" href="css/Rnaseq_6.css">');
        }
    </script>


</head>
<body>
<%@include file="header.jsp"%>

<%--body--%>
<div id="body">
    <div class="body_center">
        <form action="#">
            <div class="form_top">

                <p><s:property value="spe_geo_num"/></p>
            </div>

            <div class="form_function">

                <div class="form_function_species">
                    <div class="topname">
                        Overview
                    </div>

                    <s:iterator value="alloverview" var="spe_geo_overview">
                        <div class="rnaseqTitle">
                            <s:property value="#spe_geo_overview.spe_geo_overview_title"/>
                        </div>
                        <div class="rnseqcont">
                            <s:property value="#spe_geo_overview.spe_geo_overview_cont"/>
                    </div>
                    </s:iterator>
                </div>
            </div>

            <div class="form_function">

                <div class="form_function_species">

                    <div class="topname">
                        Platforms
                    </div>
                    <div class="rnaseqTitle">
                        Platforms
                    </div>
                    <div class="rnseqcont">

                        <s:iterator value="allplatlist" var="spe_geo_plat">

                            <a href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<s:property value="#spe_geo_plat.spe_geo_plat_number"/>" target="_blank">
                                <s:property value="#spe_geo_plat.spe_geo_plat_number"/>
                            </a>

                            <span>
                                <s:property value="#spe_geo_plat.spe_geo_plat_intro"/>
                            </span>
                            <br>

                        </s:iterator>


                    </div>
                </div>
            </div>

            <div class="form_function">

                <div class="form_function_species">

                    <div class="topname">
                        Samples
                    </div>
                    <div class="rnaseqTitle">
                        Samples
                    </div>
                    <div class="rnseqcont">

                        <s:iterator value="allsamplelist" var="spe_geo_sample">

                            <a href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<s:property value="#spe_geo_sample.spe_geo_samp_num"/>" target="_blank">
                                <s:property value="#spe_geo_sample.spe_geo_samp_num"/>
                            </a>

                            <span>
                                <s:property value="#spe_geo_sample.spe_geo_samp_intro"/>
                            </span>
                            <br>

                        </s:iterator>


                    </div>
                </div>
            </div>

            <div class="form_function">

                <div class="form_function_species">

                    <div class="topname">
                        Download
                    </div>
                    <div class="rnaseqTitle">
                        Matrix
                    </div>
                    <div class="rnseqcont">


                       <s:iterator value="allmaterlist" var="spe_geo_download">

                           <a class="rnaseqfile" href="download_down.action?fileName=<s:property value="#spe_geo_download.spe_geo_download_name"/>">
                               <s:property value="#spe_geo_download.spe_geo_download_name"/>
                           </a>
                           <br>

                       </s:iterator>


                    </div>
                </div>
            </div>

        </form>
    </div>
</div>
<!--footer-->
<%@include file="footer.jsp"%>
</body>
</html>
