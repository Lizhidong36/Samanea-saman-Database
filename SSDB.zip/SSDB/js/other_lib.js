function $(num) {
    alert('自定义哭，'+num);
}