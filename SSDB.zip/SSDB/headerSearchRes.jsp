<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/11/6
  Time: 下午4:47
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags"  prefix="s"%>
<html>
<head>
    <title>Title</title>
</head>
<body>


<form id="blast_form" action="<s:property value="#session.shLink"/>" method="post"  enctype="multipart/form-data">


</form>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<script type="text/javascript">

    $(function () {

        $("#blast_form").submit();

    });

</script>
</body>
</html>
