<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/11
  Time: 9:50
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Recent Updates</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/news.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/news_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/news_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/news_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/news.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/news_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>

<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <!--body_center-->
    <div id="body_center">
        <div class="body_center_center">
            <div class="body_center_center_top">
                <p>Recent Updates</p>
            </div>
            <div class="body_center_center_bottom">

                <s:iterator value="allNews" var="newsdetail">
                    <div class="body_center_center_bottom_new">
                        <div class="body_center_center_bottom_new_left">
                            <ul>
                                <li>
                                   <%-- <a href="${pageContext.request.contextPath}/news_oneNews.action?new_id=<s:property value="#newsdetail.new_id"/>">--%>
                                        <a href="${pageContext.request.contextPath}/news_oneNews.action?new_id=<s:property value="#newsdetail.new_id"/>" target="_blank"><s:property value="#newsdetail.new_desc"/></a>
                                   <%-- </a>--%>

                                </li>
                            </ul>

                        </div>
                        <div class="body_center_center_bottom_new_right">
                            <p><s:property value="#newsdetail.new_data"/></p>
                        </div>
                    </div>
                </s:iterator>


            </div>
        </div>
    </div>
</div>

<%@include file="footer.jsp"%>
</body>
</html>
