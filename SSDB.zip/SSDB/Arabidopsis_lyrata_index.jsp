<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/24
  Time: 下午6:55
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Species Detail</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/body_kuangjia.css">
    <link rel="stylesheet" href="css/Arabidopsis_lyrata_index.css">--%>
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/body_kuangjia_24.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_index.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/body_kuangjia_18.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_index.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/body_kuangjia_15.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_index.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/body_kuangjia.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_index.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/body_kuangjia_6.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_index.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
    <div class="body_center">

        <form action="#">
            <div class="form_top">
                <%--<p>Arabidopsis &nbsp;lyrata</p>--%>
<%--                <p><i><s:property value="#session.spe_ind_title1"/></i><s:property value="#session.spe_ind_gentitle6"/><s:property value="#session.spe_ind_title2"/><s:property value="#session.spe_ind_title3"/> &nbsp;<s:property value="#session.spe_ind_title4"/> &nbsp;<s:property value="#session.spe_ind_title5"/></p>--%>
                <p><i><s:property value="#session.spe_ind_title1"/></i><s:property value="#session.spe_ind_gentitle6"/></p>

            </div>

            <div class="spe_introductions">
                <div class="form_function_species">
                    <div class="intro_spe">
                        <div class="i_s_left">
                            <ul>

                                 <li>
                                     <b>Introduction</b><br>
<%--                                     <i><s:property value="#session.spe_ind_title1"/></i>--%>
                                     <i><s:property value="#session.spe_ind_name"/></i>
                                     <s:property value="#session.spe_ind_intro"></s:property><br>
                                     <b><i><s:property value="#session.spe_ind_title2"/></i></b><s:property value="#session.spe_ind_title3"/><b><i><s:property value="#session.spe_ind_title4"/></i></b><s:property value="#session.spe_ind_title5"/><b><i><s:property value="#session.spe_ind_gentitle1"/></i></b><s:property value="#session.spe_ind_gentitle2"/><b><i><s:property value="#session.spe_ind_gentitle3"/></i></b><s:property value="#session.spe_ind_gentitle4"/>
<%--                                     <s:property value="#session.spe_ind_intro1"></s:property><br>--%>
<%--                                     <s:property value="#session.spe_ind_intro2"></s:property><br>--%>
<%--                                     <s:property value="#session.spe_ind_intro3"></s:property><br>--%>
<%--                                    <s:property value="#session.spe_ind_intro4"></s:property><br>--%>
<%--                                     <sup><s:property value="#session.spe_ind_linknum"></s:property></sup>--%>

                                </li>
                                <li>
                                    <b>Common name: </b><s:property value="#session.spe_ind_gentitle6"/>
                                </li>
                                <li>

<%--                                    <a href="<s:property value="#session.spe_ind_taxlink"/>" target="_blank">--%>
                                        <b>Taxonomy: </b><s:property value="#session.spe_ind_taxlink"/>


                                </li>
<%--                                <li>--%>
<%--                                    <a href="<s:property value="#session.spe_ind_downloadlink"/>" target="_blank">--%>
<%--                                        <b>Genome</b>--%>
<%--                                    </a>--%>

<%--                                </li>--%>
<%--                                <li>--%>
<%--                                    <a href="<s:property value="#session.spe_ind_jbrowselink"/>" target="_blank">--%>
<%--                                        <b>JBrowse</b>--%>
<%--                                    </a>--%>
<%--                                </li>--%>
                                <%--<li>
                                    <a>
                                        <b>T2T Genome: <s:property value="#session.spe_ind_lite_keyword"/></b>
                                    </a>
                                </li>--%>
                            </ul>

                        </div>
                        <div class="i_s_right">

                            <img src="${pageContext.request.contextPath}/<s:property value="#session.spe_ind_image"/>" alt="">
                        </div>
                    </div>
                </div>
            </div>

<%--            <div class="form_overview">--%>

<%--                <div class="form_overview_top">--%>
<%--                    <p>Feature Summary <sup><s:property value="#session.spe_ind_linknum"></s:property></sup></p>--%>
<%--                </div>--%>
<%--                <div class="form_overview_body">--%>
<%--                    <s:iterator value="feaList" var="species_overview_feature">--%>
<%--                        <div class="form_overview_body_intro">--%>

<%--                            <span><s:property value="#species_overview_feature.spe_ov_fea_desc"/></span>--%>
<%--                            <span><s:property value="#species_overview_feature.spe_ov_fea_cont"/></span>--%>
<%--                        </div>--%>

<%--                    </s:iterator>--%>

<%--                </div>--%>
<%--            </div>--%>
            <%--<div class="form_function">

                <s:iterator value="Contlist" var="species_index_con">

                    <div class="form_function_species">
                        <div class="f_f_s_top">
                            <a href="${pageContext.request.contextPath}/SpeciesOverview_getCont.action?spe_ind_title=<s:property value="#species_index_con.spe_ind_title"/>" target="_blank">

                                      <p><i><s:property value="#species_index_con.spe_ind_gentitle1"/></i><s:property value="#species_index_con.spe_ind_gentitle2"/><i><s:property value="#species_index_con.spe_ind_gentitle3"/></i><s:property value="#species_index_con.spe_ind_gentitle4"/><i><s:property value="#species_index_con.spe_ind_gentitle5"/></i><s:property value="#species_index_con.spe_ind_gentitle6"/></p>

                            </a>
                            <sup> <s:property value="#species_index_con.spe_ind_genomelinknum"></s:property></sup>


                        </div>


                        &lt;%&ndash;<div class="f_f_s_center">
                            <a href="http://tbir.njau.edu.cn/pLoTs/boxplot.jsp" target="_blank">Box-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/mifenqun.jsp" target="_blank">Box-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/corrplot.jsp" target="_blank">Corr-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/keggrich.jsp" target="_blank">Go/KeggRich-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/goterm.jsp" target="_blank">GoTerm-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/heatmap.jsp" target="_blank">Heatmap-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/manhataanplot.jsp" target="_blank">Manhattan-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/qqplot.jsp" target="_blank">QQ-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/seqlogo.jsp" target="_blank">Seqlogo-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/ternary.jsp" target="_blank">Ternary-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/Venn.jsp" target="_blank">Venn-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/volcano.jsp" target="_blank">Volcano-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/violin.jsp" target="_blank">Violin-plot</a>

                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=blast&functionType=blast" target="_blank">Blast+</a>
                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/homologs.jsp" target="_blank">Homologs</a>

                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/SSRFinder.jsp" target="_blank">SSR Finder</a>
                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=kegg&functionType=kegg" target="_blank">KEGG Enrichment</a>
                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=go&functionType=go" target="_blank">GO Enrichment</a>
                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/Synteny2.jsp" target="_blank">Synteny Finder</a>
                            &nbsp;|&nbsp;
                           &lt;%&ndash; <a href="${pageContext.request.contextPath}/kegg_pathway.jsp" target="_blank">KEGG Pathway</a>
                            &nbsp;|&nbsp;&ndash;%&gt;
                            <a href="${pageContext.request.contextPath}/Motif_Discovery.jsp" target="_blank">Motif Discovery</a>
                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/hmmerScan.jsp" target="_blank">TF Annotation</a>
                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=batchquery&functionType=blast" target="_blank">Batch Query</a>
&lt;%&ndash;                            &nbsp;|&nbsp;&ndash;%&gt;
&lt;%&ndash;                            <a href="${pageContext.request.contextPath}/blastResSearch.jsp" target="_blank">Tools Result Search</a>&ndash;%&gt;
&lt;%&ndash;                            &nbsp;|&nbsp;&ndash;%&gt;
&lt;%&ndash;                            <a href="${pageContext.request.contextPath}/LiteratureSearch.jsp" target="_blank">Literature Search</a>&ndash;%&gt;
                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/Submit.jsp" target="_blank">Submit</a>
                            &nbsp;|&nbsp;
                            <a href="<s:property value="#species_index_con.spe_ind_jbrowselink"/>" target="_blank">JBrowse</a>
                            &nbsp;|&nbsp;
                            <a href="<s:property value="#species_index_con.spe_ind_downloadlink"/>" target="_blank">Genome</a>
                            &nbsp;|&nbsp;
                            <a href="<s:property value="#species_index_con.spe_ind_lite_keyword"/>">Literature</a>
                            &nbsp;|&nbsp;
                            <a href="${pageContext.request.contextPath}/Link.jsp" target="_blank">Links</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/primer.jsp" target="_blank">Primer Design</a>
                        </div>&ndash;%&gt;
                    </div>
                </s:iterator>
            </div>--%>


           <%-- <div class="form_function">
                <s:iterator value="geoList" var="spe_geo">

                    <div class="form_function_species">
                        <div class="f_f_s_top">
                            <a href="${pageContext.request.contextPath}/Spernaseq_contlist.action?spe_geo_num=<s:property value="#spe_geo.spe_geo_num"/>" target="_blank">

                                <p><s:property value="#spe_geo.spe_geo_num"/></p>

                            </a>
                            <sup> <s:property value="#spe_geo.spe_geo_linknum"></s:property></sup>


                        </div>
                        <div class="f_f_s_center">
                            <a href="http://tbir.njau.edu.cn/pLoTs/boxplot.jsp" target="_blank">Box-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/Venn.jsp" target="_blank">Venn-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/qqplot.jsp" target="_blank">QQ-plot</a>
                            &nbsp;|&nbsp;
                            <a href="http://tbir.njau.edu.cn/pLoTs/manhataanplot.jsp" target="_blank">Manhattan-plot</a>
                        </div>
                    </div>
                </s:iterator>

            </div>--%>



            <div class="spe_introductions">
                <div class="form_function_species">
                    <div class="f_f_s_top">

                        <p class="ref_paper">
                            Genome
                        </p>
                        <ul>
                            <s:iterator value="paperList" var="species_index_con_paper">
                            <li>
                                <span><s:property value="#species_index_con_paper.spe_ind_refautor"/></span>
                                <span>
                                    <a href="<s:property value="#species_index_con_paper.spe_ind_reflink"/>" target="_blank">
                                        <s:property value="#species_index_con_paper.spe_ind_refname"/>
                                    </a>
                                </span>
                                <span><s:property value="#species_index_con_paper.spe_ind_refjoutnal"/></span>
                            </li>
                            </s:iterator>
                        </ul>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!--footer-->
<%@include file="footer.jsp"%>
</body>
</html>
