<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/11
  Time: 9:56
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/search.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/search_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/search_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/search_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/search.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/search_6.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <!--body_center-->
    <div id="body_center">
        <div class="body_center_top">
            <p class="b_c_t_p1">Search</p>
        </div>
        <div class="body_center_bottom">

        </div>
    </div>
</div>
<!--footer-->
<%@include file="footer.jsp"%>
</body>
</html>
