<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/8/15
  Time: 11:59
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html lang="en">
<head>

    <title>Title</title>
    <link rel="stylesheet" href="css/backHeader.css">
</head>
<body>
<!--header-->
<div id="header">
    <!--header_top-->
    <div class="header_top">
        <div class="header_top_center">
            <div class="header_top_center_left">
                Welcome &nbsp;to &nbsp;NOGR
            </div>

            <div class="header_top_center_right">
                <span>welcome:</span>
                <span class="back_name"><s:property value="ba_username" ></s:property></span>
                <a href="index1.jsp">Home</a>

            </div>
        </div>

        <!--header_body-->
        <div class="header_body">

            <div class="header_body_center">
                <div class="header_body_center_left">
                    <img src="image/DSC_3302.JPG">
                </div>

                <div class="header_body_center_center">
                    <p>NOGR &nbsp;Background &nbsp;Management &nbsp;System</p>
                    <%--<p>&nbsp;V1.0</p>--%>
                </div>
                <a href="${pageContext.request.contextPath}/LoginControl.jsp">
                    <ul class="access_con">
                        <li>
                            Access
                        </li>
                    </ul>
                </a>
                <a href="${pageContext.request.contextPath}/backIndex.jsp">
                    <ul class="main_inf">
                        <li>
                            Maintenance
                        </li>
                    </ul>
                </a>
                <a href="${pageContext.request.contextPath}/back_index.jsp">
                    <ul class="more">
                        <li>
                            More
                        </li>
                    </ul>
                </a>


            </div>

        </div>
    </div>
</div>

</body>
</html>
