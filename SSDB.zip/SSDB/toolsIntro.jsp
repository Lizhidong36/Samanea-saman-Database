<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/28
  Time: 下午1:20
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/toolsIntro.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/toolsIntro_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/toolsIntro_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/toolsIntro_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/toolsIntro.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/toolsIntro_6.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
    <div class="body_center">
        <form action="#">

            <div class="form_top">
                    <p><s:property value="#session.f_type"/></p>
            </div>

            <s:iterator value="allfunction" var="functionintro">

                <div class="gene_family">
                    <div class="gene_family_top">
                        <p>
                            <a href="<s:property value="#functionintro.f_link"/>" target="_blank">
                            <s:property value="#functionintro.f_name"/>:
                            <a/>
                        </p>
                    </div>
                    <div class="gene_family_cont">
                        <p>
                            <s:property value="#functionintro.f_introduction"/>
                        </p>
                    </div>
                </div>

            </s:iterator>

        </form>
    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
