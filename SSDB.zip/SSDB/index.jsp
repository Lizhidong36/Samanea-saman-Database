<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<%--<%@include file="header.jsp"%>--%>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>hortDB</title>
  <%--<link rel="stylesheet" href="css/index.css">
  <link rel="stylesheet" href="css/body_species.css">
    <link rel="stylesheet" href="css/body_speciesHeight.css">
    <link rel="stylesheet" href="css/footer.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/index_24.css">');
            document.write('<link rel="stylesheet" href="css/body_species_24.css">');
            document.write('<link rel="stylesheet" href="css/body_speciesHeight_24.css">');
            document.write('<link rel="stylesheet" href="css/footer_24.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/index_18.css">');
            document.write('<link rel="stylesheet" href="css/body_species_18.css">');
            document.write('<link rel="stylesheet" href="css/body_speciesHeight_18.css">');
            document.write('<link rel="stylesheet" href="css/footer_18.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/index_15.css">');
            document.write('<link rel="stylesheet" href="css/body_species_15.css">');
            document.write('<link rel="stylesheet" href="css/body_speciesHeight_15.css">');
            document.write('<link rel="stylesheet" href="css/footer_15.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/index.css">');
            document.write('<link rel="stylesheet" href="css/body_species.css">');
            document.write('<link rel="stylesheet" href="css/body_speciesHeight.css">');
            document.write('<link rel="stylesheet" href="css/footer.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/index_6.css">');
            document.write('<link rel="stylesheet" href="css/body_species_6.css">');
            document.write('<link rel="stylesheet" href="css/body_speciesHeight_6.css">');
            document.write('<link rel="stylesheet" href="css/footer_6.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<%@include file="header.jsp"%>
<body>
<!--body-->
<div id="body">
  <!--body_center-->
  <div id="body_center">
    <div class="body_center_top">
      <p class="b_c_t_p1">Introduction</p>
    </div>
    <div class="body_center_bottom">

<%--        <b class="int_b1">N</b>on-heading <b class="int_b2">C</b>hinese  <b class="int_b3">C</b>abbage and <b class="int_b4">W</b>--%>
        <p class="body_center_bottom_p4">The <i>Samanea saman</i> Database (SSDB) is a comprehensive platform dedicated to genomic data of the Rain Tree (<i>Samanea saman</i>). This database integrates high-quality genome sequences, annotation information, and gene expression data, supporting multi-omics research and comparative genomic analysis. Users can utilize interactive tools to query gene functions, sequence information, and download multi-omics data for applications in breeding, ecological adaptation, and medicinal value studies. SSDB is committed to advancing the exploration and utilization of genetic resources in this important tropical tree species, providing open-access data support for researchers, breeders, and conservation biologists.</p>
    </div>
  </div>



  <!--body_bottom-->
  <div id="body_bottom">


    <div class="body_bottom_footer">
        <div class="f_left">
            <div class="f_right_top">
                <p class="f_p">Cite</p>
            </div>

            <div class="body_bottom_bottom_right_bottom">
                <ul>
                   <%-- <li>
                        <p>More and more people are always welcome to use the NHCCDB data in their own work.
                            If you use NHCCDB data or information in your work, please cite the following publications :</p>
                    </li>--%>
<%--                    <li>--%>
<%--                        <a href="#">--%>
<%--                            The Horticultural Plant Database project has been published in XXXXXXXXXXXXXXXXXXXX. To cite us, please refer to the following publication:--%>
<%--                        </a>--%>
<%--                    </li>--%>
                       <li>
                           <a href="#" target="_blank">
                               Kejing Yang, Shenghao Wang, Guilian Guo, Haixiang Yu, Zhidong Li, Fei Chen and Yingchun Xu. SSDB V1.0: a genomic database of Samanea  saman. 
                           </a>
                       </li>
                </ul>
            </div>

        </div>
        <div class="f_center">
            <div class="f_right_top">
                <p class="f_p">News</p>
            </div>
            <div class="body_bottom_bottom_right_bottom">
                <ul>
                    <li>
                        <p>Plant Biology Europe.  June25-28, 2025, Budapest, Hungary. https://pbe2025-budapest.org/</p>
                    </li>
                    <li>

                        <p>2025 International Conference on Plant Cell Wall Biology.  July 6-10,2025,University of British Columbia (UBC),Vancouver,Canada. </p>
                    </li>
                    <li>
                        <p>20th International Workshop on Plant Membrane Biology. August 17-22, 2025, Elsinore/Copenhagen,Denmark.</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="f_right">
            <div class="f_right_top">
                <p class="f_p">Visitors</p>
            </div>
            <div class="f_right_bottom">
<%--                <script type="text/javascript" src="//rf.revolvermaps.com/0/0/1.js?i=5enfzlsnili&amp;s=220&amp;m=2&amp;v=true&amp;r=false&amp;b=000000&amp;n=false&amp;c=ff8a00" async="async"></script>--%>
    <script type="text/javascript" src="//rf.revolvermaps.com/0/0/1.js?i=5cdtwije5v3&amp;s=220&amp;m=0&amp;v=true&amp;r=false&amp;b=000000&amp;n=false&amp;c=ff0000" async="async"></script>
             <%--                <script type="text/javascript" src="//rf.revolvermaps.com/0/0/1.js?i=570tsk0fgti&amp;s=250&amp;m=7&amp;v=true&amp;r=false&amp;b=000000&amp;n=false&amp;c=ff0000" async="async"></script>--%>
            </div>
        </div>

    </div>
  </div>
</div>
<!--footer-->

<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<script type="text/javascript">

  $(function () {

    $.post('${pageContext.request.contextPath}/news_fiveNews.action',function (data) {

      console.log(data);
      $(data).each(function (i,obj) {
        console.log(obj.new_desc);
        console.log(obj.new_detail);
        console.log(obj.new_data);
        console.log(obj.new_id);
        console.log(obj.new_links);

        /*$(".news_ul").append("<option value="+obj.id+">"+obj.new_desc+"</option>");*/
        <%--$(".news_ul").append("<li><a href='${pageContext.request.contextPath}/news_oneNews.action?new_id="+obj.new_id+"'>"+obj.new_desc+"</a><p>"+" "+obj.new_data+"</p></li>");--%>
        $(".news_ul").append("<li><a href='"+obj.new_links+"'>"+obj.new_desc+"</a><p>"+" "+obj.new_data+"</p></li>");
      });


    },"json");

    $.post('${pageContext.request.contextPath}/recentUpdate_fourUpdate.action',function (data) {
      console.log(data);

      $(data).each(function (i,obj) {
        console.log(obj.re_desc);
        console.log(obj.re_date);
        console.log(obj.re_link);
        console.log(obj.re_id);

        $(".recentUpdate_ul").append("<li><a href='"+obj.re_link+"'"+ 'target="_blank"' + ">"+obj.re_desc+"</a><p>"+" "+obj.re_date+"</p></li>");


      });
    },"json");



      /*$(document).ready(function () {

          if(location.href.indexOf("#reloaded")==-1){
              location.href=location.href+"#reloaded";
              location.reload();
          }
      });*/



  });
</script>
</body>
</html>
