<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/10
  Time: 21:59
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transcriptome</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/blast.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/blast_24.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/blast_18.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/blast_15.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/blast.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/blast_6.css">');
            document.write('<link rel="stylesheet" href="css/seqenceFetch_6.css">');
        }
    </script>


</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">

    <div class="body_center">
        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/literuture_gfflist.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p>Transcriptome</p>
                <%--<select class="par_type" name="par_type">
                    <option>blast</option>
                </select>--%>
<%--                <input name="seq_species_type" style="display: none" value="<s:property value="#session.seq_species_types"/>">--%>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Species:</p>

                        <select id="sub_cate_se1" class="blast_db" name="seq_species_type">

                            <option value="Brassica rapa">Brassica rapa</option>
                            <option value="Brassica napus">Brassica napus</option>
                            <option value="Camellia sinensis">Camellia sinensis</option>
                            <option value="Capsicum annuum">Capsicum annuum</option>
                            <option value="Carica papaya">Carica papaya</option>
                            <option value="Chrysanthemum nankingense">Chrysanthemum nankingense</option>
                            <option value="Citrullus lanatus">Citrullus lanatus</option>
                            <option value="Citrus sinensis">Citrus sinensis</option>
                            <option value="Coffea canephora">Coffea canephora</option>
                            <option value="Cucumis sativus">Cucumis sativus</option>
                            <option value="Diospyros kaki Thumb">Diospyros kaki Thumb</option>
                            <option value="Fragaria vesca">Fragaria vesca</option>
                            <option value="Ipomoea batatas">Ipomoea batatas</option>
                            <option value="Litchi chinensis Sonn">Litchi chinensis Sonn</option>
                            <option value="Malus domestica">Malus domestica</option>
                            <option value="Mangifera indica">Mangifera indica</option>
                            <option value="Musa acuminata">Musa acuminata</option>
                            <option value="Panax ginseng">Panax ginseng</option>
                            <option value="Raphanus sativus">Raphanus sativus</option>
                            <option value="Rosa chinensis">Rosa chinensis</option>
                            <option value="Solanum lycopersicum">Solanum lycopersicum</option>
                            <option value="Solanum melongena">Solanum melongena</option>
                            <option value="Solanum tuberosum">Solanum tuberosum</option>
                            <option value="Vitis vinifera">Vitis vinifera</option>
                            <option value="Pyrus pyrifolia">Pyrus pyrifolia</option>
                            <option value="Pyrus betulifolia">Pyrus betulifolia</option>
                            <option value="Pyrus communis">Pyrus communis</option>


                        </select>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Tissues:</p>
                    <select id="sub_cate_se2" class="blast_db " name="blast_db">
                            <option value="All">All</option>
                        <option value="flower">Flower</option>
                        <option value="fruit">Fruit</option>
                            <option value="leaves">Leaves</option>
                        <option value="root">Root</option>
                            <option value="seed">Seed</option>
                    </select>
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Search:</p>
                    <input type="button" value="Example" class="blast_example">
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>

<!--footer-->
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        $(".blast_example").click(function () {


            $("#sub_cate_se2").val("leaves");


        });
        $(".blast_sb").click(function () {


            $("#blast_form").submit();


        });

    });
</script>
</body>
</html>