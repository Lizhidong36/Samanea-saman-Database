<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/10
  Time: 21:59
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Homologs</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/batchquery.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/batchquery_24.css">');
            document.write('<link rel="stylesheet" href="css/homologs_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/batchquery_18.css">');
            document.write('<link rel="stylesheet" href="css/homologs_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/batchquery_15.css">');
            document.write('<link rel="stylesheet" href="css/homologs_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/batchquery.css">');
            document.write('<link rel="stylesheet" href="css/homologs.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/batchquery_6.css">');
            document.write('<link rel="stylesheet" href="css/homologs_6.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">
    <div id="userguidelink">
        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=Batch_Query_1.zip" title="userguide and test data">
            <p class="userguidelink_p">Userguide and demo file</p>
        </a>
    </div>
<%--    <div class="body_center">--%>
<%--        <form id="blast_form" action="${pageContext.request.contextPath}/literuture_homologslist.action" method="post"  enctype="multipart/form-data">--%>
<%--            <div class="form_top">--%>
<%--                <p>Homologs</p>--%>
<%--            </div>--%>

<%--            <div class="form_type">--%>
<%--                <div class="f_t_lab">--%>
<%--                <p>Select Type:</p>--%>
<%--                <select class="blast_type" name="organism_type" >--%>

<%--&lt;%&ndash;                    <s:iterator value="allBlastFile" var="BlastFile">&ndash;%&gt;--%>
<%--&lt;%&ndash;                        <option value="<s:property value="#BlastFile.blast_speciesFileName"></s:property>"><s:property value="#BlastFile.balst_speciesName"></s:property> </option>&ndash;%&gt;--%>
<%--&lt;%&ndash;                    </s:iterator>&ndash;%&gt;--%>
<%--                        <option value="orth">Orthologs</option>--%>
<%--                        <option value="pa">Paralogs</option>--%>
<%--                    &lt;%&ndash; <option value="Brapa_genome_v3.0_pep.fasta">B. nigra (pep)</option>&ndash;%&gt;--%>
<%--                </select>--%>
<%--                </div>--%>
<%--            </div>--%>


<%--            <div class="form_seq">--%>
<%--                <div class="f_t_lab">--%>
<%--                    <p>Group or Gene:</p>--%>
<%--                    <div id="error" style="color:red"><s:actionerror></s:actionerror></div>--%>
<%--                    <textarea class="blast_seq" name="content" placeholder="Group number or gene id (Brassica campestris ssp. chinensis NHCC001, Nasturtium officinale, Brassica rapa subsp. pekinensis, Brassica juncea, Brassica napus, Brassica oleracea or Arabidopsis thaliana):--%>
<%--For example:--%>
<%--OG0000000 or BraC01g000090.1 or Noff13351-RA"></textarea>--%>
<%--&lt;%&ndash;                    <input type="file" name="upload" id="fileupload">&ndash;%&gt;--%>
<%--                </div>--%>
<%--            </div>--%>

<%--            <div class="form_sub">--%>
<%--                <div class="f_t_lab">--%>
<%--                    <p>Search:</p>--%>
<%--                    <input type="button" value="Submit" class="blast_sb">--%>
<%--                </div>--%>
<%--            </div>--%>

<%--            <div class="form_sub2">--%>
<%--                <div class="f_t_lab">--%>
<%--                    <p>Search All:</p>--%>
<%--                    <input type="button" value="Orthologs_All" class="blast_sb_Orthologs">--%>
<%--                    <input type="button" value="Paralogs_All" class="blast_sb_Paralogs">--%>
<%--                </div>--%>
<%--            </div>--%>
<%--        </form>--%>


<%--    </div>--%>
</div>
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    function turn(str) {

        while (str.indexOf("\n") != -1) {
            str = str.substring(0, str.indexOf("\n")) + "<br>"
                + str.substring(str.indexOf("\n") + 1);
        }
        while (str.indexOf(" ") != -1) {
            str = str.substring(0, str.indexOf(" ")) + "\C6MC6M"
                + str.substring(str.indexOf(" ") + 1);
        }
        while (str.indexOf("|") != -1) {
            str = str.substring(0, str.indexOf("|")) + "\C9MC9M"
                + str.substring(str.indexOf("|") + 1);
        }
        while (str.indexOf("_") != -1) {
            str = str.substring(0, str.indexOf("_")) + "\C3MC3M"
                + str.substring(str.indexOf("_") + 1);
        }
        while (str.indexOf("#") != -1) {
            str = str.substring(0, str.indexOf("#")) + "\C5MC5M"
                + str.substring(str.indexOf("#") + 1);
        }
        while (str.indexOf("=") != -1) {
            str = str.substring(0, str.indexOf("=")) + "\C7MC7M"
                + str.substring(str.indexOf("=") + 1);
        }
        while (str.indexOf(".") != -1) {
            str = str.substring(0, str.indexOf(".")) + "\C8MC8M"
                + str.substring(str.indexOf(".") + 1);
        }
        while (str.indexOf("/") != -1) {
            str = str.substring(0, str.indexOf("/")) + "\C4MC4M"
                + str.substring(str.indexOf("/") + 1);
        }
        while (str.indexOf("-") != -1) {
            str = str.substring(0, str.indexOf("-")) + "\C2MC2M"
                + str.substring(str.indexOf("-") + 1);
        }
        while (str.indexOf("+") != -1) {
            str = str.substring(0, str.indexOf("+")) + "\C1MC1M"
                + str.substring(str.indexOf("+") + 1);
        }
        while (str.indexOf(":") != -1) {
            str = str.substring(0, str.indexOf(":")) + "\M6666MM6666M"
                + str.substring(str.indexOf(":") + 1);
        }
        while (str.indexOf(";") != -1) {
            str = str.substring(0, str.indexOf(";")) + "\M1111MM1111M"
                + str.substring(str.indexOf(";") + 1);
        }
        while (str.indexOf(" ") != -1) {
            str = str.substring(0, str.indexOf(" ")) + "\M2222MM2222M"
                + str.substring(str.indexOf(" ") + 1);
        }
        while (str.indexOf("\t") != -1) {
            str = str.substring(0, str.indexOf("\t")) + "\M3333MM3333M"
                + str.substring(str.indexOf("\t") + 1);
        }
        while (str.indexOf(",") != -1) {
            str = str.substring(0, str.indexOf(",")) + "\M4444MM4444M"
                + str.substring(str.indexOf(",") + 1);
        }
        while (str.indexOf("    ") != -1) {
            str = str.substring(0, str.indexOf("    ")) + "\Cc1MCc1M"
                + str.substring(str.indexOf("   ") + 1);
        }
        return str;
    };

    $(".blast_sb").click(function () {
       var content =  $(".blast_seq").val();
       var organism_type =  $(".blast_type").val();
       // var fileupload =  $("#fileupload").val();


       if(content == ""){
           alert("please input Group number or gene id (Brassica campestris ssp. chinensis NHCC001, Nasturtium officinale, Brassica rapa subsp. pekinensis, Brassica juncea, Brassica oleracea or Arabidopsis thaliana)!");
       }

        // if(content != "" && fileupload != ""){
        //     alert("please input or upload sequence file!");
        // }

        if(content != ""){
            cont1 = turn(content);

            var new_blast_seq = $(".blast_seq").val(cont1);

            $("#blast_form").submit();
        }

        // if(content == "" && fileupload != ""){
        //     $("#blast_form").submit();
        // }

    });

    $(".blast_sb_Orthologs").click(function () {

        // var keyword =  $("#input_search").val();
        // var organism_type =  $(".blast_type").val();

        //alert(keyword);
        <%--$(window).attr('location','${pageContext.request.contextPath}/literuture_homologslist.action?organism_type=orth&content=');--%>
    });

    $(".blast_sb_Paralogs").click(function () {

        // var keyword =  $("#input_search").val();
        // var organism_type =  $(".blast_type").val();

        //alert(keyword);
        <%--$(window).attr('location','${pageContext.request.contextPath}/literuture_homologslist.action?organism_type=pa&content=');--%>
    });

</script>
</body>
</html>