<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/9/8
  Time: 下午8:44
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>TF</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/tfListdetail.css">


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/tfListdetail_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>

<%@include file="header.jsp"%>

<div id="body">
    <div class="body_center">

        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/TfAction_list.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p><s:property value="#session.alltf_family"/></p>
            </div>

            <div class="form_database" id="ft_title">

                <div class="tf_id">
                    Gene &nbsp;ID
                </div>
                <div class="tf_cds">
                    CDS
                </div>
                <div class="tf_pep">
                    PEP
                </div>
                <div class="pfam_num">
                    Pfam &nbsp;ID
                </div>
                <div class="tf_domain">
                    Domain
                </div>
                <div class="tf_evalue">
                    Pfam &nbsp;Evalue
                </div>
                <div class="tf_name">
                    Family
                </div>
            </div>


            <s:iterator value="tflist" var="alltf">
                <div class="form_database">

                    <div class="tf_id">

                            <s:property value="#alltf.alltf_geneid" />

                    </div>
                    <div class="tf_cds">
                        <a href="${pageContext.request.contextPath}/BatchQuery_list.action?organism_type=<s:property value="#session.tfile_cds"/>&content=<s:property value="#alltf.alltf_geneid" />" target="_blank">
                        CDS
                        </a>
                    </div>
                    <div class="tf_pep">
                        <a href="${pageContext.request.contextPath}/BatchQuery_list.action?organism_type=<s:property value="#session.tfile_pep"/>&content=<s:property value="#alltf.alltf_geneid" />" target="_blank">
                        PEP
                        </a>
                    </div>
                    <div class="pfam_num">
                        <a href="http://pfam.xfam.org/family/<s:property value="#alltf.alltf_pfamid" />" target="_blank">
                            <s:property value="#alltf.alltf_pfamid" />
                        </a>

                    </div>
                    <div class="tf_domain">
                        <s:property value="#alltf.alltf_domain" />
                    </div>
                    <div class="tf_evalue">
                        <s:property value="#alltf.alltf_evalue" />
                    </div>
                    <div class="tf_name">
                        <s:property value="#alltf.alltf_family" />
                    </div>
                    <span class="tf_species">
                        <s:property value="#alltf.alltf_species" />
                    </span>
                </div>
            </s:iterator>



        </form>

    </div>
</div>
<%@include file="footer.jsp"%>

</body>
</html>
