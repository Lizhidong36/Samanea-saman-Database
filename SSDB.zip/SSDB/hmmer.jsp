<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/11/6
  Time: 下午7:28
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/hmmer.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/hmmer_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/hmmer_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/hmmer_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/hmmer.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/hmmer_6.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>

<div id="body">
    <div class="body_center">

        <form id="blast_form" action="${pageContext.request.contextPath}/HmmerAction_hmmer.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p>Hmmsearch</p>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select database:</p>
                    <select class="hmmer_db" name="hmmer_db">

                        <s:iterator value="allBlastFile" var="BlastFile">
                            <option value="<s:property value="#BlastFile.blast_speciesFileName"></s:property>"><s:property value="#BlastFile.balst_speciesName"></s:property> </option>
                        </s:iterator>


                        <%--<option value="Brapa_genome_v3.0_pep.fasta">Nasturtium Officinale (cds v3.0)</option>--%>

                    </select>
                </div>
            </div>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Paste in your alignment/hmm:</p>
                    <textarea name="hmmer_seq" class="hmmer_seq" placeholder="Paste in your alignment/hmm
For example:
# STOCKHOLM 1.0
F6GWZ2_VITVI/6-144               SSGRLPTWKERENNKKRERRRRAIAAKIYAGLRAQGNYKLPKHCDNNEVLKALCSEAGWTVEEDGTTYR.........................KGCKPPP....TEIAGASAN.ISA.CSSMQP.SPQSSSFPSPVPSYHASPSSSSFP.....SPTRFDG..........NPS...SYLLPFLRNLA
M4D8T1_BRARP/16-151              ATGRMPTWKERENNKKRERRRRAIAAKIFTGLRSQGNYKLPKHCDNNEVLKALCVEAGWIVHEDGTTYR.........................KGSRPTE........TTPPR.VSA.CSSIQL.SHHSSAFQSPVPSYQASPASSSYP.....SPTRFD............PNHSSTYLIPYLQNLA
//"></textarea>
                    <input type="file" name="upload" id="fileupload">
                </div>
            </div>


            <div class="form_par">
                <div class="f_t_lab">
                    <p>Optional hmmer search parameters:</p>
                    <label>Sequences E-value:</label>
                    <input class="blast_eval" name="hmmer_eval" value="0.01" max="10.0" min="0.0">
                    <br>
                    <label>Domains E-value:</label>
                    <input class="blast_eval" name="hmmerDomian_eval" value="0.03" max="10.0" min="0.0">
                    <br>
                    <label>Output File Format:</label>
                    <select class="blast_eval" name="hmmerOutfmt">
                        <option value="domtblout">domtblout</option>
                        <option value="pfamtblout">pfamtblout</option>
                        <option value="tblout">tblout</option>
                    </select>
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit hmmer search:</p>
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>
<%@include file="footer.jsp"%>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        function turn(str) {

            while (str.indexOf("\n") != -1) {
                str = str.substring(0, str.indexOf("\n")) + "<br>"
                    + str.substring(str.indexOf("\n") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\C6MC6M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("|") != -1) {
                str = str.substring(0, str.indexOf("|")) + "\C9MC9M"
                    + str.substring(str.indexOf("|") + 1);
            }
            while (str.indexOf("_") != -1) {
                str = str.substring(0, str.indexOf("_")) + "\C3MC3M"
                    + str.substring(str.indexOf("_") + 1);
            }
            while (str.indexOf("#") != -1) {
                str = str.substring(0, str.indexOf("#")) + "\C5MC5M"
                    + str.substring(str.indexOf("#") + 1);
            }
            while (str.indexOf("=") != -1) {
                str = str.substring(0, str.indexOf("=")) + "\C7MC7M"
                    + str.substring(str.indexOf("=") + 1);
            }
            while (str.indexOf(".") != -1) {
                str = str.substring(0, str.indexOf(".")) + "\C8MC8M"
                    + str.substring(str.indexOf(".") + 1);
            }
            while (str.indexOf("/") != -1) {
                str = str.substring(0, str.indexOf("/")) + "\C4MC4M"
                    + str.substring(str.indexOf("/") + 1);
            }
            while (str.indexOf("-") != -1) {
                str = str.substring(0, str.indexOf("-")) + "\C2MC2M"
                    + str.substring(str.indexOf("-") + 1);
            }
            while (str.indexOf("+") != -1) {
                str = str.substring(0, str.indexOf("+")) + "\C1MC1M"
                    + str.substring(str.indexOf("+") + 1);
            }
            while (str.indexOf(":") != -1) {
                str = str.substring(0, str.indexOf(":")) + "\M6666MM6666M"
                    + str.substring(str.indexOf(":") + 1);
            }
            while (str.indexOf(";") != -1) {
                str = str.substring(0, str.indexOf(";")) + "\M1111MM1111M"
                    + str.substring(str.indexOf(";") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\M2222MM2222M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("\t") != -1) {
                str = str.substring(0, str.indexOf("\t")) + "\M3333MM3333M"
                    + str.substring(str.indexOf("\t") + 1);
            }
            while (str.indexOf(",") != -1) {
                str = str.substring(0, str.indexOf(",")) + "\M4444MM4444M"
                    + str.substring(str.indexOf(",") + 1);
            }
            while (str.indexOf("    ") != -1) {
                str = str.substring(0, str.indexOf("    ")) + "\Cc1MCc1M"
                    + str.substring(str.indexOf("   ") + 1);
            }
            return str;
        };


        $(".blast_sb").click(function () {

            var hmmer_db = $(".hmmer_db").select().val();
            var hmmer_seq = $(".hmmer_seq").val();
            var fileupload = $("#fileupload").val();


            //alert(blast_type);
         /*   alert(hmmer_db);
            alert(hmmer_seq);
*/

            if(hmmer_seq == "" && fileupload == ""){
                alert("please upload file!");
            }
            if(hmmer_seq != "" && fileupload != ""){
                alert("please input or upload a file!");
            }
            if(hmmer_seq != "" && fileupload ==""){
                cont1 = turn(hmmer_seq);

                var new_blast_seq = $(".hmmer_seq").val(cont1);

                $("#blast_form").submit();
            }
            if(hmmer_seq == "" && fileupload != ""){

                $("#blast_form").submit();
            }

            /* win*/
            /* $(window).attr('location','<%--${pageContext.request.contextPath}--%>/BlastAction_blast.action?blast_type='+blast_type+'&blast_db='+blast_db+'&blast_seq='+cont1+'&blast_eval='+blast_eval);*/

            /*lin*/
            /*$(window).attr('location','<%--${pageContext.request.contextPath}--%>/HmmerAction_hmmer.action?hmmer_db='+hmmer_db+'&hmmer_seq='+cont1+'&hmmer_eval='+hmmer_eval);
*/
        });



    });
</script>
</body>
</html>
