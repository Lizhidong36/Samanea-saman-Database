<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/10/10
  Time: 13:01
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/back_index.css">
</head>
<body>
<%@include file="backHeader.jsp"%>
<div id="body">
    <div class="body_center">
        <div class="body_center_center">
            <div class="b_c_c_top">
                <p>Contents</p>
            </div>
            <div class="b_c_c_home">
                <div class="b_c_c_home_top">
                    <p>
                        Home
                    </p>
                </div>
                <div class="b_c_c_home_body">
                    <p class="b_c_c_home_body_News">
                        <a href="${pageContext.request.contextPath}/news_Backlist.action" target="_blank">
                            Recent Update
                        </a>

                    </p>

                    <p class="b_c_c_home_body_recentupdate">

                        <a href="${pageContext.request.contextPath}/recentUpdate_backAllUpdate.action" target="_blank">
                            News
                        </a>

                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
