<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/11/11
  Time: 下午6:12
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Tools Result Search</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/blastResSearch.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/blastResSearch_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/blastResSearch_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/blastResSearch_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/blastResSearch.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/blastResSearch_6.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">
    <div class="body_center">
        <form action="#">

            <div class="form_top">
                <p>Tools &nbsp;Result &nbsp;Search</p>
            </div>

            <div class="form_type">
                <p>This function used to find tools analysis result file. To search the function of tools analysis results in the text boxes below. You can select your results type and input your result id in the dropdown box. If you have any questions, please contact us.
                </p>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Tools Result Type:</p>
                    <select class="blast_db" name="blast_db">
                        <option value="blast">BLAST+ Result</option>
                        <option value="hmmScan">TF Annotion Result</option>
                        <option value="ssr">SSR Finder Result</option>
                        <option value="motifDis">Motif Discovery Result</option>
                        <option value="goenrich">GO Enrichment Result</option>
                        <option value="KEGGRICH">KEGG Enrichment Result</option>
                        <option value="syn">Synteny Finder Result</option>


                    </select>
                </div>
            </div>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Result Id:</p>
                    <input id="blastResId" type="text" placeholder="Enter Result Id">
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit Search:</p>
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>


        </form>
    </div>
</div>

<!--footer-->
<%@include file="footer.jsp"%>


<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {


        $(".blast_sb").click(function () {
            var blastuuidFilenameTitle = $("#blastResId").val();
            var blast_db = $(".blast_db").val();



            $(window).attr('location','${pageContext.request.contextPath}/GetResult_blastRes.action?blastuuidFilenameTitle=' + blastuuidFilenameTitle + '&blast_db=' + blast_db);


        });


    });
</script>
</body>
</html>
