<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/8/31
  Time: 12:25
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%--<%@include file="header.jsp"%>--%>
<html>
<head>
    <title>Literature Search</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/LiteratureSearch.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/LiteratureSearch_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/LiteratureSearch_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/LiteratureSearch_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/LiteratureSearch.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/LiteratureSearch_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<%@include file="header.jsp"%>
<body>

<div id="body">
    <div class="body_center">
        <div class="b_c_center">
            <div class="search_intro">Literature &nbsp;Search</div>
            <div class="search_note">
                <p>To search for publications enter keywords in the text boxes below.
                    You can limit your search by selecting the field in the dropdown box.
                    If you have any questions or suggestions, please contact us. Thank you
                    for using NHCCDB.
                </p>

            </div>

            <div class="sub_desc">
                <div class="first_limit">
                    <select class="first_select">
                        <option value="3">Title</option>
                        <%--<option value="ar_title">Title</option>--%>
                        <option value="2">Author</option>
                        <option value="1">Journal</option>
                        <option value="1">Year</option>
                        <option value="1">doi</option>
                    </select>
                    <select class="first_contain">
                        <option value="4">contains</option>
                        <option value="5">starts with</option>
                        <option value="6">ends with</option>
                    </select>
                    <input type="text" class="first_input">
                    <p class="p1">AND</p>
                </div>
               <%-- <span class="first_and">AND</span>
--%>
                <div class="second_limit">
                    <select class="second_select">
                        <option value="2">Author</option>
                        <option value="3">Title</option>

                        <option value="1">Journal</option>
                        <option value="1">Year</option>
                        <option value="1">doi</option>
                    </select>
                    <select class="second_contain">
                        <option value="4">contains</option>
                        <option value="5">starts with</option>
                        <option value="6">ends with</option>
                    </select>
                    <input type="text" class="second_input">
                    <p class="p2">AND</p>
                </div>
              <%--  <span class="second_and">AND</span>--%>
                <div class="third_limit">
                    <select class="third_select">
                        <option value="1">Journal</option>
                        <option value="3">Title</option>
                        <option value="2">Author</option>

                        <option value="1">Year</option>
                        <option value="1">doi</option>
                    </select>
                    <select class="third_contain">
                        <option value="4">contains</option>
                        <option value="5">starts with</option>
                        <option value="6">ends with</option>
                    </select>
                    <input type="text" class="third_input">
                </div>

                <div class="search_sub">
                    <input type="button" value="Search" class="search_btn">
                </div>
            </div>

            <%--<div class="serach_res">

            </div>--%>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<script type="text/javascript">

    $(".search_btn").click(function () {

       var first_select =  $(".first_select").val();
        var first_contain =  $(".first_contain").val();
        var first_input =  $(".first_input").val();

        var second_select =  $(".second_select").val();
        var second_contain =  $(".second_contain").val();
        var second_input =  $(".second_input").val();

        var third_select =  $(".third_select").val();
        var third_contain =  $(".third_contain").val();
        var third_input =  $(".third_input").val();
        /*alert(first_select);
        alert(first_contain);
        alert(first_input);

        alert(second_select);
        alert(second_contain);
        alert(second_input);

        alert(third_select);
        alert(third_contain);
        alert(third_input);*/

        $(window).attr('location','${pageContext.request.contextPath}/paper_advancelist.action?first_select='
            +first_select+'&first_contain='+first_contain+'&first_input='+first_input+'&second_select='+second_select
        +'&second_contain='+second_contain+'&second_input='+second_input+'&third_select='+third_select+'&third_contain='+third_contain+'&third_input='+third_input);
    });
</script>

<%@include file="footer.jsp"%>
</body>
</html>
