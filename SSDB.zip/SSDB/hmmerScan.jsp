<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/11/13
  Time: 下午8:14
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>TF Annotation</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/hmmerScan.css">--%>
    <%--<link rel="stylesheet" href="css/motiftools.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/hmmerScan_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/hmmerScan_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/hmmerScan_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/hmmerScan.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/hmmerScan_6.css">');
        }
    </script>

</head>
<body>

<%@include file="header.jsp"%>

<!--body-->
<div id="body">

    <div id="userguidelink">
        <a href="http://tbir.njau.edu.cn/NhCCDbHubs/download_down.action?fileName=TF_Annotion_1.zip" title="userguide and test data">
            <p class="userguidelink_p">Userguide and demo file</p>
        </a>


    </div>

    <div class="body_center">


        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/HmmerAction_hmmscan.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p>TF &nbsp;Annotation</p>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Database:</p>
                    <select class="hmmer_db" name="hmmer_db">
                        <option value="Pfam-A.hmm">Pfam 33.1</option>
                    </select>
                </div>
            </div>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Enter Fasta Protein Sequences:</p>
                    <textarea name="hmmer_seq" class="hmmer_seq" placeholder="Paste query sequence(s) in FASTA format here ...
For example:
>Bol004797
MTVLKRYVLRLFMSIKYITTNVVDKNNGRVVTTASTVEHAVKNSLECGRT
CNAKAAAILGEVLAMRLKVEGHQDGQGRGIHADVKKEIEKKGFKSRTKVW
AVINSVRNNGVTLILDDFNVDEDKYYRYRSDEGHQ"></textarea>
                    <input type="file" name="upload" id="fileupload">
                </div>
            </div>

            <div class="form_par">
                <div class="f_t_lab">
                    <p>Optional Parameters:</p>
                    <label>Evalue sequence:</label>
                    <select class="hmmer_eval" name="hmmer_eval">
                        <option>0.000001</option>
                        <option>0.00001</option>
                        <option>0.0001</option>
                        <option>0.001</option>
                    </select>
                    <label>Evalue domain:</label>
                    <select class="hmmer_eval" name="hmmerDomian_eval">
                        <option>0.000001</option>
                        <option>0.00001</option>
                        <option>0.0001</option>
                        <option>0.001</option>
                    </select>
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit TF Annotion:</p>
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>
<%@include file="footer.jsp"%>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        function turn(str) {

            while (str.indexOf("\n") != -1) {
                str = str.substring(0, str.indexOf("\n")) + "<br>"
                    + str.substring(str.indexOf("\n") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\C6MC6M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("|") != -1) {
                str = str.substring(0, str.indexOf("|")) + "\C9MC9M"
                    + str.substring(str.indexOf("|") + 1);
            }
            while (str.indexOf("_") != -1) {
                str = str.substring(0, str.indexOf("_")) + "\C3MC3M"
                    + str.substring(str.indexOf("_") + 1);
            }
            while (str.indexOf("#") != -1) {
                str = str.substring(0, str.indexOf("#")) + "\C5MC5M"
                    + str.substring(str.indexOf("#") + 1);
            }
            while (str.indexOf("=") != -1) {
                str = str.substring(0, str.indexOf("=")) + "\C7MC7M"
                    + str.substring(str.indexOf("=") + 1);
            }
            while (str.indexOf(".") != -1) {
                str = str.substring(0, str.indexOf(".")) + "\C8MC8M"
                    + str.substring(str.indexOf(".") + 1);
            }
            while (str.indexOf("/") != -1) {
                str = str.substring(0, str.indexOf("/")) + "\C4MC4M"
                    + str.substring(str.indexOf("/") + 1);
            }
            while (str.indexOf("-") != -1) {
                str = str.substring(0, str.indexOf("-")) + "\C2MC2M"
                    + str.substring(str.indexOf("-") + 1);
            }
            while (str.indexOf("+") != -1) {
                str = str.substring(0, str.indexOf("+")) + "\C1MC1M"
                    + str.substring(str.indexOf("+") + 1);
            }
            while (str.indexOf(":") != -1) {
                str = str.substring(0, str.indexOf(":")) + "\M6666MM6666M"
                    + str.substring(str.indexOf(":") + 1);
            }
            while (str.indexOf(";") != -1) {
                str = str.substring(0, str.indexOf(";")) + "\M1111MM1111M"
                    + str.substring(str.indexOf(";") + 1);
            }
            while (str.indexOf(" ") != -1) {
                str = str.substring(0, str.indexOf(" ")) + "\M2222MM2222M"
                    + str.substring(str.indexOf(" ") + 1);
            }
            while (str.indexOf("\t") != -1) {
                str = str.substring(0, str.indexOf("\t")) + "\M3333MM3333M"
                    + str.substring(str.indexOf("\t") + 1);
            }
            while (str.indexOf(",") != -1) {
                str = str.substring(0, str.indexOf(",")) + "\M4444MM4444M"
                    + str.substring(str.indexOf(",") + 1);
            }
            while (str.indexOf("    ") != -1) {
                str = str.substring(0, str.indexOf("    ")) + "\Cc1MCc1M"
                    + str.substring(str.indexOf("   ") + 1);
            }
            return str;
        };

        $(".blast_sb").click(function () {

            var hmmer_db = $(".hmmer_db").select().val();
            var hmmer_seq = $(".hmmer_seq").val();
            var hmmer_eval = $(".hmmer_eval").val();
            var fileupload = $("#fileupload").val();

          /*  alert(hmmer_db);
            alert(hmmer_seq);
            alert(hmmer_eval);*/

            if(hmmer_seq == "" && fileupload == ""){
                alert("please upload fasta sequence file!");
            }
            if(hmmer_seq != "" && fileupload != ""){
                alert("please input or upload sequence file!");
            }
            if(hmmer_seq != "" && fileupload == ""){
                cont1 = turn(hmmer_seq);

                var new_blast_seq = $(".blast_seq").val(cont1);

                $("#blast_form").submit();
            }
            if(hmmer_seq == "" && fileupload != ""){
                $("#blast_form").submit();
            }

        });


    });
</script>


</body>
</html>
