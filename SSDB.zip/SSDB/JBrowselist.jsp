<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/7/27
  Time: 下午7:35
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>JBrowse</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/DownloadGenome.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/DownloadGenome_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/DownloadGenome_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/DownloadGenome_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/DownloadGenome.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/DownloadGenome_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>

<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
    <div id="body_center">
        <div class="body_center_center">
            <div class="body_center_top">
                <p class="b_c_t_p1"><s:property value="#session.jbrowse_title"></s:property></p>
            </div>

            <div class="sub_species">

                <s:iterator value="allJbrowse" var="Jbrowselist">
                    <div class="spe">
                        <a target="_blank" href="<s:property value="#Jbrowselist.J_spelink"/>">
                            <span class="icon-eye"></span>
                            <i><s:property value="#Jbrowselist.J_species"></s:property></i>&nbsp;<s:property value="#Jbrowselist.J_details"></s:property>
                        </a>
                    </div>
                </s:iterator>

            </div>
        </div>
    </div>
</div>
<!--footer-->
<%@include file="footer.jsp"%>

</body>
</html>
