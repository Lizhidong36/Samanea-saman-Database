<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/3/7
  Time: 下午4:55
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<html>
<head>
    <title>Title</title>
    <link href="img/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/header.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/pathwayheader_24.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/pathwayheader_18.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/pathwayheader_15.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/pathwayheader.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/pathwayheader_6.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>

<!--header-->
<div id="header">

    <div class="h_top">
        <div class="h_top_center">
            <a href="${pageContext.request.contextPath}/index.jsp" target="_blank">
                <span class="h_t_c_B">P</span>
                <span class="h_t_c_i">a</span>
                <span class="h_t_c_o">t</span>
                <span class="h_t_c_P">h</span>
                <span class="h_t_c_l">w</span>
                <span class="h_t_c_o">a</span>
                <span class="h_t_c_i rotate">y</span>
            </a>
        </div>
    </div>
</div>

</body>
</html>
