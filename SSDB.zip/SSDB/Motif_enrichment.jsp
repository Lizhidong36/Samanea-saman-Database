<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/1/10
  Time: 下午1:31
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/Motif_enrichment.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/Motif_enrichment_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/Motif_enrichment_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/Motif_enrichment_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/Motif_enrichment.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/Motif_enrichment_6.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
    <div class="body_center">
        <form target="_blank" id="mot_enr_form" action="${pageContext.request.contextPath}/Motifenrichment_enrich.action" method="post" enctype="multipart/form-data">
            <div class="form_top">
                <p>Motif &nbsp;Enrichment</p>
            </div>
            <div class="form_par">
                <div class="f_t_lab">
                    <p>Select the type of control sequences to use</p>
                    <input value="sh" class="tran_pro" type="radio" name="control_type" checked>
                    <label class="tran_pro_label"> Shuffled input sequences</label>
                    <input value="user" class="tran_pro" type="radio" name="control_type">
                    <label class="tran_pro_label"> User-provided control sequences</label>
                    <input value="none" class="tran_pro" type="radio" name="control_type">
                    <label class="tran_pro_label"> NONE</label>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select the sequence alphabet</p>
                    <input value="-dna" class="tran_pro" type="checkbox" <%--name="tran_pro" --%>checked>
                    <label class="tran_pro_label"> DNA, RNA or Protein</label>
                </div>
            </div>
            <div class="form_database">
                <div class="f_t_lab">
                    <p>Enter the sequences in which you want to find enriched motifs</p>
                    <label>Uploading sequence:</label>
                    <input type="file" name="sequpload" id="sequpload"/>
                </div>
            </div>
            <div  style="display: none" id="four_database">
                <div class="f_t_lab">
                    <p>Enter the control sequences</p>
                    <label>Uploading control sequence:</label>
                    <input type="file" name="cont_upload" id="cont_upload"/>
                </div>
            </div>
            <div class="form_database">
                <div class="f_t_lab">
                    <p>Enter the motifs you wish to test for enrichment</p>
                    <label>Uploading motif sequence:</label>
                    <input type="file" name="motif_upload" id="motif_upload"/>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select the sequence scoring method</p>
                    <select class="motif_type" name="seq_score_met">
                        <option value="avg">Average odds score</option>
                        <option value="max">Maximum odds score</option>
                        <option value="sum">Total odds score</option>
                        <option value="totalhits">Total hits</option>
                    </select>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select the motif enrichment test</p>
                    <select class="motif_type" name="motif_enrich_test">
                        <option value="fisher">Fisher's exact test</option>
                        <option value="ranksum">Ranksum test</option>
                        <option value="pearson">Pearson CC</option>
                        <option value="spearman">Spearman CC</option>
                        <option value="3dmhg">3dmhg</option>
                        <option value="4dmhg">4dmhg</option>
                    </select>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Choose the (fractional) score threshold for hits</p>
                    <label>Fraction of maximum log-odds: </label>
                    <input value="0.25" name="fraction_val" class="fraction_val">
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Set the E-value threshold for reporting enriched motifs</p>
                    <label>E-value ≤</label>
                    <input value="10" name="e_val" class="e_val">
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Shuffling preserves frequencies words of what size</p>
                    <select class="kmer" name="kmer">
                        <option value="2">2</option>
                        <option value="1">1</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                </div>
            </div>
            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit Motif  Enrichment:</p>
                    <input type="button" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        $('.tran_pro').click(function () {

            var val=$('input:radio[name="control_type"]:checked').val();
           // alert(val);
            if(val== 'user'){
                $('#four_database').css('display','block');
            }else{
                $('#four_database').css('display','none');
            }

        });

        $('.blast_sb').click(function () {

            var sequploadtitle = $('#sequpload').val();
            /*alert(sequploadtitle);*/

            var motif_uploadtitle = $('#motif_upload').val();
            /*alert(motif_uploadtitle);*/

            var fraction_val = $('.fraction_val').val();
            /*alert(fraction_val);*/

            var e_val = $('.e_val').val();
            /*alert(e_val);*/

            var cont_uploadtitle = $('#cont_upload').val();
           /* alert(cont_uploadtitle);*/


            var control_type=$('input:radio[name="control_type"]:checked').val();
           /* alert(control_type);*/

            if(sequploadtitle == ""){
                alert('please upload your sequence !');
                return;
            }
            if(motif_uploadtitle == ""){
                alert('please upload your motifs !');
                return;
            }
            if(fraction_val == ""){
                alert("please choose the (fractional) score threshold for hits !");
                return;
            }
            if(e_val == ""){
                alert("please set the E-value threshold for reporting enriched motifs !");
                return;
            }
            if(control_type == "user" && cont_uploadtitle == ""){

                alert("if you choose 'User-provided control sequences', you must upload the control sequences !");
                return;
            } else {
                /*alert('submit');*/

                $("#mot_enr_form").submit();

            }

        });


    });
</script>
</body>
</html>
