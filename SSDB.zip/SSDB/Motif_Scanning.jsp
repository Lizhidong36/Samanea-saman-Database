<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/1/8
  Time: 下午2:48
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
   <%-- <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/Motif_Scanning.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Scanning_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Scanning_15.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Scanning_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Scanning.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/Motif_Scanning_6.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
    <div class="body_center">
        <form action="${pageContext.request.contextPath}/MotifScaning_scan.action" method="post" enctype="multipart/form-data">
            <div class="form_top">
                <p>Motif &nbsp;Scanning</p>
            </div>

            <div class="form_par">
                <div class="f_t_lab">
                    <p>Input the motifs:</p>
                    <label>Motifs type:</label>
                    <select class="motif_type" name="motif_type">
                        <option value="1">DNA</option>
                        <option value="2">Protein</option>
                    </select>
                    <br>
                    <label>Upload motifs:</label>
                    <input type="file" name="motifupload" id="fileupload"/>
                </div>
            </div>

            <div class="form_seq">
                <div class="f_t_lab">
                    <p>Input the sequences:</p>
                    <label>Type:</label>
                    <select class="motif_type" name="seq_type">
                        <option value="1">DNA</option>
                        <option value="2">Protein</option>
                    </select>
                    <br>
                    <label>Upload file:</label>
                    <input type="file" name="sequpload" id="sequpload"/>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Set a sequence display threshold:</p>
                    <label>Sequence E-value ≤ </label>
                    <input value="10" name="seq_value">
                </div>
            </div>
            <div class="form_database">
                <div class="f_t_lab">
                    <p>Translate DNA sequences to protein?</p>
                    <input value="-dna" class="tran_pro" type="checkbox" name="tran_pro">
                    <label class="tran_pro_label"> Search DNA sequences with protein motifs?</label>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Remove redundant motifs from query?</p>
                    <input value="-remcorr" class="tran_pro" type="checkbox" checked name="Remove_redundant">
                    <label class="tran_pro_label"> Should MAST remove any motifs that are too similar to others?</label>
                </div>
            </div>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit Motif  Scanning:</p>
                    <input type="submit" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>
    </div>
</div>
<%@include file="footer.jsp"%>
</body>
</html>
