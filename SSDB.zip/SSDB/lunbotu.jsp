<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/3/21
  Time: 下午3:59
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
  <%--  <link rel="stylesheet" href="css/lunbotu.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/lunbotu_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/lunbotu_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/lunbotu_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/lunbotu.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/lunbotu_6.css">');
        }
    </script>

</head>
<body>
<div class="box">
    <ul class="image">
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/boxplot.jsp" target="_blank">
                <img src="image/1.png"/>
            </a>
        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/Venn.jsp" target="_blank">
                <img src="image/10.png"/>
            </a>

        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/corrplot.jsp" target="_blank">
                <img src="image/2.png"/>
            </a>
        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/qqplot.jsp" target="_blank">
                <img src="image/7.png"/>
            </a>

        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/manhataanplot.jsp" target="_blank">
                <img src="image/8.jpeg"/>
            </a>

        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/seqlogo.jsp" target="_blank">
                <img src="image/9.png"/>
            </a>
        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/volcano.jsp" target="_blank">
                <img src="image/4.png"/>
            </a>

        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/heatmap.jsp" target="_blank">
                <img src="image/6.png"/>
            </a>

        </li>

        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/keggrich.jsp" target="_blank">
                <img src="image/5.png"/>
            </a>

        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/goterm.jsp" target="_blank">
                <img src="image/3.png"/>
            </a>
        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/violin.jsp" target="_blank">
                <img src="image/violin.jpeg"/>
            </a>
        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/ternary.jsp" target="_blank">
                <img src="image/ternary.png"/>
            </a>
        </li>
        <li>
            <a href="http://tbir.njau.edu.cn/pLoTs/mifenqun.jsp" target="_blank">
                <img src="image/honery.jpeg"/>
            </a>
        </li>

    </ul>
    <span class="num_par">
        <ul class="num">
            <li class='current'>1</li>
            <li>2</li>
            <li>3</li>
            <li>4</li>
            <li>5</li>
            <li>6</li>
            <li>7</li>
            <li>8</li>
            <li>9</li>
            <li>10</li>
            <li>11</li>
            <li>12</li>
            <li>13</li>
        </ul>
    </span>

    <div class="left arrow"><</div>
    <div class="right arrow">></div>
</div>
<script src="js/jquery-3.3.1.js" type="text/javascript" charset="utf-8"></script>
<script src="js/new.js"></script>
</body>
</html>
