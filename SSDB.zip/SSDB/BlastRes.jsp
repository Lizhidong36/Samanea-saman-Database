<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/22
  Time: 16:54
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/BlastRes.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/BlastRes_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/BlastRes_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/BlastRes_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/BlastRes.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/BlastRes_6.css">');
        }
    </script>

</head>
<body>
<div id="click_btn">
    <%--<input type="button" value="click here" class="c_btn">--%>
</div>
</body>
</html>
