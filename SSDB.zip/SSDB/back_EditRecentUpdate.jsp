<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/10/26
  Time: 上午11:26
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/back_EditRecentUpdate.css">
</head>
<body>
<%@include file="backHeader.jsp"%>

<%--body--%>
<div id="body">
    <div class="body_center">
        <div class="body_center_center">
            <div class="b_c_c_top">
                <p>Edit &nbsp;Recent  Update</p>
            </div>


            <form action="${pageContext.request.contextPath}/recentUpdate_updateOneUpdate.action">

                <div class="b_c_c_describe">
                    <p>Recent Update Describe:</p>
                    <textarea class="news_desc" name="re_desc"><s:property value="#session.oneUpdate.re_desc"/></textarea>
                    <input type="text" class="new_id" name="re_id" value="<s:property value="#session.oneUpdate.re_id"/>">

                </div>

                <div class="b_c_c_date">
                    <p>Date:</p>
                    <input type="text" class="new_data" name="re_date" value="<s:property value="#session.oneUpdate.re_date"/>">
                </div>

                <div class="b_c_c_detail">
                    <p>Recent Update Link:</p>
                    <textarea class="news_detail" name="re_link"><s:property value="#session.oneUpdate.re_link"/></textarea>
                </div>

                <div class="b_c_c_submit">
                    <p>Update:</p>
                    <input type="submit" value="Update" class="save">
                </div>
            </form>

        </div>
    </div>
</div>
</body>
</html>
