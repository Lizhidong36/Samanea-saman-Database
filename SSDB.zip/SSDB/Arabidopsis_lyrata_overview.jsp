<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/12/25
  Time: 下午2:19
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Species Detail</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <%--<link rel="stylesheet" href="css/body_kuangjia.css">
    <link rel="stylesheet" href="css/Arabidopsis_lyrata_overview.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/body_kuangjia_24.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_overview.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/body_kuangjia_18.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_overview.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/body_kuangjia_15.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_overview.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/body_kuangjia.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_overview.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/body_kuangjia_6.css">');
            document.write('<link rel="stylesheet" href="css/Arabidopsis_lyrata_overview.css">');
            document.write('<link rel="stylesheet" href="css/a_hovers.css">');
        }
    </script>

</head>
<body>
<%@include file="header.jsp"%>
<%--body--%>
<div id="body">
    <div class="body_center">

        <form action="#">
            <div class="form_top">

                <p><s:property value="spe_ov_t_title"/></p>
            </div>
            <div class="form_function">
                <div class="form_function_species">
                    <div class="f_f_s_top">
                        <a>
                           <%-- <p>Arabidopsis &nbsp;lyrata &nbsp;</p>
                            <p>v2.1 &nbsp;Genome</p>--%>
                            <p><s:property value="spe_ov_t_title"/></p>
                            <p></p>
                        </a>
                    </div>
                    <div class="f_f_s_center">
                        <a href="http://tbir.njau.edu.cn/pLoTs/boxplot.jsp" target="_blank">Box-plot</a>
                        &nbsp;|&nbsp;
                        <a href="http://tbir.njau.edu.cn/pLoTs/Venn.jsp" target="_blank">Venn-plot</a>
                        &nbsp;|&nbsp;
                        <a href="http://tbir.njau.edu.cn/pLoTs/qqplot.jsp" target="_blank">QQ-plot</a>
                        &nbsp;|&nbsp;
                        <a href="http://tbir.njau.edu.cn/pLoTs/manhataanplot.jsp" target="_blank">Manhattan-plot</a>
                        &nbsp;|&nbsp;
                        <a href="http://tbir.njau.edu.cn/pLoTs/seqlogo.jsp" target="_blank">Seqlogo-plot</a>
                        &nbsp;|&nbsp;
                        <a href="http://tbir.njau.edu.cn/pLoTs/volcano.jsp" target="_blank">Volcano-plot</a>
                        &nbsp;|&nbsp;
                        <a href="http://tbir.njau.edu.cn/pLoTs/heatmap.jsp" target="_blank">Heatmap-plot</a>
                        &nbsp;|&nbsp;
                        <a href="http://tbir.njau.edu.cn/pLoTs/corrplot.jsp" target="_blank">Corr-plot</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=blast&functionType=blast" target="_blank">Blast+</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/SSRFinder.jsp" target="_blank">SSR Finder</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=kegg&functionType=kegg" target="_blank">KEGG Enrichment</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=go&functionType=go" target="_blank">GO Enrichment</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/Synteny2.jsp" target="_blank">Synteny Finder</a>
                        &nbsp;|&nbsp;
                       <%-- <a href="${pageContext.request.contextPath}/kegg_pathway.jsp" target="_blank">KEGG Pathway</a>
                        &nbsp;|&nbsp;--%>
                        <a href="${pageContext.request.contextPath}/Motif_Discovery.jsp" target="_blank">Motif Discovery</a>
                        &nbsp;|&nbsp;

                        <a href="${pageContext.request.contextPath}/hmmerScan.jsp" target="_blank">TF Annotation</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/BlastFile_allFile.action?directfile=batchquery&functionType=blast" target="_blank">Batch Query</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/blastResSearch.jsp" target="_blank">Tools Result Search</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/LiteratureSearch.jsp" target="_blank">Literature Search</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/Submit.jsp" target="_blank">Submit</a>
                        &nbsp;|&nbsp;
                        <a href="<s:property value="spe_ov_t_jbrowselink"/>" target="_blank">JBrowse</a>
                        &nbsp;|&nbsp;
                        <a href="<s:property value="spe_ov_t_downloadlink"/>" target="_blank">Genome</a>
                        &nbsp;|&nbsp;
                        <a href="<s:property value="spe_ov_t_keyword"/>">Literature</a>
                        &nbsp;|&nbsp;
                        <a href="${pageContext.request.contextPath}/Link.jsp" target="_blank">Links</a>
                        &nbsp;|&nbsp;
                        <a href="http://tbir.njau.edu.cn/pLoTs/primer.jsp" target="_blank">Primer Design</a>
                    </div>

                </div>
            </div>

            <div class="form_overview">

                <div class="form_overview_top">
                    <p>Overview:</p>
                </div>
                <div class="form_overview_body">

                    <s:iterator value="overContList" var="species_overview_overview">

                        <div class="form_overview_body_intro">

                            <span><s:property value="#species_overview_overview.spe_ov_ov_desc"/></span>
                            <span><s:property value="#species_overview_overview.spe_ov_ov_cont"/></span>
                        </div>

                    </s:iterator>

                </div>
            </div>

            <div class="form_overview">

                <div class="form_overview_top">
                    <p>Feature Summary:</p>
                </div>
                <div class="form_overview_body">
                    <s:iterator value="feaContList" var="species_overview_feature">
                        <div class="form_overview_body_intro">

                            <span><s:property value="#species_overview_feature.spe_ov_fea_desc"/></span>
                            <span><s:property value="#species_overview_feature.spe_ov_fea_cont"/></span>
                        </div>

                    </s:iterator>

                </div>
            </div>


            <div class="spe_introductions">
                <div class="form_function_species">
                    <div class="f_f_s_top">

                        <p class="ref_paper">
                            Reference Publication(s):
                        </p>
                        <ul>
                            <s:iterator value="paperContList" var="species_overview_paper">
                                <li>
                                    <span><s:property value="#species_overview_paper.spe_ov_pa_autor"/></span>
                                    <span>
                                    <a href="<s:property value="#species_overview_paper.spe_ov_pa_link"/>" target="_blank">
                                        <s:property value="#species_overview_paper.spe_ov_pa_name"/>
                                    </a>
                                </span>
                                    <span><s:property value="#species_overview_paper.spe_ov_pa_journal"/></span>
                                </li>
                            </s:iterator>
                        </ul>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>
<!--footer-->
<%@include file="footer.jsp"%>
</body>
</html>
