<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/8/29
  Time: 下午4:18
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib uri="/struts-tags" prefix="s"%>
<html>
<head>
    <title>Gene Annotation</title>
    <link href="image/favicon.ico" rel="shortcut icon">
  <%--  <link rel="stylesheet" href="css/tools.css">
    <link rel="stylesheet" href="css/TF.css">--%>

    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/tools_24.css">');
            document.write('<link rel="stylesheet" href="css/TF_24.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoSearch_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/tools_18.css">');
            document.write('<link rel="stylesheet" href="css/TF_18.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoSearch_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/tools_15.css">');
            document.write('<link rel="stylesheet" href="css/TF_15.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoSearch_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/tools.css">');
            document.write('<link rel="stylesheet" href="css/TF.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoSearch.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/tools_6.css">');
            document.write('<link rel="stylesheet" href="css/TF_6.css">');
            document.write('<link rel="stylesheet" href="css/font_styles.css">');
            document.write('<link rel="stylesheet" href="css/geneAnnoSearch_6.css">');
        }
    </script>


</head>
<body>
<%@include file="header.jsp"%>

<!--body-->
<div id="body">
    <div class="body_center">

        <form target="_blank" id="blast_form" action="${pageContext.request.contextPath}/literuture_geneannolist.action" method="post"  enctype="multipart/form-data">
            <div class="form_top">
                <p>Gene &nbsp;Search</p>
            </div>
            <div class="form_database">
                <div class="f_t_lab">
                    <p>Search Input:</p>
<%--                    <select class="hmmer_db" name="alltf_species">--%>

<%--                        <option  value="Ziziphus_jujuba">Ziziphus jujuba</option>--%>
<%--                        <input type="text" name="keyword" class="input_search" value="<s:property value="#parameters.keyword"/>" placeholder="Example:WRKY,BraC01g000010.1">--%>
                        <input type="text" name="keyword" class="input_search"  placeholder="Keyworld or gene id. Example:WRKY">


<%--                    </select>--%>
                </div>
            </div>

            <div class="form_database">
                <div class="f_t_lab">
                    <p>Select Species:</p>
                    <select class="hmmer_db" name="alltf_species">

                        <option  value="Samanea_saman">Samanea saman</option>



                    </select>
                </div>
            </div>

<%--            <div class="form_par">--%>
<%--                <div class="f_t_lab">--%>
<%--                    <p>Select Family:</p>--%>
<%--                    <s:iterator value="allTF" var="tffamily">--%>
<%--                        <input value="<s:property value="#tffamily.tf_name"/>" class="tran_pro" type="radio" name="alltf_family">--%>
<%--                        <label class="tran_pro_label"> <s:property value="#tffamily.tf_name"/></label>--%>
<%--                    </s:iterator>--%>

<%--                </div>--%>
<%--            </div>--%>

            <div class="form_sub">
                <div class="f_t_lab">
                    <p>Submit:</p>
                    <input type="button" value="Example" class="blast_example">
                    <input type="submit" value="Submit" class="blast_sb">
                </div>
            </div>

        </form>

    </div>
</div>
<%@include file="footer.jsp"%>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<script type="text/javascript">

    $(function () {

        $(".blast_example").click(function () {

            $(".input_search").val("WRKY");
        });
    });
</script>
</body>
</html>
