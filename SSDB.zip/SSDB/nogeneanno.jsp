<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2021/4/30
  Time: 上午10:15
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Gene Function</title>
    <link href="image/favicon.ico" rel="shortcut icon">
    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/literuture_24.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_24.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_24.css">');
            document.write('<link rel="stylesheet" href="css/geneanno_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/literuture_18.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_18.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_18.css">');
            document.write('<link rel="stylesheet" href="css/geneanno_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/literuture_15.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_15.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_15.css">');
            document.write('<link rel="stylesheet" href="css/geneanno_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/literuture.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist.css">');
            document.write('<link rel="stylesheet" href="css/geneanno.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/literuture_6.css">');
            document.write('<link rel="stylesheet" href="css/pageStyle_6.css">');
            document.write('<link rel="stylesheet" href="css/ssrlist_6.css">');
            document.write('<link rel="stylesheet" href="css/geneanno_6.css">');
        }
    </script>
</head>
<body>
<%@include file="header.jsp"%>
<!--body-->
<div id="body">
    <!--body_center-->
    <div id="body_center">

        <div class="body_center_top">
            <p class="b_c_t_p1">Gene &nbsp;&nbsp;Function &nbsp;&nbsp;Annotation</p>
            <div id="s_input">
                <input type="text" id="input_search" value="<s:property value="#parameters.keyword"/>" placeholder="Example:WRKY,BraC01g000010.1">
            </div>
            <div id="s_button">
                <input type="button" value="Search">
            </div>
        </div>


        <%--<div class="body_center_bottom">
            <a href="https://pubmed.ncbi.nlm.nih.gov/<s:property value="#article.ar_link"/>" target="_blank">
        </div>--%>
        <div class="ssr_list">
            <div class="ssr_list_headerid">Gene Id</div>
            <div class="ssr_list_headernr">GO</div>
            <div class="ssr_list_headertype">KEGG</div>
            <div class="ssr_list_headerssr">KOG</div>
            <div class="ssr_list_headersize">Pfam</div>
            <div class="ssr_list_headerstart">Swissprot</div>
            <div class="ssr_list_headerend">TrEMBL</div>
            <div class="ssr_list_headerprimer">NR</div>
            <div class="ssr_list_headerprimer">InterPro</div>
        </div>
        <s:iterator value="list" var="geneannt">
            <div class="ssr_detail">
                <a href="${pageContext.request.contextPath}/literuture_noonegeneAnno.action?g_id=<s:property value="#geneannt.g_id"/>" target="_blank">
                    <div class="ssr_list_ID"><s:property value="#geneannt.g_name"/></div>
                </a>

                <a href="${pageContext.request.contextPath}/literuture_noonegeneAnno.action?g_id=<s:property value="#geneannt.g_id"/>" target="_blank">
                    <div class="ssr_list_nr icon-file-text"></div>
                </a>

                <a href="${pageContext.request.contextPath}/literuture_noonegeneAnno.action?g_id=<s:property value="#geneannt.g_id"/>" target="_blank">
                    <div class="ssr_list_type icon-file-text"></div>
                </a>

                <a href="${pageContext.request.contextPath}/literuture_noonegeneAnno.action?g_id=<s:property value="#geneannt.g_id"/>" target="_blank">
                    <div class="ssr_list_SSR icon-file-text"></div>
                </a>

                <a href="${pageContext.request.contextPath}/literuture_noonegeneAnno.action?g_id=<s:property value="#geneannt.g_id"/>" target="_blank">
                    <div class="ssr_list_size icon-file-text"></div>
                </a>

                <a href="${pageContext.request.contextPath}/literuture_noonegeneAnno.action?g_id=<s:property value="#geneannt.g_id"/>" target="_blank">
                    <div class="ssr_list_star icon-file-text"></div>
                </a>

                <a href="${pageContext.request.contextPath}/literuture_noonegeneAnno.action?g_id=<s:property value="#geneannt.g_id"/>" target="_blank">
                    <div class="ssr_list_end icon-file-text"></div>
                </a>

                <a href="${pageContext.request.contextPath}/literuture_noonegeneAnno.action?g_id=<s:property value="#geneannt.g_id"/>" target="_blank">
                    <div class="ssr_list_end icon-file-text"></div>
                </a>

                <a href="${pageContext.request.contextPath}/literuture_noonegeneAnno.action?g_id=<s:property value="#geneannt.g_id"/>" target="_blank">
                    <div class="ssr_list_primer icon-file-text"></div>
                </a>

            </div>
        </s:iterator>

        <div id="page" class="page_div"></div>

    </div>
</div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<%--<script src="js/jquery.min.js"></script>--%>
<script type="text/javascript" src="js/paging.js"></script>
<script type="text/javascript">

    //分页
    $("#page").paging({
        pageNo:<s:property value="currentPage"/>,
        totalPage: <s:property value="totalPage"/>,
        totalSize:  <s:property value="totalCount"/>,
        callback: function(num) {
            var keyword =  $("#input_search").val();

            //alert(keyword);

            //alert(num);
            <%--$(window).attr('location','${pageContext.request.contextPath}/literuture_nogeneannolist.action?currPage='+num+'&keyword='+keyword);--%>
        }
    });

    $("#s_button").click(function () {

        var keyword =  $("#input_search").val();

        //alert(keyword);
        <%--$(window).attr('location','${pageContext.request.contextPath}/literuture_nogeneannolist.action?keyword='+keyword);--%>
    });

</script>

<%@include file="footer.jsp"%>


</body>
</html>
