<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2020/7/16
  Time: 下午3:43
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <script src="js/echarts.js"></script>
   <%-- <link rel="stylesheet" href="css/echarttest.css">--%>


    <script>

        if(window.screen.width >= 2480){
            document.write('<link rel="stylesheet" href="css/echarttest_24.css">');
        }

        else if(window.screen.width >= 1880){
            document.write('<link rel="stylesheet" href="css/echarttest_18.css">');
        }
        else if(window.screen.width >= 1540){
            document.write('<link rel="stylesheet" href="css/echarttest_15.css">');
        }
        else if( window.screen.width >= 1000){
            document.write('<link rel="stylesheet" href="css/echarttest.css">');
        }
        else{
            document.write('<link rel="stylesheet" href="css/echarttest_6.css">');
        }
    </script>

</head>
<body>

<%--<div id="main" style="width: 386.6px;height:304px;"></div>--%>
<div id="main"></div>
<script type="text/javascript">

    var myChart = echarts.init(document.getElementById('main'));

    option = {

        color: ['#37a2da','#32c5e9', '#67e0e3', '#9fe6b8', '#ffdb5c', '#fb7293', '#e062ae', '#e062ae', '#e690d1','#67e0e3'],

        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
            show: false
        },
        series: [
            {
                name: 'Species',
                type: 'pie',
                radius: '55%',
                center: ['50%', '50%'],
                data: [
                    {value: 1, name: 'Arabidopsis thaliana'},
                    {value: 5, name: 'Brassica campestris'},
                    {value: 4, name: 'Arabis alpina'},


                    {value: 2, name: 'Brassica juncea'},

                    {value: 1, name: 'Brassica nigra'},
                    {value: 9, name: 'Brassica napus'},
                    {value: 1, name: 'Brassica oleracea'}



                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);

</script>
</body>
</html>
