<%--
  Created by IntelliJ IDEA.
  User: root
  Date: 2019/10/24
  Time: 下午7:23
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/back_AddNews.css">
</head>
<body>
<%@include file="backHeader.jsp"%>
<div id="body">
    <div class="body_center">
        <div class="body_center_center">
            <div class="b_c_c_top">
                <p>Add &nbsp;News</p>
            </div>

            <form action="${pageContext.request.contextPath}/news_SaveOneNews.action">

                <div class="b_c_c_describe">
                    <p>News Describe:</p>
                    <textarea class="news_desc" name="new_desc"></textarea>

                </div>

                <div class="b_c_c_date">
                    <p>Date:</p>
                    <input type="text" class="new_data" name="new_data">
                </div>

                <div class="b_c_c_detail">
                    <p>News Detail:</p>
                    <textarea class="news_detail" name="new_detail"></textarea>
                </div>

                <div class="b_c_c_submit">
                    <p>Save:</p>
                    <input type="submit" value="Save" class="save">
                </div>
            </form>


        </div>
    </div>
</div>

</body>
</html>
