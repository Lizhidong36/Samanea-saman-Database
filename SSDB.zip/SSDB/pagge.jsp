<%--
  Created by IntelliJ IDEA.
  User: 志栋
  Date: 2019/7/24
  Time: 10:58
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java"
         pageEncoding="UTF-8"%>
<%
    String ctx = request.getContextPath();
    pageContext.setAttribute("ctx", ctx);
%>
<html>
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="${ctx}/css/style.css"
          type="text/css" />
    <link rel="stylesheet" href="${ctx}/css/amazeui.min.css" />
    <link rel="stylesheet" href="${ctx}/css/pageStyle.css">
</head>
<body>

<!--分页-->
<div id="page" class="page_div"></div>

<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
<%--<script type="text/javascript" src="js/jquery.min.js"></script>--%>
<%--<script src="js/jquery.min.js"></script>--%>
<script type="text/javascript" src="js/paging.js"></script>
<script type="text/javascript">

    //分页
    $("#page").paging({
        pageNo:1,
        totalPage: 5,
        totalSize: 3,
        callback: function(num) {
            /*  $(window).attr('location','/article_list.action?currPage='+num);*/
            alert(num);
        }
    });

</script>
</body>
</html>

